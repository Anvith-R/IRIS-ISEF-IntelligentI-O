/*
 * libiio.so - LD_PRELOAD interposer.   v0.3 (BCL-3 runtime)
 *
 * Does NOTHING unless IIO_MODE is set, and IIO_MODE is only set by
 * `iio record|run|bench` for the one process the developer launches.
 *
 *   IIO_MODE=record : append "<t_us>\t<file key>" for every successful
 *                     read-only open()/openat()/fopen() and every dlopen()
 *                     of a path.
 *   IIO_MODE=run    : on every such event predict what comes next and hand it
 *                     to low-priority worker threads (readahead/fadvise).
 *
 * Runtime safety rails (all enforced off the application's thread):
 *   * hard cap on speculative bytes that are resident-but-unconsumed
 *     (IIO_SPEC_MB, default min(512, MemAvailable/8) MB, floor 32 MB)
 *   * entries expire after IIO_TTL_MS (default 30 s) so a wrong guess stops
 *     counting against the cap
 *   * memory guard: no prefetch while MemAvailable < max(128 MB, 8% of RAM)
 *   * total byte budget (IIO_BUDGET_MB, default 2048), per-file cap (128 MB)
 *   * precision governor: threshold rises when guesses are wasted
 *   * optional deadline-aware ("just in time") issue, IIO_JIT=1
 *   * files the app already demanded are never prefetched ("moot")
 *
 * Developer API (optional): int iio_hint(const char *path) asks for a file to
 * be prefetched now (TIP-style declared future reads). See include/iio_hint.h.
 *
 * Environment (normally set by the iio CLI): IIO_TRACE IIO_MODEL IIO_ROOT
 * IIO_STATS IIO_RESIDENCY IIO_NOPF IIO_HINTS IIO_THREADS IIO_BUDGET_MB
 * IIO_MAXPF_MB IIO_SPEC_MB IIO_TTL_MS IIO_MEMGUARD IIO_JIT IIO_JIT_FRAC
 * IIO_LEAD_MS IIO_METHOD IIO_ADAPT IIO_REPF_MS IIO_VERBOSE IIO_THR IIO_DEPTH ...
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#include "iio_common.h"

#define EXPORT __attribute__((visibility("default")))
#define QCAP 1024
#define RCAP 4096
#define THREAD_STACK (128 * 1024)

typedef int (*open_fn)(const char *, int, ...);
typedef int (*openat_fn)(int, const char *, int, ...);
typedef FILE *(*fopen_fn)(const char *, const char *);
typedef void *(*dlopen_fn)(const char *, int);

static open_fn   r_open, r_open64;
static openat_fn r_openat, r_openat64;
static fopen_fn  r_fopen, r_fopen64;
static dlopen_fn r_dlopen;

enum { M_OFF = 0, M_RECORD = 1, M_RUN = 2 };
static volatile int g_mode;
static volatile int g_disabled;           /* set in forked children */
static __thread int t_busy;

static uint64_t g_t0;
static int      g_trace_fd = -1;
static int      g_tl_fd = -1;                 /* run-mode timeline (IIO_TIMELINE) */
static char     g_trace_path[PATH_MAX];

static char    *g_roots[IIO_MAX_ROOTS];
static size_t   g_rootlen[IIO_MAX_ROOTS];
static uint32_t g_nroots;

/* ---- run-mode state (everything below g_lock unless noted) ---- */
static iio_model  g_m;
static iio_params g_p;
static double     g_thr_floor;
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
static uint32_t   g_prev = IIO_NONE, g_cur = IIO_START;
static uint64_t  *g_pf_last;      /* last enqueue time per id            */
static uint64_t  *g_due;          /* scheduled issue time per id         */
static uint64_t  *g_sz;           /* bytes charged to the spec cap       */
static uint32_t  *g_gen;          /* generation (validates ring entries) */
static uint8_t   *g_st8;          /* 0 idle, 1 queued, 2 fetched-unused  */
typedef struct { uint32_t id, gen; uint64_t t; } ring_ent;
static ring_ent   g_ring[RCAP];
static uint32_t   g_rhead, g_rcount;
static uint64_t   g_unc;          /* speculative bytes resident, unused  */

static int g_nopf, g_stats, g_resid, g_adapt = 1, g_verbose, g_use_readahead = 1;
static int g_jit, g_memguard = 1, g_hints_only;
static double g_jit_frac = 0.5;
static uint64_t g_lead_us = 30000, g_repf_us = 5000000, g_ttl_us = 30000000;
static uint64_t g_budget, g_maxpf, g_spec_cap;
static uint32_t g_mem_floor_pct = 8;
static char g_model_path[PATH_MAX];

static struct {
    uint64_t opens, events_dl, known, unknown;
    uint64_t hits, late, moot, raced, capped, memskip, budgetskip, enq;
    uint64_t fetched, pf_fail, pf_bytes, expired_bytes, peak_unc;
    uint64_t hint_files, hint_bytes, hint_skip;
    uint64_t res_pages, tot_pages, full_res, meas_files;
    uint64_t hook_ns, hook_calls;
    uint64_t win_issued, win_hits, win_opens;
} S;
#define ADD(f, v) __atomic_add_fetch(&S.f, (v), __ATOMIC_RELAXED)

/* prefetch queue, sorted by due time (JIT) - FIFO when due == now */
typedef struct { uint64_t due; uint32_t id; char *hp; } qitem;
static pthread_mutex_t q_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  q_cv;
static qitem q_buf[QCAP];
static int q_n;

static uint64_t now_us(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000ull + ts.tv_nsec / 1000;
}
static uint64_t now_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + ts.tv_nsec;
}

static void resolve(void)
{
    if (r_open) return;
    r_open     = (open_fn)dlsym(RTLD_NEXT, "open");
    r_open64   = (open_fn)dlsym(RTLD_NEXT, "open64");
    r_openat   = (openat_fn)dlsym(RTLD_NEXT, "openat");
    r_openat64 = (openat_fn)dlsym(RTLD_NEXT, "openat64");
    r_fopen    = (fopen_fn)dlsym(RTLD_NEXT, "fopen");
    r_fopen64  = (fopen_fn)dlsym(RTLD_NEXT, "fopen64");
    r_dlopen   = (dlopen_fn)dlsym(RTLD_NEXT, "dlopen");
    if (!r_open64)   r_open64 = r_open;
    if (!r_openat64) r_openat64 = r_openat;
    if (!r_fopen64)  r_fopen64 = r_fopen;
}

/* ---------------------------------------------------------------- keys */
static int key_from_abs(const char *abs, size_t n, char *out, size_t outsz)
{
    if (n > 10 && !strcmp(abs + n - 10, " (deleted)")) return -1;
    if (g_nroots) {
        for (uint32_t i = 0; i < g_nroots; i++) {
            size_t l = g_rootlen[i];
            if (!strncmp(abs, g_roots[i], l) && abs[l] == '/')
                return snprintf(out, outsz, "@%u%s", i, abs + l) < (int)outsz ? 0 : -1;
        }
        return -1;
    }
    static const char *deny[] = { "/proc/", "/sys/", "/dev/", "/run/", "/lib/", "/lib64/",
                                  "/usr/lib/", "/usr/lib64/", "/etc/ld.so", NULL };
    for (int i = 0; deny[i]; i++)
        if (!strncmp(abs, deny[i], strlen(deny[i]))) return -1;
    return snprintf(out, outsz, "%s", abs) < (int)outsz ? 0 : -1;
}

static int make_key(int fd, char *out, size_t outsz)
{
    char link[64], abs[PATH_MAX];
    snprintf(link, sizeof link, "/proc/self/fd/%d", fd);
    ssize_t n = readlink(link, abs, sizeof abs - 1);
    if (n <= 1) return -1;
    abs[n] = 0;
    if (abs[0] != '/') return -1;                       /* pipe:[..], socket:[..] */
    return key_from_abs(abs, (size_t)n, out, outsz);
}

/* ---------------------------------------------------------------- mem guard */
static int mem_ok(void)
{
    /* shared by all workers: relaxed atomics, a stale answer is harmless */
    static uint64_t last_us; static int last_ok = 1;
    if (!g_memguard) return 1;
    uint64_t now = now_us();
    uint64_t lu = __atomic_load_n(&last_us, __ATOMIC_RELAXED);
    if (lu && now - lu < 200000) return __atomic_load_n(&last_ok, __ATOMIC_RELAXED);
    __atomic_store_n(&last_us, now, __ATOMIC_RELAXED);
    char buf[2048];
    int fd = r_open("/proc/meminfo", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return 1;
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return 1;
    buf[n] = 0;
    const char *a = strstr(buf, "MemAvailable:"), *t = strstr(buf, "MemTotal:");
    if (!a || !t) return 1;
    uint64_t avail = strtoull(a + 13, NULL, 10), total = strtoull(t + 9, NULL, 10);
    uint64_t floor_kb = total * g_mem_floor_pct / 100;
    if (floor_kb < 131072) floor_kb = 131072;
    int ok = (avail >= floor_kb);
    __atomic_store_n(&last_ok, ok, __ATOMIC_RELAXED);
    return ok;
}

/* ---------------------------------------------------------------- worker */
static void drop_state(uint32_t id)
{
    pthread_mutex_lock(&g_lock);
    if (g_st8[id] == 1) g_st8[id] = 0;
    pthread_mutex_unlock(&g_lock);
}

/* g_lock held: retire the oldest ring entry; returns bytes released */
static void ring_pop_locked(void)
{
    ring_ent e = g_ring[g_rhead];
    g_rhead = (g_rhead + 1) % RCAP; g_rcount--;
    if (g_gen[e.id] == e.gen && g_st8[e.id] == 2) {
        g_unc -= g_sz[e.id];
        ADD(expired_bytes, g_sz[e.id]);
        g_sz[e.id] = 0; g_st8[e.id] = 0;
    }
}
static void expire_locked(uint64_t now)
{
    while (g_rcount && now - g_ring[g_rhead].t > g_ttl_us) ring_pop_locked();
}
static void ring_push_locked(uint32_t id, uint64_t now)
{
    if (g_rcount == RCAP) ring_pop_locked();
    g_ring[(g_rhead + g_rcount) % RCAP] = (ring_ent){ id, g_gen[id], now };
    g_rcount++;
}

static uint64_t advise_file(const char *path, int *ok)
{
    *ok = 0;
    int fd = r_open(path, O_RDONLY | O_CLOEXEC | O_NOCTTY | O_NONBLOCK);
    if (fd < 0) return 0;
    struct stat st; uint64_t len = 0;
    if (fstat(fd, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0) {
        len = (uint64_t)st.st_size;
        if (g_maxpf && len > g_maxpf) len = g_maxpf;
        if (g_use_readahead) readahead(fd, 0, (size_t)len);
        else posix_fadvise(fd, 0, (off_t)len, POSIX_FADV_WILLNEED);
        *ok = 1;
    }
    close(fd);
    return len;
}

static void do_prefetch(uint32_t id)
{
    uint64_t now = now_us();
    pthread_mutex_lock(&g_lock);
    if (g_st8[id] != 1) { pthread_mutex_unlock(&g_lock); ADD(moot, 1); return; }
    expire_locked(now);
    int over = g_unc >= g_spec_cap;
    if (over) g_st8[id] = 0;
    pthread_mutex_unlock(&g_lock);
    if (over) { ADD(capped, 1); return; }
    if (!mem_ok()) { drop_state(id); ADD(memskip, 1); return; }
    if (g_budget && S.pf_bytes >= g_budget) { drop_state(id); ADD(budgetskip, 1); return; }

    char path[PATH_MAX];
    if (iio_key_to_path(g_roots, g_nroots, g_m.st.s[id], path, sizeof path)) { drop_state(id); return; }
    int ok;
    uint64_t len = advise_file(path, &ok);
    if (!ok) { drop_state(id); ADD(pf_fail, 1); return; }

    pthread_mutex_lock(&g_lock);
    if (g_st8[id] == 1) {
        g_st8[id] = 2; g_sz[id] = len; g_unc += len;
        if (g_unc > S.peak_unc) S.peak_unc = g_unc;
        ring_push_locked(id, now_us());
        ADD(fetched, 1); ADD(win_issued, 1);
    } else ADD(raced, 1);          /* the app demanded it while we were reading */
    pthread_mutex_unlock(&g_lock);
    ADD(pf_bytes, len);
}

static void do_hint(char *path)
{
    if (!mem_ok()) { ADD(hint_skip, 1); return; }
    if (g_budget && S.pf_bytes + S.hint_bytes >= g_budget) { ADD(hint_skip, 1); return; }
    int ok;
    uint64_t len = advise_file(path, &ok);
    if (ok) { ADD(hint_files, 1); ADD(hint_bytes, len); } else ADD(hint_skip, 1);
}

static void *worker(void *arg)
{
    (void)arg;
    /* stay out of the game's way: idle-ish best-effort IO class + nice 10 */
    syscall(SYS_ioprio_set, 1 /*WHO_PROCESS*/, 0, (2 << 13) | 7);
    setpriority(PRIO_PROCESS, 0, 10);
    t_busy = 1;                      /* never trace our own file accesses */
    for (;;) {
        pthread_mutex_lock(&q_lock);
        for (;;) {
            if (!q_n) { pthread_cond_wait(&q_cv, &q_lock); continue; }
            uint64_t now = now_us();
            if (q_buf[0].due <= now) break;
            struct timespec ts;
            ts.tv_sec = (time_t)(q_buf[0].due / 1000000ull);
            ts.tv_nsec = (long)(q_buf[0].due % 1000000ull) * 1000;
            pthread_cond_timedwait(&q_cv, &q_lock, &ts);
        }
        qitem it = q_buf[0];
        memmove(&q_buf[0], &q_buf[1], (size_t)(q_n - 1) * sizeof(qitem));
        q_n--;
        pthread_mutex_unlock(&q_lock);
        if (it.hp) { do_hint(it.hp); free(it.hp); }
        else do_prefetch(it.id);
    }
    return NULL;
}

static int enqueue(uint32_t id, char *hp, uint64_t due)
{
    int ok = 1;
    pthread_mutex_lock(&q_lock);
    if (q_n < QCAP) {
        int pos = q_n;
        while (pos > 0 && q_buf[pos - 1].due > due) pos--;
        memmove(&q_buf[pos + 1], &q_buf[pos], (size_t)(q_n - pos) * sizeof(qitem));
        q_buf[pos] = (qitem){ due, id, hp };
        q_n++;
        pthread_cond_broadcast(&q_cv);
    } else ok = 0;
    pthread_mutex_unlock(&q_lock);
    return ok;
}

/* called with g_lock held */
static void issue(const iio_cand *c, int n, uint64_t now)
{
    for (int i = 0; i < n; i++) {
        uint32_t id = c[i].id;
        if (id == g_cur) continue;
        uint64_t due = now;
        if (g_jit) {
            double d = (double)c[i].dt_us * g_jit_frac;
            if (d > (double)g_lead_us) due = now + (uint64_t)(d - (double)g_lead_us);
        }
        if (g_st8[id] == 2) continue;                       /* already fetched, not yet used */
        if (g_st8[id] == 1) {                               /* queued: maybe needed sooner now */
            if (due + 1000 < g_due[id]) { g_due[id] = due; enqueue(id, NULL, due); }
            continue;
        }
        if (g_pf_last[id] && now - g_pf_last[id] < g_repf_us) continue;
        g_pf_last[id] = now; g_due[id] = due; g_gen[id]++;
        g_st8[id] = 1;
        if (!enqueue(id, NULL, due)) { g_st8[id] = 0; continue; }
        ADD(enq, 1);
        if (g_verbose)
            fprintf(stderr, "[iio] prefetch %s score=%.2f dist=%.1f due=+%lluus\n",
                    g_m.st.s[id], c[i].score, c[i].dist16 / 16.0, (unsigned long long)(due - now));
    }
}

/* ------------------------------------------------------------ residency */
static void measure_residency(int fd)
{
    struct stat st;
    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0 ||
        st.st_size > (256 << 20)) return;
    long ps = sysconf(_SC_PAGESIZE);
    size_t pages = ((size_t)st.st_size + ps - 1) / ps;
    void *a = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_SHARED, fd, 0);
    if (a == MAP_FAILED) return;
    unsigned char *vec = malloc(pages);
    if (vec && mincore(a, (size_t)st.st_size, vec) == 0) {
        size_t r = 0;
        for (size_t i = 0; i < pages; i++) r += vec[i] & 1;
        ADD(res_pages, r); ADD(tot_pages, pages); ADD(meas_files, 1);
        if (r == pages) ADD(full_res, 1);
    }
    free(vec);
    munmap(a, (size_t)st.st_size);
}

/* ---------------------------------------------------------------- core */
static void on_event_run(const char *key, int fd)
{
    uint32_t id = iio_st_find(&g_m.st, key);
    ADD(opens, 1);
    if (g_resid && fd >= 0) measure_residency(fd);   /* before we touch history */
    if (id == IIO_NONE || id == IIO_START) { ADD(unknown, 1); return; }
    ADD(known, 1);

    uint64_t now = now_us();
    pthread_mutex_lock(&g_lock);
    if (g_st8[id] == 2) {
        ADD(hits, 1); ADD(win_hits, 1);
        g_unc -= g_sz[id]; g_sz[id] = 0;
    } else if (g_st8[id] == 1) ADD(late, 1);         /* predicted, not issued yet */
    g_st8[id] = 0;
    g_prev = g_cur; g_cur = id;
    if (!g_nopf) {
        iio_cand cand[IIO_MAXC];
        int n = iio_predict(&g_m, &g_p, g_prev, g_cur, cand, IIO_MAXC);
        issue(cand, n, now);
    }
    /* overhead governor: tighten threshold when precision drops */
    if (g_adapt && ++S.win_opens >= 64) {
        if (S.win_issued >= 16) {
            double prec = (double)S.win_hits / (double)S.win_issued;
            if (prec < 0.30 && g_p.thr < 0.90) g_p.thr += 0.05;
            else if (prec > 0.75 && g_p.thr > g_thr_floor) g_p.thr -= 0.03;
        }
        S.win_issued = S.win_hits = S.win_opens = 0;
    }
    pthread_mutex_unlock(&g_lock);
}

static void on_event_record(const char *key)
{
    char line[PATH_MAX + 40];
    int n = snprintf(line, sizeof line, "%llu\t%s\n",
                     (unsigned long long)(now_us() - g_t0), key);
    if (n > 0 && n < (int)sizeof line && !memchr(key, '\n', strlen(key)))
        if (write(g_trace_fd, line, (size_t)n) < 0) { /* ignore */ }
    ADD(opens, 1);
}

static void on_timeline(const char *key)
{
    char line[PATH_MAX + 40];
    int n = snprintf(line, sizeof line, "%llu\t%s\n",
                     (unsigned long long)(now_us() - g_t0), key);
    if (n > 0 && n < (int)sizeof line && !memchr(key, '\n', strlen(key)))
        if (write(g_tl_fd, line, (size_t)n) < 0) { /* ignore */ }
}

static void dispatch(const char *key, int fd)
{
    if (g_mode == M_RECORD) on_event_record(key);
    else if (g_mode == M_RUN) {
        if (g_tl_fd >= 0) on_timeline(key);   /* timestamp first: before any prefetch work */
        on_event_run(key, fd);
    }
}

static void note_fd(int fd, int flags)
{
    if (g_mode == M_OFF || g_disabled || fd < 0 || t_busy) return;
    if ((flags & O_ACCMODE) != O_RDONLY || (flags & (O_DIRECTORY | O_PATH | O_CREAT))) return;
    int saved = errno;
    uint64_t t0 = g_stats ? now_ns() : 0;
    t_busy = 1;
    char key[PATH_MAX + 8];
    if (make_key(fd, key, sizeof key) == 0) dispatch(key, fd);
    t_busy = 0;
    if (g_stats) { ADD(hook_ns, now_ns() - t0); ADD(hook_calls, 1); }
    errno = saved;
}

/* ---------------------------------------------------------------- hooks */
#define NEEDS_MODE(fl) (((fl) & O_CREAT) || (((fl) & O_TMPFILE) == O_TMPFILE))

EXPORT int open(const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_open(path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int open64(const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_open64(path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int openat(int dirfd, const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_openat(dirfd, path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int openat64(int dirfd, const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_openat64(dirfd, path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
/* glibc _FORTIFY_SOURCE entry points */
EXPORT int __open_2(const char *p, int f)        { resolve(); int fd = r_open(p, f);        note_fd(fd, f); return fd; }
EXPORT int __open64_2(const char *p, int f)      { resolve(); int fd = r_open64(p, f);      note_fd(fd, f); return fd; }
EXPORT int __openat_2(int d, const char *p, int f)   { resolve(); int fd = r_openat(d, p, f);   note_fd(fd, f); return fd; }
EXPORT int __openat64_2(int d, const char *p, int f) { resolve(); int fd = r_openat64(d, p, f); note_fd(fd, f); return fd; }

static FILE *fopen_common(fopen_fn fn, const char *p, const char *m)
{
    resolve();
    FILE *f = fn(p, m);
    if (f && m && m[0] == 'r' && !strchr(m, '+')) note_fd(fileno(f), O_RDONLY);
    return f;
}
EXPORT FILE *fopen(const char *p, const char *m)   { resolve(); return fopen_common(r_fopen, p, m); }
EXPORT FILE *fopen64(const char *p, const char *m) { resolve(); return fopen_common(r_fopen64, p, m); }

/* Shared objects loaded with dlopen() (plugins, Python extension modules,
 * engine modules). The event is raised BEFORE the load so the prefetch of
 * what follows overlaps with it. ld.so's own dependency loading is not
 * visible to LD_PRELOAD. */
EXPORT void *dlopen(const char *file, int mode)
{
    resolve();
    if (file && g_mode != M_OFF && !g_disabled && !t_busy && strchr(file, '/')) {
        uint64_t t0 = g_stats ? now_ns() : 0;
        t_busy = 1;
        char abs[PATH_MAX], key[PATH_MAX + 8];
        if (realpath(file, abs) && key_from_abs(abs, strlen(abs), key, sizeof key) == 0) {
            ADD(events_dl, 1);
            dispatch(key, -1);
        }
        t_busy = 0;
        if (g_stats) { ADD(hook_ns, now_ns() - t0); ADD(hook_calls, 1); }
    }
    return r_dlopen(file, mode);
}

/* Developer hint: "I will read this file soon." No-op unless run mode is on. */
EXPORT int iio_hint(const char *path)
{
    if (g_mode != M_RUN || g_nopf || g_disabled || !path) return -1;
    char *dup = strdup(path);
    if (!dup) return -1;
    if (!enqueue(IIO_NONE, dup, now_us())) { free(dup); ADD(hint_skip, 1); return -1; }
    return 0;
}

/* ---------------------------------------------------------------- init */
static void parse_roots(const char *list)
{
    char *dup = strdup(list), *save = NULL;
    for (char *tok = strtok_r(dup, ":", &save); tok && g_nroots < IIO_MAX_ROOTS;
         tok = strtok_r(NULL, ":", &save)) {
        char rp[PATH_MAX];
        if (!realpath(tok, rp)) continue;
        size_t l = strlen(rp);
        while (l > 1 && rp[l - 1] == '/') rp[--l] = 0;
        g_roots[g_nroots] = strdup(rp);
        g_rootlen[g_nroots] = l;
        g_nroots++;
    }
    free(dup);
}

static void child_after_fork(void) { g_disabled = 1; }

static void print_stats(void)
{
    if (g_mode == M_RECORD) {
        fprintf(stderr, "[iio] recorded %llu opens (%llu via dlopen) -> %s\n",
                (unsigned long long)S.opens, (unsigned long long)S.events_dl, g_trace_path);
        return;
    }
    if (g_mode != M_RUN || !g_stats) return;
    uint64_t wasted_end = g_unc;
    fprintf(stderr, "[iio] ---- %s ----\n", g_nopf ? "baseline (prefetch OFF)" : "prefetch ON");
    fprintf(stderr, "[iio] events=%llu (dlopen %llu) known=%llu unknown=%llu\n",
            (unsigned long long)S.opens, (unsigned long long)S.events_dl,
            (unsigned long long)S.known, (unsigned long long)S.unknown);
    if (!g_nopf) {
        fprintf(stderr, "[iio] prefetch fetched=%llu used=%llu late=%llu moot=%llu raced=%llu "
                        "precision=%.1f%% coverage=%.1f%% failed=%llu thr_final=%.2f\n",
                (unsigned long long)S.fetched, (unsigned long long)S.hits,
                (unsigned long long)S.late, (unsigned long long)S.moot, (unsigned long long)S.raced,
                S.fetched ? 100.0 * S.hits / S.fetched : 0.0,
                S.known ? 100.0 * S.hits / S.known : 0.0,
                (unsigned long long)S.pf_fail, g_p.thr);
        fprintf(stderr, "[iio] memory: read=%.1f MB peak_unconsumed=%.1f MB wasted=%.1f MB "
                        "(cap %.0f MB) skipped: cap=%llu memguard=%llu budget=%llu\n",
                S.pf_bytes / 1048576.0, S.peak_unc / 1048576.0,
                (S.expired_bytes + wasted_end) / 1048576.0, g_spec_cap / 1048576.0,
                (unsigned long long)S.capped, (unsigned long long)S.memskip,
                (unsigned long long)S.budgetskip);
        if (S.hint_files || S.hint_skip)
            fprintf(stderr, "[iio] hints: files=%llu read=%.1f MB skipped=%llu\n",
                    (unsigned long long)S.hint_files, S.hint_bytes / 1048576.0,
                    (unsigned long long)S.hint_skip);
    }
    fprintf(stderr, "[iio] hook cost on app thread: %.2f us/event (%.2f ms total over %llu)\n",
            S.hook_calls ? S.hook_ns / 1000.0 / S.hook_calls : 0.0, S.hook_ns / 1e6,
            (unsigned long long)S.hook_calls);
    if (S.tot_pages)
        fprintf(stderr, "[iio] page-cache residency at open: %.1f%% of pages, %.1f%% of files fully cached "
                        "(%llu files measured)\n",
                100.0 * S.res_pages / S.tot_pages,
                100.0 * S.full_res / S.meas_files, (unsigned long long)S.meas_files);
    fprintf(stderr, "[iio] STATS events=%llu known=%llu fetched=%llu used=%llu late=%llu moot=%llu "
                    "raced=%llu capped=%llu memskip=%llu pf_mb=%.2f peak_unc_mb=%.2f wasted_mb=%.2f "
                    "hint_files=%llu hook_us=%.3f\n",
            (unsigned long long)S.opens, (unsigned long long)S.known,
            (unsigned long long)S.fetched, (unsigned long long)S.hits,
            (unsigned long long)S.late, (unsigned long long)S.moot, (unsigned long long)S.raced,
            (unsigned long long)S.capped, (unsigned long long)S.memskip,
            S.pf_bytes / 1048576.0, S.peak_unc / 1048576.0,
            (S.expired_bytes + wasted_end) / 1048576.0, (unsigned long long)S.hint_files,
            S.hook_calls ? S.hook_ns / 1000.0 / S.hook_calls : 0.0);
}

static uint64_t env_u64(const char *name, uint64_t dflt)
{
    const char *s = getenv(name);
    return (s && *s) ? (uint64_t)atoll(s) : dflt;
}

static uint64_t mem_available_kb(void)
{
    char buf[2048];
    int fd = r_open("/proc/meminfo", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return 0;
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = 0;
    const char *a = strstr(buf, "MemAvailable:");
    return a ? strtoull(a + 13, NULL, 10) : 0;
}

__attribute__((constructor)) static void iio_init(void)
{
    const char *mode = getenv("IIO_MODE");
    if (!mode || !*mode) return;                 /* inert */
    const char *owner = getenv("IIO_OWNER_PID"); /* ignore spawned subprocesses */
    if (owner && (pid_t)atol(owner) != getpid()) return;
    resolve();
    g_t0 = now_us();
    const char *s;
    if ((s = getenv("IIO_STATS")) && atoi(s)) g_stats = 1;
    if ((s = getenv("IIO_RESIDENCY")) && atoi(s)) g_resid = 1;
    if ((s = getenv("IIO_VERBOSE")) && atoi(s)) g_verbose = 1;

    if (!strcmp(mode, "record")) {
        const char *tp = getenv("IIO_TRACE");
        if (!tp) return;
        if ((s = getenv("IIO_ROOT"))) parse_roots(s);
        g_trace_fd = r_open(tp, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
        if (g_trace_fd < 0) { perror("[iio] cannot open trace"); return; }
        snprintf(g_trace_path, sizeof g_trace_path, "%s", tp);
        char hdr[PATH_MAX + 32];
        int n = snprintf(hdr, sizeof hdr, "#iio1\n");
        if (write(g_trace_fd, hdr, n) < 0) {}
        for (uint32_t i = 0; i < g_nroots; i++) {
            n = snprintf(hdr, sizeof hdr, "#root %u %s\n", i, g_roots[i]);
            if (write(g_trace_fd, hdr, n) < 0) {}
        }
        g_mode = M_RECORD;
    } else if (!strcmp(mode, "run")) {
        const char *mp = getenv("IIO_MODEL");
        if ((s = getenv("IIO_HINTS")) && atoi(s) && !mp) {
            g_hints_only = 1;                    /* no model: only iio_hint() works */
            memset(&g_m, 0, sizeof g_m);
        } else {
            if (!mp || iio_model_load(&g_m, mp)) {
                fprintf(stderr, "[iio] cannot load model '%s'\n", mp ? mp : "(unset)");
                return;
            }
            snprintf(g_model_path, sizeof g_model_path, "%s", mp);
            /* roots: model's, optionally relocated through IIO_ROOT (same count) */
            if ((s = getenv("IIO_ROOT"))) parse_roots(s);
            if (g_nroots != g_m.n_roots) {
                for (uint32_t i = 0; i < g_nroots; i++) free(g_roots[i]);
                g_nroots = 0;
                for (uint32_t i = 0; i < g_m.n_roots; i++) {
                    char rp[PATH_MAX];
                    const char *r = g_m.roots[i] ? g_m.roots[i] : "";
                    if (!realpath(r, rp)) snprintf(rp, sizeof rp, "%s", r);
                    g_roots[i] = strdup(rp); g_rootlen[i] = strlen(rp); g_nroots++;
                }
            }
        }
        if ((s = getenv("IIO_TIMELINE")) && *s) {
            g_tl_fd = r_open(s, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
            if (g_tl_fd >= 0) { if (write(g_tl_fd, "#iio1\n", 6) < 0) {} }
        }
        iio_params_from_env(&g_p);
        g_thr_floor = g_p.thr > 0.30 ? 0.30 : g_p.thr;
        if ((s = getenv("IIO_ADAPT"))) g_adapt = atoi(s);
        if ((s = getenv("IIO_NOPF")) && atoi(s)) g_nopf = 1;
        if ((s = getenv("IIO_METHOD")) && !strcmp(s, "fadvise")) g_use_readahead = 0;
        if ((s = getenv("IIO_JIT"))) g_jit = atoi(s);
        if ((s = getenv("IIO_JIT_FRAC"))) g_jit_frac = atof(s);
        if ((s = getenv("IIO_MEMGUARD"))) g_memguard = atoi(s);
        g_lead_us = env_u64("IIO_LEAD_MS", 30) * 1000;
        g_repf_us = env_u64("IIO_REPF_MS", 5000) * 1000;
        g_ttl_us  = env_u64("IIO_TTL_MS", 30000) * 1000;
        g_budget  = env_u64("IIO_BUDGET_MB", 2048) << 20;
        g_maxpf   = env_u64("IIO_MAXPF_MB", 128) << 20;
        {   /* speculative footprint cap: default MemAvailable/8 in [32,512] MB */
            uint64_t dflt = mem_available_kb() / 1024 / 8;
            if (dflt < 32) dflt = 32;
            if (dflt > 512) dflt = 512;
            g_spec_cap = env_u64("IIO_SPEC_MB", dflt) << 20;
        }
        uint32_t nid = g_m.st.n + 1;
        g_pf_last = calloc(nid, sizeof *g_pf_last);
        g_due     = calloc(nid, sizeof *g_due);
        g_sz      = calloc(nid, sizeof *g_sz);
        g_gen     = calloc(nid, sizeof *g_gen);
        g_st8     = calloc(nid, 1);
        g_mode = M_RUN;
        int nt = (s = getenv("IIO_THREADS")) ? atoi(s) : 2;
        if (nt < 1) nt = 1;
        if (nt > 8) nt = 8;
        if (!g_nopf) {
            pthread_condattr_t ca;
            pthread_condattr_init(&ca);
            pthread_condattr_setclock(&ca, CLOCK_MONOTONIC);
            pthread_cond_init(&q_cv, &ca);
            pthread_attr_t at;
            pthread_attr_init(&at);
            pthread_attr_setstacksize(&at, THREAD_STACK);
            pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
            for (int i = 0; i < nt; i++) {
                pthread_t th;
                pthread_create(&th, &at, worker, NULL);
            }
            /* process start: whatever always opens first */
            if (!g_hints_only) {
                iio_cand cand[IIO_MAXC];
                int n = iio_predict(&g_m, &g_p, IIO_NONE, IIO_START, cand, IIO_MAXC);
                pthread_mutex_lock(&g_lock);
                issue(cand, n, now_us());
                pthread_mutex_unlock(&g_lock);
            }
        }
    }
    pthread_atfork(NULL, NULL, child_after_fork);
}

__attribute__((destructor)) static void iio_fini(void)
{
    if (g_mode == M_OFF || g_disabled) return;
    print_stats();
    if (g_trace_fd >= 0) close(g_trace_fd);
    if (g_tl_fd >= 0) close(g_tl_fd);
}
