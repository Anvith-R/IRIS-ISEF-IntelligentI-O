#pragma once
#include <stddef.h>
#include <stdint.h>

/* Userspace picker. Not a kernel API.
 * Default constants are the author's Fedora fit, Oct 2026.
 * Call adio_calibrate() on another machine before trusting them.
 */
typedef struct {
    double pread_per_ns;
    double preadv_fixed_ns;
    double preadv_per_ns;
    double uring_fixed_ns;
    double uring_per_ns;
} adio_model;

typedef enum { ADIO_PREAD = 1, ADIO_PREADV = 2, ADIO_URING = 3 } adio_path;

void adio_model_default(adio_model *m);
adio_path adio_choose(const adio_model *m, int n, int same_fd);
const char *adio_path_name(adio_path p);
double adio_predict_ns(const adio_model *m, adio_path p, int n, int same_fd);
