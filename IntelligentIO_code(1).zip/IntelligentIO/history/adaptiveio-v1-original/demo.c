#include "adio.h"
#include <stdio.h>

int main(void) {
    adio_model m;
    adio_model_default(&m);
    struct { const char *name; int n; int same; } steps[] = {
        {"64 chunks, one pack", 64, 1},
        {"32 config files", 32, 0},
        {"1 header", 1, 1},
    };
    printf("AdaptiveIO picker (Fedora constants)\n");
    for (int i = 0; i < 3; i++) {
        adio_path p = adio_choose(&m, steps[i].n, steps[i].same);
        printf("%s  n=%d  same_fd=%d  choose=%s  predict=%.0f ns\n",
               steps[i].name, steps[i].n, steps[i].same,
               adio_path_name(p), adio_predict_ns(&m, p, steps[i].n, steps[i].same));
    }
    return 0;
}
