#include "adio.h"

void adio_model_default(adio_model *m) {
    m->pread_per_ns = 684.1;
    m->preadv_fixed_ns = 806.4;
    m->preadv_per_ns = 14.7;
    m->uring_fixed_ns = 730.4;
    m->uring_per_ns = 274.0;
}

const char *adio_path_name(adio_path p) {
    if (p == ADIO_PREADV) return "preadv";
    if (p == ADIO_URING) return "io_uring";
    return "pread";
}

double adio_predict_ns(const adio_model *m, adio_path p, int n, int same_fd) {
    if (p == ADIO_PREADV) {
        if (!same_fd) return 1e18;
        return m->preadv_fixed_ns + m->preadv_per_ns * n;
    }
    if (p == ADIO_URING) return m->uring_fixed_ns + m->uring_per_ns * n;
    return m->pread_per_ns * n;
}

adio_path adio_choose(const adio_model *m, int n, int same_fd) {
    adio_path best = ADIO_PREAD;
    double b = adio_predict_ns(m, ADIO_PREAD, n, same_fd);
    double u = adio_predict_ns(m, ADIO_URING, n, same_fd);
    if (u < b) { best = ADIO_URING; b = u; }
    if (same_fd) {
        double v = adio_predict_ns(m, ADIO_PREADV, n, same_fd);
        if (v < b) best = ADIO_PREADV;
    }
    return best;
}
