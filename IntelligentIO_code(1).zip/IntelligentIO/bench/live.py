#!/usr/bin/env python3
"""
live.py - paired, randomized, cold-cache A/B benchmark for iio.

  sudo python3 bench/live.py gameload [--profile native|hdd|emmc] [--rounds 3] [--seeds 5]
  python3 bench/live.py --help

What it does (and why it is built this way)
  * every run starts from a dropped page cache (needs root) - checked, not assumed
  * conditions are run in randomized order inside each (seed, round) block so
    drift (thermal, background load) hits all conditions equally
  * the same seeds are replayed under every condition -> paired comparison
  * profiles other than `native` put the whole process into a cgroup with a
    read bandwidth/IOPS cap (emulated slow storage). The cap is VERIFIED with a
    timed cold read before any benchmark runs; if it does not bite, the profile
    is skipped rather than reported.
  * reports tail latency (p50/p95/p99/max of per-level load time), CPU seconds,
    peak RSS, and speculative memory (peak unconsumed / wasted MB) per condition,
    with bootstrap 95% CIs on the difference to baseline.
"""
import argparse, csv, os, random, re, shutil, statistics as st, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IIO, LIB3, LIB2 = ROOT / "iio", ROOT / "libiio.so", ROOT / "libiio_bcl2.so"
V1SRC, V1LIB = ROOT / "bench/ref/v1/prefetch_hook.c", ROOT / "bench/ref/v1/libprefetch_v1.so"
GAME = ROOT / "bench/gameload"
PROFILES = {            # name: (read bytes/s, read iops) ; None = no cap
    "native": None,
    "hdd":  (150 * 2**20, 150),
    "emmc": (40 * 2**20, 1000),
}

def sh(cmd, **kw):
    return subprocess.run(cmd, check=True, text=True, capture_output=True, **kw).stdout

def drop_caches():
    os.sync()
    with open("/proc/sys/vm/drop_caches", "w") as f:
        f.write("3\n")

# ---------------------------------------------------------------- cgroups
def block_devs_for(path):
    """Whole-disk 'maj:min' strings under `path`. st_dev is useless on btrfs (anonymous device),
    so go via findmnt, then walk partitions / dm / md slaves up to the physical disks.
    Override with IIO_DEV=/dev/nvme0n1."""
    ov = os.environ.get("IIO_DEV")
    if ov:                      # taken literally: IIO_DEV=/dev/dm-0 throttles the dm device itself
        n = Path(ov).resolve().name
        try: return [(Path("/sys/class/block") / n / "dev").read_text().strip()]
        except OSError: return []
    else:
        src = subprocess.run(["findmnt", "-no", "SOURCE", "-T", str(path)],
                             capture_output=True, text=True).stdout.strip().splitlines()
        src = re.sub(r"\[.*\]$", "", src[0]) if src else ""
        if not src.startswith("/dev/"): return []
        names = [Path(src).resolve().name]
    sysb = Path("/sys/class/block")
    def top(name):
        d = sysb / name
        if not d.exists(): return set()
        if (d / "partition").exists(): return top(d.resolve().parent.name)
        sl = list((d / "slaves").glob("*")) if (d / "slaves").exists() else []
        if sl:
            r = set()
            for x in sl: r |= top(x.name)
            return r
        return {name}
    disks = set()
    for n in names: disks |= top(n)
    out = []
    for n in sorted(disks):
        try: out.append((sysb / n / "dev").read_text().strip())
        except OSError: pass
    return out

class Throttle:
    """cgroup v1 (blkio) or v2 (io.max) read cap for the physical disk(s) under a path."""
    def __init__(self, devs, bps, iops):
        self.path = None
        if not devs:
            print("  cannot find the block device under the data dir (set IIO_DEV=/dev/nvme0n1)"); return
        print(f"  throttling device(s): {', '.join(devs)}")
        v2 = Path("/sys/fs/cgroup/cgroup.controllers")
        try:
            if v2.exists():
                root = Path("/sys/fs/cgroup")
                try: (root / "cgroup.subtree_control").write_text("+io")
                except OSError: pass
                p = root / "iio-bench"; p.mkdir(exist_ok=True)
                for dev in devs: (p / "io.max").write_text(f"{dev} rbps={bps} riops={iops}\n")
                self.path = p
            else:
                p = Path("/sys/fs/cgroup/blkio/iio-bench"); p.mkdir(parents=True, exist_ok=True)
                for dev in devs:
                    (p / "blkio.throttle.read_bps_device").write_text(f"{dev} {bps}\n")
                    (p / "blkio.throttle.read_iops_device").write_text(f"{dev} {iops}\n")
                self.path = p
        except OSError as e:
            print(f"  cannot create throttle cgroup: {e}")
    def enter(self):                       # used as preexec_fn: runs in the child before exec
        if self.path:
            with open(self.path / "cgroup.procs", "w") as f:
                f.write(str(os.getpid()))

def timed_cold_read(path, throttle):
    drop_caches()
    def pre():
        if throttle: throttle.enter()
    t0 = time.perf_counter()
    subprocess.run(["dd", f"if={path}", "of=/dev/null", "bs=1M", "status=none"], preexec_fn=pre, check=True)
    return time.perf_counter() - t0

def validate_profile(name, datadir):
    spec = PROFILES[name]
    if spec is None: return None
    probe = Path(datadir) / ".probe.bin"
    with open(probe, "wb") as f: f.write(os.urandom(64 * 2**20))
    os.sync()
    th = Throttle(block_devs_for(probe), *spec)
    free = timed_cold_read(probe, None)
    capped = timed_cold_read(probe, th) if th.path else 0
    probe.unlink()
    ok = capped > 3 * free and capped > 0.5
    print(f"  profile {name}: 64MB cold read {free:.2f}s uncapped vs {capped:.2f}s capped -> "
          f"{'cap is effective' if ok else 'CAP DOES NOT BITE: profile skipped'}")
    return th if ok else False

# ---------------------------------------------------------------- v1 (user's original hook)
def build_v1_graph(traces, root, out_bin):
    """Re-creates v1's pipeline: first-order graph, prune (min_count 2, min_prob 0.02), pack."""
    import struct
    from collections import defaultdict
    edges = defaultdict(lambda: defaultdict(int))
    for tr in traces:
        seq = []
        for line in open(tr):
            if line.startswith("#") or "\t" not in line: continue
            key = line.rstrip("\n").split("\t", 1)[1]
            seq.append(key.replace("@0", str(root), 1))
        for a, b in zip(seq, seq[1:]): edges[a][b] += 1
    graph = {}
    for a, d in edges.items():
        tot = sum(d.values())
        es = sorted(((b, c / tot) for b, c in d.items() if c >= 2 and c / tot >= 0.02), key=lambda x: -x[1])
        if es: graph[a] = es
    with open(out_bin, "wb") as f:
        f.write(struct.pack("<I", len(graph)))
        for a, es in graph.items():
            ab = a.encode(); f.write(struct.pack("<I", len(ab))); f.write(ab); f.write(struct.pack("<I", len(es)))
            for b, p in es:
                bb = b.encode(); f.write(struct.pack("<I", len(bb))); f.write(bb); f.write(struct.pack("<f", p))
    return len(graph)

# ---------------------------------------------------------------- running one cell
STAT = re.compile(r"\[iio\] STATS (.*)")
def run_cell(cmd, env_extra, throttle):
    env = dict(os.environ); env.update(env_extra)
    env.pop("IIO_OWNER_PID", None)
    out, err = Path("/tmp/iio-live.out"), Path("/tmp/iio-live.err")
    with open(out, "w") as fo, open(err, "w") as fe:
        p = subprocess.Popen(cmd, stdout=fo, stderr=fe, env=env,
                             preexec_fn=(throttle.enter if throttle else None))
        _, status, ru = os.wait4(p.pid, 0)
    res = {"cpu_s": ru.ru_utime + ru.ru_stime, "rss_mb": ru.ru_maxrss / 1024, "rc": os.waitstatus_to_exitcode(status)}
    stats = {}
    m = STAT.search(err.read_text())
    if m:
        for kv in m.group(1).split():
            k, v = kv.split("=", 1)
            try: stats[k] = float(v)
            except ValueError: pass
    loads, startup = [], None
    for line in out.read_text().splitlines():
        t = line.split()
        if t and t[0] == "STARTUP": startup = float(t[1])
        elif t and t[0] == "L": loads.append((int(t[1]), float(t[2]), float(t[3])))
    return res, stats, loads, startup

# ---------------------------------------------------------------- stats helpers
def q(xs, p):
    xs = sorted(xs); k = (len(xs) - 1) * p; lo = int(k); hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)

def boot_diff(a, b, p, n=2000, seed=1):
    """95% CI of q_p(b) - q_p(a) by independent bootstrap."""
    r = random.Random(seed); d = []
    for _ in range(n):
        ra = [r.choice(a) for _ in a]; rb = [r.choice(b) for _ in b]
        d.append(q(rb, p) - q(ra, p))
    d.sort(); return d[int(0.025 * n)], d[int(0.975 * n)]

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("workload", nargs="?", default="gameload", choices=["gameload"])
    ap.add_argument("--profile", default="native", choices=list(PROFILES))
    ap.add_argument("--data", default=str(Path.home() / ".iio-bench"), help="directory on a REAL disk (not tmpfs)")
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--loads", type=int, default=20)
    ap.add_argument("--think-ms", type=int, default=100)
    ap.add_argument("--train", type=int, default=8, help="training sessions to record")
    ap.add_argument("--out", default=str(ROOT / "bench/results"))
    ap.add_argument("--only", default="", help="comma list of condition names")
    ap.add_argument("--env", action="append", default=[], metavar="K=V",
                    help="extra environment for every iio condition (e.g. IIO_THR=0.9); repeatable")
    ap.add_argument("--tag", default="", help="suffix for result file names")
    a = ap.parse_args()
    if os.geteuid() != 0: sys.exit("needs root (drop_caches). Re-run with sudo.")
    for need in (IIO, LIB3, GAME):
        if not need.exists(): sys.exit(f"missing {need}: run `make`")
    data = Path(a.data); gdir = data / "game"; gdir.mkdir(parents=True, exist_ok=True)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    print(f"== iio live benchmark  profile={a.profile}  data={data}  kernel={os.uname().release}")
    th = validate_profile(a.profile, data)
    if th is False: sys.exit("profile not usable on this machine")
    subprocess.run([str(GAME), "create", str(gdir)], check=True, capture_output=True)

    # ---- learn: record k sessions with the real hook (warm cache, no think time)
    tdir = data / "traces"; shutil.rmtree(tdir, ignore_errors=True); tdir.mkdir()
    for s in range(1, a.train + 1):
        subprocess.run([str(IIO), "record", "--root", str(gdir), "--out", str(tdir), "--", str(GAME), "play",
                        str(gdir), str(a.loads), str(s), "0"], check=True, capture_output=True)
        time.sleep(1.1)                       # trace names carry a 1s timestamp
    traces = sorted(tdir.glob("*.trace"))
    man = data / "game.manifest"; man.write_text(sh([str(GAME), "manifest", str(gdir)]))
    models = {}
    def train(name, ts, manifest=False):
        m = data / f"{name}.iiom"
        cmd = [str(IIO), "train", "-o", str(m)] + (["--manifest", str(man)] if manifest else []) + [str(t) for t in ts]
        if manifest and not ts: cmd += ["--root", str(gdir)]
        sh(cmd); models[name] = m
    train("k1", traces[:1]); train("k4", traces[:4]); train("man0", [], True); train("man_k1", traces[:1], True)
    v1bin = data / "v1_graph.bin"; n1 = build_v1_graph(traces[:4], gdir, v1bin)
    if not LIB2.exists() or not V1LIB.exists():
        subprocess.run(["make", "-C", str(ROOT), "libiio_bcl2.so"], check=True, capture_output=True)
        subprocess.run(["gcc", "-shared", "-fPIC", "-O2", "-w", "-o", str(V1LIB), str(V1SRC), "-ldl", "-lpthread"], check=True)

    def iio_env(lib, model, **kv):
        e = {"LD_PRELOAD": str(lib), "IIO_MODE": "run", "IIO_MODEL": str(model), "IIO_STATS": "1"}
        e.update(dict(x.split("=", 1) for x in a.env))
        e.update({k: str(v) for k, v in kv.items()}); return e
    conds = {
        "baseline":      {},
        "v1 (k=4)":      {"LD_PRELOAD": str(V1LIB), "GRAPH_BIN": str(v1bin), "PREFETCH_THRESHOLD": "0.1"},
        "v3/BCL-2 (k=4)": iio_env(LIB2, models["k4"]),
        "BCL-3 (k=1)":   iio_env(LIB3, models["k1"]),
        "BCL-3 (k=4)":   iio_env(LIB3, models["k4"]),
        "BCL-3 JIT (k=4)": iio_env(LIB3, models["k4"], IIO_JIT=1),
        "BCL-3 manifest only (k=0)": iio_env(LIB3, models["man0"]),
        "BCL-3 manifest + k=1": iio_env(LIB3, models["man_k1"]),
    }
    if a.only: conds = {k: v for k, v in conds.items() if k in a.only.split(",")}
    print(f"   models: " + ", ".join(f"{k}={Path(v).stat().st_size}B" for k, v in models.items()) + f", v1 graph nodes={n1}")

    # ---- measure
    rows, loadrows = [], []
    eval_seeds = [100 + i for i in range(a.seeds)]
    for rnd in range(a.rounds):
        for seed in eval_seeds:
            order = list(conds); random.Random(rnd * 1000 + seed).shuffle(order)
            for name in order:
                drop_caches()
                cmd = [str(GAME), "play", str(gdir), str(a.loads), str(seed), str(a.think_ms)]
                res, stats, loads, startup = run_cell(cmd, conds[name], th or None)
                if res["rc"] != 0 or len(loads) != a.loads:
                    print(f"  !! {name} seed={seed}: rc={res['rc']} loads={len(loads)} (run discarded)"); continue
                rows.append(dict(cond=name, round=rnd, seed=seed, startup_ms=startup, **res, **stats))
                for i, (lv, ms, worst) in enumerate(loads):
                    loadrows.append(dict(cond=name, round=rnd, seed=seed, idx=i, level=lv, ms=ms, worst_read_ms=worst))
        print(f"   round {rnd + 1}/{a.rounds} done")
    tag = f"{a.workload}_{a.profile}{a.tag}"
    for fn, rs in ((f"{tag}_runs.csv", rows), (f"{tag}_loads.csv", loadrows)):
        keys = sorted({k for r in rs for k in r}); 
        with open(out / fn, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rs)

    # ---- summarize
    base = [r["ms"] for r in loadrows if r["cond"] == "baseline"]
    print(f"\n== {a.workload} / {a.profile}: per-level load time (ms), pooled over {len(base)} baseline loads\n")
    hdr = f"{'condition':28s} {'p50':>7s} {'p95':>7s} {'p99':>7s} {'max':>7s} | {'d p95 [95% CI]':>22s} {'d p99 [95% CI]':>22s} | {'start ms':>8s} {'cpu s':>6s} {'rss MB':>6s} {'peakspec':>8s} {'waste':>6s}"
    print(hdr); print("-" * len(hdr))
    for name in conds:
        xs = [r["ms"] for r in loadrows if r["cond"] == name]
        rs = [r for r in rows if r["cond"] == name]
        if not xs: continue
        d95 = boot_diff(base, xs, 0.95) if name != "baseline" else (0, 0)
        d99 = boot_diff(base, xs, 0.99) if name != "baseline" else (0, 0)
        m95, m99 = q(xs, .95) - q(base, .95), q(xs, .99) - q(base, .99)
        cell = lambda m, ci: "" if name == "baseline" else f"{m:+7.1f} [{ci[0]:+.1f},{ci[1]:+.1f}]"
        mean = lambda k: st.mean(r.get(k, 0) for r in rs)
        print(f"{name:28s} {q(xs,.5):7.1f} {q(xs,.95):7.1f} {q(xs,.99):7.1f} {max(xs):7.1f} | {cell(m95,d95):>22s} {cell(m99,d99):>22s} | "
              f"{mean('startup_ms'):8.1f} {mean('cpu_s'):6.2f} {mean('rss_mb'):6.1f} {mean('peak_unc_mb'):8.1f} {mean('wasted_mb'):6.1f}")
    print(f"\nraw rows written to {out}/{tag}_*.csv   (runs per condition: {len([r for r in rows if r['cond']=='baseline'])})")

if __name__ == "__main__":
    main()
