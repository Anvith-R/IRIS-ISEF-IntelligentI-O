/* openloop - hook overhead microbenchmark. Opens+closes a fixed cyclic pattern of
 * small files (all warm in cache) so every nanosecond measured is hook cost.
 *   openloop DIR NFILES ITERS   -> prints ns per open+close, CPU seconds, max RSS KB */
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
int main(int argc, char **argv)
{
    if (argc < 4) return 2;
    int nf = atoi(argv[2]); long it = atol(argv[3]); char p[512], b[64];
    mkdir(argv[1], 0755);
    for (int i = 0; i < nf; i++) { snprintf(p, sizeof p, "%s/f%d", argv[1], i); if (access(p, F_OK)) { FILE *f = fopen(p, "wb"); fwrite("0123456789abcdef", 1, 16, f); fclose(f); } }
    for (int i = 0; i < nf; i++) { snprintf(p, sizeof p, "%s/f%d", argv[1], i); int fd = open(p, O_RDONLY); if (fd >= 0) { if (read(fd, b, 16) < 0) {} close(fd); } }
    double t0 = now();
    for (long k = 0; k < it; k++) {
        snprintf(p, sizeof p, "%s/f%ld", argv[1], k % nf);
        int fd = open(p, O_RDONLY); if (fd >= 0) { if (read(fd, b, 16) < 0) {} close(fd); }
    }
    double dt = now() - t0; struct rusage ru; getrusage(RUSAGE_SELF, &ru);
    printf("ns_per_open=%.0f cpu_s=%.3f maxrss_kb=%ld\n", dt / it * 1e9,
           ru.ru_utime.tv_sec + ru.ru_utime.tv_usec / 1e6 + ru.ru_stime.tv_sec + ru.ru_stime.tv_usec / 1e6, ru.ru_maxrss);
    return 0;
}
