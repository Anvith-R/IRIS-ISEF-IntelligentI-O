/* gameload - synthetic level-streaming game for tail-latency benchmarks.
 *
 *   gameload create DIR
 *   gameload play DIR NLOADS SEED THINK_MS
 *   gameload manifest DIR            (prints a developer manifest for iio train --manifest)
 *
 * Every level load opens: shared icons+font (shared by ALL levels -> order-1
 * ambiguity), level meta, atlas, 12 tiles, music. Level order is a branching
 * walk: 70% next level, 15% skip-3, 15% random. Prints "L level ms" per load
 * and a SUMMARY line with p50/p95/p99/max of the per-level load time.
 */
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#define LEVELS 20
#define TILES 12
static char dir[400];
static uint64_t rng;
static uint32_t rnd(void) { rng = rng * 6364136223846793005ULL + 1442695040888963407ULL; return (uint32_t)(rng >> 33); }
static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1e3 + t.tv_nsec / 1e6; }
static void mk(const char *name, size_t sz)
{
    char p[512]; snprintf(p, sizeof p, "%s/%s", dir, name);
    if (access(p, F_OK) == 0) return;
    FILE *f = fopen(p, "wb"); if (!f) { perror(p); exit(1); }
    char *b = malloc(sz); uint64_t x = 0x9E3779B97F4A7C15ull ^ sz;
    for (size_t i = 0; i < sz; i += 8) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; memcpy(b + i, &x, sz - i < 8 ? sz - i : 8); }
    fwrite(b, 1, sz, f); fclose(f); free(b);
}
static size_t slurp(const char *name, int use_fopen)
{
    char p[512], buf[65536]; size_t tot = 0; ssize_t n;
    snprintf(p, sizeof p, "%s/%s", dir, name);
    if (use_fopen) { FILE *f = fopen(p, "rb"); if (!f) return 0; size_t k; while ((k = fread(buf, 1, sizeof buf, f)) > 0) tot += k; fclose(f); }
    else { int fd = open(p, O_RDONLY); if (fd < 0) return 0; while ((n = read(fd, buf, sizeof buf)) > 0) tot += (size_t)n; close(fd); }
    return tot;
}
static void names(int l, char *meta, char *atlas, char *music)
{ sprintf(meta, "level%d.meta", l); sprintf(atlas, "atlas%d.bin", l); sprintf(music, "music%d.ogg", l); }
static int cmpd(const void *a, const void *b) { double x = *(double *)a, y = *(double *)b; return x < y ? -1 : x > y; }
int main(int argc, char **argv)
{
    if (argc < 3) return 2;
    snprintf(dir, sizeof dir, "%s", argv[2]);
    if (!strcmp(argv[1], "create")) {
        mkdir(dir, 0755);
        mk("icons.png", 400000); mk("font.ttf", 900000); mk("menu.meta", 2000); mk("menu.bin", 3000000);
        for (int l = 0; l < LEVELS; l++) {
            char m[64], a[64], s[64], t[64]; names(l, m, a, s);
            mk(m, 4096); mk(a, 2000000); mk(s, 3000000);
            for (int i = 0; i < TILES; i++) { sprintf(t, "tiles%d_%d.bin", l, i); mk(t, 65536u * (1 + i % 4)); }
        }
        printf("created %d levels in %s\n", LEVELS, dir); return 0;
    }
    if (!strcmp(argv[1], "manifest")) {
        printf("# gameload developer manifest: what each level needs, in order\nroot %s\nprior 8\n@start: menu.meta menu.bin font.ttf\n", dir);
        for (int l = 0; l < LEVELS; l++) {
            char m[64], a[64], s[64], nm[64], na[64], ns[64]; names(l, m, a, s); names((l + 1) % LEVELS, nm, na, ns);
            printf("%s: atlas%d.bin tiles%d_*.bin font.ttf music%d.ogg\n", m, l, l, l);
            printf("%s: icons.png %s %s tiles%d_*.bin\n", s, nm, na, (l + 1) % LEVELS);   /* story order: next level */
        }
        return 0;
    }
    int loads = argc > 3 ? atoi(argv[3]) : 20; rng = argc > 4 ? (uint64_t)atoll(argv[4]) * 7919 + 1 : 1;
    int think = argc > 5 ? atoi(argv[5]) : 100;
    double *lat = malloc(sizeof(double) * (loads + 1)); int n = 0;
    double ts = now_ms();
    slurp("menu.meta", 1); slurp("menu.bin", 0); slurp("font.ttf", 1);
    printf("STARTUP %.1f\n", now_ms() - ts);
    int level = 0;
    for (int i = 0; i < loads; i++) {
        usleep(think * 1000);                          /* gameplay */
        uint32_t r = rnd() % 100;
        level = r < 70 ? (level + 1) % LEVELS : r < 85 ? (level + 3) % LEVELS : (int)(rnd() % LEVELS);
        char m[64], a[64], s[64], t[64]; names(level, m, a, s);
        double t0 = now_ms(), worst = 0, f0;
        f0 = now_ms(); slurp("icons.png", 0);                           if (now_ms() - f0 > worst) worst = now_ms() - f0;
        f0 = now_ms(); slurp(m, 1);                                     if (now_ms() - f0 > worst) worst = now_ms() - f0;
        f0 = now_ms(); slurp(a, 0);                                     if (now_ms() - f0 > worst) worst = now_ms() - f0;
        for (int k = 0; k < TILES; k++) { sprintf(t, "tiles%d_%d.bin", level, k); f0 = now_ms(); slurp(t, k & 1); if (now_ms() - f0 > worst) worst = now_ms() - f0; }
        slurp("font.ttf", 1);
        f0 = now_ms(); slurp(s, 0);                                     if (now_ms() - f0 > worst) worst = now_ms() - f0;
        double ms = now_ms() - t0; lat[n++] = ms;
        printf("L %d %.2f %.2f\n", level, ms, worst);
    }
    double tot = 0; for (int i = 0; i < n; i++) tot += lat[i];
    double *s2 = malloc(sizeof(double) * n); memcpy(s2, lat, sizeof(double) * n); qsort(s2, n, sizeof(double), cmpd);
    printf("SUMMARY n=%d mean=%.2f p50=%.2f p95=%.2f p99=%.2f max=%.2f\n", n, tot / n, s2[n / 2], s2[(int)(n * 0.95)], s2[(int)(n * 0.99) < n ? (int)(n * 0.99) : n - 1], s2[n - 1]);
    return 0;
}
