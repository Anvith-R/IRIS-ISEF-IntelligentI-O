#!/usr/bin/env python3
"""Re-run the ORIGINAL v1 benchmark (same replay script, same hook) but with randomized interleaved order,
more trials, and a hook-only control. Usage: sudo python3 bench/v1redo.py PROFILE ROUNDS V1_DIR   (profile: native|hdd|emmc)"""
import os, sys, random, subprocess, statistics as st, csv, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import live
from pathlib import Path
W = Path(sys.argv[3]) if len(sys.argv) > 3 else Path(".")   # your v1 folder (has scripts/ src/ data/)
prof, rounds = sys.argv[1], int(sys.argv[2])
th = None
if prof != "native":
    th = live.validate_profile(prof, W / "data")
    if th is False: sys.exit("profile unusable")
conds = ["baseline", "hook-only (thr 2.0, no prefetch)", "v1 prefetch (thr 0.1)"]
rows = []; random.seed(7)
for rd in range(1, rounds + 1):
    order = conds[:]; random.shuffle(order)
    for pos, c in enumerate(order):
        live.drop_caches()
        env = dict(os.environ)
        if c != "baseline":
            env.update(GRAPH_BIN=str(W / "data/markov_graph.bin"), LD_PRELOAD=str(W / "src/libprefetch_hook.so"),
                       PREFETCH_THRESHOLD="2.0" if c.startswith("hook") else "0.1")
        p = subprocess.run(["python3", str(W / "scripts/replay_session_timed.py")], capture_output=True, text=True,
                           env=env, preexec_fn=(th.enter if th else None))
        m = re.search(r"TOTAL ([0-9.]+)", p.stdout)
        if not m: print("FAILED run", rd, c, p.stderr[-200:]); continue
        rows.append((rd, pos, c, float(m.group(1))))
out = W / f"results/redo_{prof}.csv"
with open(out, "w", newline="") as f:
    w = csv.writer(f); w.writerow(["round", "position", "condition", "total_s"]); w.writerows(rows)
def boot(a, b, n=4000):
    r = random.Random(1); d = []
    for _ in range(n):
        d.append(st.mean(r.choices(a, k=len(a))) - st.mean(r.choices(b, k=len(b))))
    d.sort(); return d[int(.025 * n)], d[int(.975 * n)]
print(f"\n== v1 re-run, profile={prof}, {rounds} randomized rounds ==")
print(f"{'condition':36s} {'n':>3} {'mean ms':>9} {'median':>8} {'stdev':>8} {'min':>7} {'max':>8}")
by = {c: [r[3] * 1000 for r in rows if r[2] == c] for c in conds}
for c in conds:
    v = by[c]; print(f"{c:36s} {len(v):3d} {st.mean(v):9.1f} {st.median(v):8.1f} {st.stdev(v):8.1f} {min(v):7.1f} {max(v):8.1f}")
b = by["baseline"]
for c in conds[1:]:
    v = by[c]; lo, hi = boot(v, b)
    print(f"{c}: mean diff vs baseline {st.mean(v)-st.mean(b):+.1f} ms [95% CI {lo:+.1f}, {hi:+.1f}]; "
          f"median diff {st.median(v)-st.median(b):+.1f} ms; stdev ratio base/this {st.stdev(b)/st.stdev(v):.2f}x")
first = [r[3] * 1000 for r in rows if r[0] == 1]
print("round-1 runs (any condition), ms:", ", ".join(f"{r[2][:8]}={r[3]*1000:.0f}" for r in rows if r[0] == 1))
print("slowest 3 runs:", ", ".join(f"{r[2][:8]} round{r[0]} pos{r[1]}={r[3]*1000:.0f}ms" for r in sorted(rows, key=lambda x: -x[3])[:3]))
