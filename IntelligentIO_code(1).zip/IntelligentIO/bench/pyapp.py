#!/usr/bin/env python3
"""
pyapp.py - real-application cold-start benchmark for iio (no synthetic game).

Each "task" is a python3 process that imports a different mix of large libraries
(pandas, scipy, scikit-learn, matplotlib, flask, lxml ...). They share a big common
core (numpy, stdlib) and diverge afterwards, exactly the situation where a
one-file-back context is ambiguous. iio learns from recorded runs of some tasks
(`--learn`), then every task is run cold under every condition and its WALL TIME is
compared pairwise against the no-prefetch run of the same task and round.
Tasks that were not recorded ("unseen") are reported separately.

  sudo python3 bench/pyapp.py --profile native|hdd|emmc [--rounds 5]
"""
import argparse, os, random, re, shutil, site, statistics as st, subprocess, sys, time, csv
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import live
from live import ROOT, IIO, LIB3, LIB2, V1SRC, V1LIB, drop_caches, validate_profile, run_cell, q

TASKS = {   # name: code (each prints a checksum so we know it really ran)
    "numpy":   "import numpy as np; a=np.random.default_rng(1).random((200,200)); print(round(float(np.linalg.svd(a)[1][0]),3)>0)",
    "pandas":  "import pandas as pd, numpy as np; d=pd.DataFrame({'a':np.arange(1000)%7,'b':np.arange(1000)}); print(len(d.groupby('a').b.sum()))",
    "scipy":   "import scipy.stats as s, scipy.optimize as o; print(round(s.norm.cdf(0),2), o.minimize_scalar(lambda x:(x-1)**2).x>0)",
    "sklearn": "from sklearn.linear_model import LinearRegression as L; import numpy as np; x=np.arange(50.).reshape(-1,1); print(round(L().fit(x,2*x[:,0]).coef_[0],2))",
    "mpl":     "import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as p; f,a=p.subplots(); a.plot([1,2,3]); f.canvas.draw(); print('ok')",
    "flask":   "import flask; a=flask.Flask('x'); print(a.test_client().get('/').status_code)",
    "lxml":    "from lxml import etree; print(len(etree.fromstring('<a><b/><b/></a>')))",
    "stdlib":  "import json,sqlite3,decimal,asyncio,http.client,email.message,xml.dom.minidom,statistics; print(statistics.mean([1,2,3]))",
}
LEARN_DEFAULT = ["numpy", "pandas", "scipy", "mpl"]          # recorded; the rest are 'unseen'

def python_roots():
    roots = []
    for p in sys.path + site.getsitepackages():
        p = os.path.realpath(p)
        if os.path.isdir(p) and p not in roots and not p.endswith(".zip"):
            roots.append(p)
    # keep the 4 largest-prefix-distinct roots (iio supports 4)
    roots = [r for r in roots if r.startswith("/usr")] or roots
    roots = sorted(set(roots), key=len)
    roots = [r for r in roots if not any(r != o and r.startswith(o + '/') for o in roots)]   # drop nested roots
    return roots[:4]

def build_v1_graph(traces, roots, out_bin):
    import struct
    from collections import defaultdict
    edges = defaultdict(lambda: defaultdict(int))
    for tr in traces:
        seq = []
        for line in open(tr):
            if line.startswith("#") or "\t" not in line: continue
            key = line.rstrip("\n").split("\t", 1)[1]
            m = re.match(r"@(\d)(/.*)", key)
            seq.append(roots[int(m.group(1))] + m.group(2) if m else key)
        for a, b in zip(seq, seq[1:]): edges[a][b] += 1
    graph = {}
    for a, d in edges.items():
        tot = sum(d.values())
        es = sorted(((b, c / tot) for b, c in d.items() if c >= 2 and c / tot >= 0.02), key=lambda x: -x[1])
        if es: graph[a] = es
    with open(out_bin, "wb") as f:
        f.write(struct.pack("<I", len(graph)))
        for a, es in graph.items():
            ab = a.encode(); f.write(struct.pack("<I", len(ab))); f.write(ab); f.write(struct.pack("<I", len(es)))
            for b, p in es:
                bb = b.encode(); f.write(struct.pack("<I", len(bb))); f.write(bb); f.write(struct.pack("<f", p))
    return len(graph)

def run_py(code, env_extra, throttle):
    env = dict(os.environ); env.update(env_extra); env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.pop("IIO_OWNER_PID", None)
    out, err = Path("/tmp/iio-py.out"), Path("/tmp/iio-py.err")
    t0 = time.perf_counter()
    with open(out, "w") as fo, open(err, "w") as fe:
        p = subprocess.Popen(["python3", "-c", code], stdout=fo, stderr=fe, env=env,
                             preexec_fn=(throttle.enter if throttle else None))
        _, status, ru = os.wait4(p.pid, 0)
    wall = time.perf_counter() - t0
    stats = {}
    m = re.search(r"\[iio\] STATS (.*)", err.read_text())
    if m:
        for kv in m.group(1).split():
            k, v = kv.split("=", 1)
            try: stats[k] = float(v)
            except ValueError: pass
    return dict(wall_ms=wall * 1000, cpu_s=ru.ru_utime + ru.ru_stime, rss_mb=ru.ru_maxrss / 1024,
                rc=os.waitstatus_to_exitcode(status), out=out.read_text().strip(), **stats)

def boot_mean(xs, n=4000, seed=7):
    r = random.Random(seed); ms = sorted(st.mean(r.choice(xs) for _ in xs) for _ in range(n))
    return ms[int(.025 * n)], ms[int(.975 * n)]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="native", choices=list(live.PROFILES))
    ap.add_argument("--data", default=str(Path.home() / ".iio-bench"))
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--learn", default=",".join(LEARN_DEFAULT), help="tasks to record (comma list)")
    ap.add_argument("--out", default=str(ROOT / "bench/results"))
    a = ap.parse_args()
    if os.geteuid() != 0: sys.exit("needs root (drop_caches)")
    data = Path(a.data); data.mkdir(parents=True, exist_ok=True); out = Path(a.out); out.mkdir(exist_ok=True)
    print(f"== iio pyapp benchmark  profile={a.profile} kernel={os.uname().release} python={sys.version.split()[0]}")
    th = live.validate_profile(a.profile, data)
    if th is False: sys.exit("profile not usable")
    roots = python_roots(); print("   roots:", roots)
    learn = [t for t in a.learn.split(",") if t in TASKS]
    unseen = [t for t in TASKS if t not in learn]
    # verify tasks run at all
    for t, code in list(TASKS.items()):
        r = subprocess.run(["python3", "-c", code], capture_output=True, text=True)
        if r.returncode:
            print(f"   skipping task {t}: {r.stderr.strip().splitlines()[-1] if r.stderr.strip() else 'fails'}")
            del TASKS[t]
    learn = [t for t in learn if t in TASKS]; unseen = [t for t in TASKS if t not in learn]
    if len(learn) < 2 or len(unseen) < 1:
        sys.exit("too few working tasks. Install some, e.g.: sudo dnf install python3-numpy python3-pandas "
                 "python3-scipy python3-matplotlib python3-scikit-learn python3-flask python3-lxml")
    tdir = data / "pytraces"; shutil.rmtree(tdir, ignore_errors=True); tdir.mkdir()
    for t in learn:
        subprocess.run([str(IIO), "record", "--root", ":".join(roots), "--out", str(tdir), "--", "python3", "-c", TASKS[t]],
                       check=True, capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        time.sleep(1.1)
    traces = sorted(tdir.glob("*.trace"), key=lambda p: p.stat().st_mtime)
    print(f"   recorded {len(traces)} sessions ({', '.join(learn)}); unseen at training: {', '.join(unseen)}")
    models = {}
    def train(name, ts):
        m = data / f"py_{name}.iiom"; subprocess.run([str(IIO), "train", "-o", str(m)] + [str(t) for t in ts], check=True, capture_output=True); models[name] = m
    train("k1", traces[:1]); train("kN", traces)
    v1bin = data / "py_v1.bin"; n1 = build_v1_graph(traces, roots, v1bin)
    if not LIB2.exists() or not V1LIB.exists():
        subprocess.run(["make", "-C", str(ROOT), "libiio_bcl2.so"], check=True, capture_output=True)
        subprocess.run(["gcc", "-shared", "-fPIC", "-O2", "-w", "-o", str(V1LIB), str(V1SRC), "-ldl", "-lpthread"], check=True)
    print("   models:", ", ".join(f"{k}={v.stat().st_size}B" for k, v in models.items()), f", v1 graph nodes={n1}")
    def ienv(lib, m, **kv):
        e = {"LD_PRELOAD": str(lib), "IIO_MODE": "run", "IIO_MODEL": str(m), "IIO_STATS": "1", "IIO_ROOT": ":".join(roots)}
        e.update({k: str(v) for k, v in kv.items()}); return e
    k = len(learn)
    conds = {
        "baseline": {},
        f"v1 (k={k})": {"LD_PRELOAD": str(V1LIB), "GRAPH_BIN": str(v1bin), "PREFETCH_THRESHOLD": "0.1"},
        f"v3/BCL-2 (k={k})": ienv(LIB2, models["kN"]),
        "BCL-3 (k=1)": ienv(LIB3, models["k1"]),
        f"BCL-3 (k={k})": ienv(LIB3, models["kN"]),
        f"BCL-3 JIT (k={k})": ienv(LIB3, models["kN"], IIO_JIT=1),
    }
    rows = []
    for rnd in range(a.rounds):
        for task in TASKS:
            order = list(conds); random.Random(rnd * 100 + hash(task) % 97).shuffle(order)
            for name in order:
                drop_caches()
                r = run_py(TASKS[task], conds[name], th or None)
                if r["rc"] != 0: print(f"  !! {name}/{task}: rc={r['rc']}"); continue
                rows.append(dict(cond=name, task=task, seen=int(task in learn), round=rnd, **r))
        print(f"   round {rnd + 1}/{a.rounds} done")
    tag = f"pyapp_{a.profile}"
    keys = sorted({k for r in rows for k in r})
    with open(out / f"{tag}_runs.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)

    base = {(r["task"], r["round"]): r for r in rows if r["cond"] == "baseline"}
    print(f"\n== pyapp / {a.profile}: cold-start wall time, paired against the no-prefetch run of the same task and round\n")
    hdr = f"{'condition':22s} {'base ms':>8s} {'this ms':>8s} | {'rel change, all [95% CI]':>28s} | {'seen':>7s} {'unseen':>7s} | {'cpu x':>6s} {'rss MB':>7s} {'peakspec':>8s} {'waste':>6s}"
    print(hdr); print("-" * len(hdr))
    for name in conds:
        rs = [r for r in rows if r["cond"] == name and (r["task"], r["round"]) in base]
        if not rs: continue
        rel = [(r["wall_ms"] - base[(r["task"], r["round"])]["wall_ms"]) / base[(r["task"], r["round"])]["wall_ms"] for r in rs]
        relseen = [x for x, r in zip(rel, rs) if r["seen"]]; relun = [x for x, r in zip(rel, rs) if not r["seen"]]
        b_ms = st.mean(base[(r["task"], r["round"])]["wall_ms"] for r in rs); t_ms = st.mean(r["wall_ms"] for r in rs)
        cpu = st.mean(r["cpu_s"] / base[(r["task"], r["round"])]["cpu_s"] for r in rs)
        lo, hi = boot_mean(rel)
        f = lambda v: f"{100 * st.mean(v):+6.1f}%" if v else "     - "
        cell = "" if name == "baseline" else f"{100 * st.mean(rel):+6.1f}% [{100 * lo:+.1f}, {100 * hi:+.1f}]"
        print(f"{name:22s} {b_ms:8.0f} {t_ms:8.0f} | {cell:>28s} | {f(relseen) if name != 'baseline' else '':>7s} {f(relun) if name != 'baseline' else '':>7s} | "
              f"{cpu:6.2f} {st.mean(r['rss_mb'] for r in rs):7.1f} {st.mean(r.get('peak_unc_mb', 0) for r in rs):8.1f} {st.mean(r.get('wasted_mb', 0) for r in rs):6.1f}")
    print(f"\nper-task median wall ms (baseline -> BCL-3 k={k}):")
    for t in TASKS:
        b = [r["wall_ms"] for r in rows if r["cond"] == "baseline" and r["task"] == t]
        c = [r["wall_ms"] for r in rows if r["cond"] == f"BCL-3 (k={k})" and r["task"] == t]
        if b and c: print(f"  {t:8s} {'(seen)  ' if t in learn else '(unseen)'} {st.median(b):7.0f} -> {st.median(c):7.0f} ms")
    print(f"\nraw rows: {out}/{tag}_runs.csv   runs per condition: {len([r for r in rows if r['cond']=='baseline'])}")

if __name__ == "__main__":
    main()
