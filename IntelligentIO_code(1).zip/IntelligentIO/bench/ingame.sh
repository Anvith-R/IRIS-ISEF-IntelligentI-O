#!/usr/bin/env bash
# ingame.sh - blind A/B of IN-GAME load times with iio, using the game's own file activity as the clock.
#
#   bench/ingame.sh --model m.iiom --root /usr/share/supertux2 [--rounds 3] [--gap-ms 300] \
#                   [--min-events 5] [--out DIR] [--yes] -- supertux2
#
# Run it as your normal user (the game must not run as root). It asks for sudo only to clear the page cache.
# Each round runs the game twice in random order: once with prefetching OFF and once ON, with the same
# model loaded in both so the only difference is the prefetching. Which run was which is hidden until the end.
# Every run: do the SAME actions (e.g. launch, start the same world and level, wait for it to load, quit).
# Load time = duration of a burst of file opens (first to last), taken from `iio run --timeline`, so
# it does not depend on a stopwatch. See `iio loads` for how bursts are defined.
set -euo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd); IIO="$HERE/iio"
MODEL=""; ROOT=""; ROUNDS=3; GAP=300; MINEV=5; OUT=""; YES=0
die() { echo "ingame.sh: $*" >&2; exit 1; }
while [ $# -gt 0 ]; do case "$1" in
  --model) MODEL=$2; shift 2;; --root) ROOT=$2; shift 2;; --rounds) ROUNDS=$2; shift 2;;
  --gap-ms) GAP=$2; shift 2;; --min-events) MINEV=$2; shift 2;; --out) OUT=$2; shift 2;;
  --yes) YES=1; shift;; --) shift; break;; *) die "unknown option $1";; esac; done
[ -n "$MODEL" ] && [ -n "$ROOT" ] && [ $# -gt 0 ] || die "usage: ingame.sh --model M --root R [--rounds N] -- game [args]"
[ -x "$IIO" ] || die "build first: make"
[ -f "$MODEL" ] || die "no such model: $MODEL"
CMD=("$@"); NAME=$(basename "${CMD[0]}")
OUT=${OUT:-ingame-$(date +%Y%m%d-%H%M%S)}; mkdir -p "$OUT"; : > "$OUT/.key"
dropc() { if [ "$(id -u)" -eq 0 ]; then sync; echo 3 > /proc/sys/vm/drop_caches
          else sudo sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches'; fi; }
[ "$(id -u)" -eq 0 ] || sudo -v
n=0; total=$((ROUNDS * 2))
for r in $(seq 1 "$ROUNDS"); do
  if [ $((RANDOM % 2)) -eq 0 ]; then order="base iio"; else order="iio base"; fi
  for cond in $order; do
    n=$((n + 1))
    pgrep -x "$NAME" >/dev/null 2>&1 && die "$NAME is already running; close it first"
    echo; echo "== run $n of $total: do your fixed routine, wait for the level to load, then quit the game =="
    [ "$YES" -eq 1 ] || read -r -p "Press Enter to start (the cache is cleared first)... " _
    dropc
    fl=""; [ "$cond" = base ] && fl="--baseline"
    "$IIO" run --model "$MODEL" --root "$ROOT" $fl --timeline "$OUT/run$n.tl" -- "${CMD[@]}" \
        >"$OUT/run$n.log" 2>&1 || echo "(game exited with an error; see $OUT/run$n.log)"
    echo "run$n $cond" >> "$OUT/.key"
  done
done
echo; echo "== results (which run was which is revealed now) =="
args=()
for want in base iio; do          # baseline group first, so the comparison reads "iio vs base"
  while read -r f c; do [ "$c" = "$want" ] && args+=("$c:$OUT/$f.tl"); done < "$OUT/.key"
done
"$IIO" loads --gap-ms "$GAP" --min-events "$MINEV" "${args[@]}"
echo; echo "key: $(tr '\n' ' ' < "$OUT/.key")"
echo "timelines are in $OUT/ (send the lines above, or the whole folder)"
