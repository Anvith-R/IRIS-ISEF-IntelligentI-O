/*
 * iio - developer-invoked front end for IntelligentI/O.
 *
 *   iio record [--root R[:R2]] [--out DIR] -- cmd args...
 *   iio train  -o model.iiom [--window N] [--burst-us N] [--min-count N]
 *              [--max-edges N] trace...
 *   iio run    --model m.iiom [--root R] [--stats] [--baseline] [--verbose]
 *              [--thr X] [--depth N] [--order 1|2] [--threads N]
 *              [--budget-mb N] [--method readahead|fadvise] -- cmd args...
 *   iio eval   [--model m.iiom] [--horizon N] trace...     (no --model: leave-one-out)
 *   iio evict  --model m.iiom [--root R]
 *   iio inspect model.iiom
 *   iio bench  --model m.iiom [--runs N] [--no-evict] [--root R] -- cmd args...
 *
 * Nothing here installs anything or stays resident: the helper library is
 * injected only into the one process tree started by `record`/`run`/`bench`.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "iio_common.h"

static void die(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    fprintf(stderr, "iio: "); vfprintf(stderr, fmt, ap); fprintf(stderr, "\n");
    va_end(ap); exit(1);
}

static double now_s(void)
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static void usage(void)
{
    fputs(
"iio - IntelligentI/O (BCL-2 file-open predictor)\n\n"
"  iio record [--root R[:R2]] [--out DIR] -- cmd...   record one play session\n"
"  iio train  -o model.iiom [--window N] [--burst-us N] [--min-count N]\n"
"             [--max-edges N] trace...                build the model\n"
"  iio eval   [--model m] [--horizon N] trace...      offline accuracy (leave-one-out)\n"
"  iio run    --model m [--stats] [--baseline] [--verbose] [--root R]\n"
"             [--thr X] [--depth N] [--order 1|2] [--threads N]\n"
"             [--budget-mb N] [--method readahead|fadvise] -- cmd...\n"
"  iio evict  --model m [--root R]                    drop modeled files from page cache\n"
"  iio bench  --model m [--runs N] [--no-evict] -- cmd...   A/B wall-clock (cmd must exit)\n"
"  iio inspect model\n", stderr);
    exit(2);
}

/* ------------------------------------------------------------ helpers */
static const char *find_lib(char *buf, size_t n)
{
    const char *e = getenv("IIO_LIB");
    if (e) return e;
    ssize_t k = readlink("/proc/self/exe", buf, n - 1);
    if (k > 0) {
        buf[k] = 0;
        char *d = dirname(buf);
        char tmp[PATH_MAX];
        snprintf(tmp, sizeof tmp, "%s/libiio.so", d);
        if (access(tmp, R_OK) == 0) { snprintf(buf, n, "%s", tmp); return buf; }
    }
    if (access("./libiio.so", R_OK) == 0) { snprintf(buf, n, "./libiio.so"); return buf; }
    die("cannot find libiio.so (set IIO_LIB)");
    return NULL;
}

static void set_preload(void)
{
    char buf[PATH_MAX];
    const char *lib = find_lib(buf, sizeof buf);
    char full[PATH_MAX];
    if (!realpath(lib, full)) die("libiio.so: %s", strerror(errno));
    const char *old = getenv("LD_PRELOAD");
    char val[2 * PATH_MAX + 2];
    if (old && *old) snprintf(val, sizeof val, "%s:%s", full, old);
    else snprintf(val, sizeof val, "%s", full);
    setenv("LD_PRELOAD", val, 1);
}

static int run_cmd(char **argv, int quiet, double *wall)
{
    double t0 = now_s();
    fflush(NULL);
    pid_t pid = fork();
    if (pid < 0) die("fork: %s", strerror(errno));
    if (pid == 0) {
        if (getenv("IIO_MODE")) {            /* only this pid (and its exec chain) is instrumented */
            char ob[32]; snprintf(ob, sizeof ob, "%d", (int)getpid());
            setenv("IIO_OWNER_PID", ob, 1);
        }
        if (quiet) {
            int dn = open("/dev/null", O_WRONLY);
            if (dn >= 0) { dup2(dn, 1); dup2(dn, 2); }
        }
        execvp(argv[0], argv);
        fprintf(stderr, "iio: exec %s: %s\n", argv[0], strerror(errno));
        _exit(127);
    }
    int st = 0;
    while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {}
    if (wall) *wall = now_s() - t0;
    return WIFEXITED(st) ? WEXITSTATUS(st) : 128 + WTERMSIG(st);
}

static char **after_dashdash(int argc, char **argv, int *stop)
{
    for (int i = 0; i < argc; i++)
        if (!strcmp(argv[i], "--")) { *stop = i; return argv + i + 1; }
    *stop = argc;
    return NULL;
}

#define NEED_ARG() do { if (++i >= argc) usage(); } while (0)

/* ------------------------------------------------------------ record */
static int cmd_record(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *root = NULL, *out = "iio-traces";
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; }
        else if (!strcmp(argv[i], "--out")) { NEED_ARG(); out = argv[i]; }
        else usage();
    }
    mkdir(out, 0755);
    char *tmp = strdup(cmd[0]);
    char path[PATH_MAX];
    snprintf(path, sizeof path, "%s/%s.%ld.%d.trace", out, basename(tmp), (long)time(NULL), (int)getpid());
    setenv("IIO_MODE", "record", 1);
    setenv("IIO_TRACE", path, 1);
    if (root) setenv("IIO_ROOT", root, 1);
    set_preload();
    int rc = run_cmd(cmd, 0, NULL);
    fprintf(stderr, "iio: trace written to %s (exit %d)\n", path, rc);
    return rc;
}

/* ------------------------------------------------------------ train */
static int cmd_train(int argc, char **argv)
{
    const char *out = NULL; int window = 8, burst = 5000, min_cnt = 1, max_edges = 24;
    int nfiles = 0; char **files = calloc(argc, sizeof *files);
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-o")) { NEED_ARG(); out = argv[i]; }
        else if (!strcmp(argv[i], "--window")) { NEED_ARG(); window = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--burst-us")) { NEED_ARG(); burst = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--min-count")) { NEED_ARG(); min_cnt = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--max-edges")) { NEED_ARG(); max_edges = atoi(argv[i]); }
        else files[nfiles++] = argv[i];
    }
    if (!out || !nfiles) usage();
    iio_trainer *T = iio_trainer_new(window, burst);
    size_t events = 0;
    for (int i = 0; i < nfiles; i++) {
        iio_trace *t = iio_trace_load(files[i]);
        if (!t) die("cannot read %s", files[i]);
        events += t->n;
        iio_trainer_add(T, t);
        iio_trace_free(t);
    }
    iio_model m;
    iio_trainer_finish(T, min_cnt, max_edges, &m);
    if (iio_model_save(&m, out)) die("cannot write %s", out);
    struct stat st; stat(out, &st);
    printf("trained on %d session(s), %zu opens -> %u files, %u contexts, %u edges, %lld bytes\n",
           nfiles, events, m.st.n - 1, m.n_ctx, m.n_edges, (long long)st.st_size);
    iio_model_free(&m); iio_trainer_free(T);
    return 0;
}

/* ------------------------------------------------------------ eval */
typedef struct { const char *name; iio_params p; } variant;
typedef struct { long opens, known, hits, issued; } evres;

static void eval_trace(const iio_model *m, const iio_params *p, const iio_trace *tr,
                       int horizon, evres *r)
{
    long *pred_at = malloc(m->st.n * sizeof *pred_at);
    for (uint32_t i = 0; i < m->st.n; i++) pred_at[i] = -1;
    uint32_t prev = IIO_NONE, cur = IIO_START;
    iio_cand cand[IIO_MAXC];
    long k = 0;
    int n = iio_predict(m, p, prev, cur, cand, IIO_MAXC);
    for (int i = 0; i < n; i++) { pred_at[cand[i].id] = 0; r->issued++; }
    for (size_t e = 0; e < tr->n; e++) {
        r->opens++;
        uint32_t id = iio_st_find(&m->st, tr->key[e]);
        if (id == IIO_NONE || id == IIO_START) continue;
        k++; r->known++;
        if (pred_at[id] >= 0 && k - pred_at[id] <= horizon) r->hits++;
        pred_at[id] = -1;
        prev = cur; cur = id;
        n = iio_predict(m, p, prev, cur, cand, IIO_MAXC);
        for (int i = 0; i < n; i++) {
            uint32_t c = cand[i].id;
            if (pred_at[c] < 0 || k - pred_at[c] > horizon) { pred_at[c] = k; r->issued++; }
        }
    }
    free(pred_at);
}

static int cmd_eval(int argc, char **argv)
{
    const char *model = NULL; int horizon = 16, nfiles = 0, window = 8, burst = 5000;
    char **files = calloc(argc, sizeof *files);
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--horizon")) { NEED_ARG(); horizon = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--window")) { NEED_ARG(); window = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--burst-us")) { NEED_ARG(); burst = atoi(argv[i]); }
        else files[nfiles++] = argv[i];
    }
    if (!nfiles || (!model && nfiles < 2)) usage();

    variant v[4];
    for (int i = 0; i < 4; i++) iio_params_from_env(&v[i].p);
    v[0].name = "order-1, next-file only (approx. step-3 baseline)";
    v[0].p.use_o2 = 0; v[0].p.depth = 0; v[0].p.max_dist16 = 16; v[0].p.beta = 0;
    v[1].name = "order-1 + lookahead window (Griffioen-Appleton)";
    v[1].p.use_o2 = 0; v[1].p.depth = 0; v[1].p.beta = 0;
    v[2].name = "order-2 blend + lookahead";
    v[2].p.use_o2 = 1; v[2].p.depth = 0; v[2].p.beta = 0;
    v[3].name = "BCL-2: order-2 + burst bonus + chaining";

    iio_trace **tr = calloc(nfiles, sizeof *tr);
    for (int i = 0; i < nfiles; i++)
        if (!(tr[i] = iio_trace_load(files[i]))) die("cannot read %s", files[i]);

    evres res[4]; memset(res, 0, sizeof res);
    if (model) {
        iio_model m;
        if (iio_model_load(&m, model)) die("cannot load %s", model);
        for (int a = 0; a < 4; a++)
            for (int i = 0; i < nfiles; i++) eval_trace(&m, &v[a].p, tr[i], horizon, &res[a]);
        iio_model_free(&m);
        printf("evaluating on %d trace(s) with model %s (NOT held out: optimistic)\n", nfiles, model);
    } else {
        for (int hold = 0; hold < nfiles; hold++) {
            iio_trainer *T = iio_trainer_new(window, burst);
            for (int i = 0; i < nfiles; i++) if (i != hold) iio_trainer_add(T, tr[i]);
            iio_model m; iio_trainer_finish(T, 1, 24, &m);
            for (int a = 0; a < 4; a++) eval_trace(&m, &v[a].p, tr[hold], horizon, &res[a]);
            iio_model_free(&m); iio_trainer_free(T);
        }
        printf("leave-one-out over %d traces (each trace predicted by a model that never saw it)\n", nfiles);
    }
    printf("hit = file opened within %d opens after being predicted\n\n", horizon);
    printf("%-52s %9s %10s %12s\n", "variant", "coverage", "precision", "issued/open");
    for (int a = 0; a < 4; a++) {
        printf("%-52s %8.1f%% %9.1f%% %12.2f\n", v[a].name,
               res[a].known ? 100.0 * res[a].hits / res[a].known : 0.0,
               res[a].issued ? 100.0 * res[a].hits / res[a].issued : 0.0,
               res[a].known ? (double)res[a].issued / res[a].known : 0.0);
    }
    for (int i = 0; i < nfiles; i++) iio_trace_free(tr[i]);
    return 0;
}

/* ------------------------------------------------------------ evict / inspect */
static int do_evict(const iio_model *m, const char *root_override)
{
    char *roots[IIO_MAX_ROOTS] = { 0 }; uint32_t nr = m->n_roots;
    for (uint32_t i = 0; i < nr; i++) roots[i] = m->roots[i];
    char *dup = NULL;
    if (root_override) {
        dup = strdup(root_override);
        char *save; uint32_t i = 0;
        for (char *t = strtok_r(dup, ":", &save); t && i < IIO_MAX_ROOTS; t = strtok_r(NULL, ":", &save)) roots[i++] = t;
        nr = i;
    }
    int done = 0;
    for (uint32_t id = 1; id < m->st.n; id++) {
        char p[PATH_MAX];
        if (iio_key_to_path(roots, nr, m->st.s[id], p, sizeof p)) continue;
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        fdatasync(fd);                       /* dirty pages are skipped by DONTNEED */
        posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
        close(fd); done++;
    }
    free(dup);
    return done;
}

static int cmd_evict(int argc, char **argv)
{
    const char *model = NULL, *root = NULL;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; }
        else usage();
    }
    if (!model) usage();
    iio_model m; if (iio_model_load(&m, model)) die("cannot load %s", model);
    int n = do_evict(&m, root);
    printf("evicted %d file(s) from page cache (clean, unmapped pages only; for a full cold start also run:\n"
           "  sync; echo 3 | sudo tee /proc/sys/vm/drop_caches )\n", n);
    iio_model_free(&m);
    return 0;
}

static int cmd_inspect(int argc, char **argv)
{
    if (argc < 1) usage();
    iio_model m; if (iio_model_load(&m, argv[0])) die("cannot load %s", argv[0]);
    struct stat st; stat(argv[0], &st);
    printf("model %s: %lld bytes, %u files, %u contexts (%u edges), window=%u burst_gap=%uus\n",
           argv[0], (long long)st.st_size, m.st.n - 1, m.n_ctx, m.n_edges, m.window, m.burst_gap_us);
    for (uint32_t i = 0; i < m.n_roots; i++) printf("root @%u = %s\n", i, m.roots[i]);
    /* show the most frequently seen order-2 context and its predictions */
    int best = -1;
    for (uint32_t i = 0; i < m.n_ctx; i++)
        if (m.ctx[i].b != IIO_NONE && (best < 0 || m.ctx[i].total > m.ctx[best].total)) best = (int)i;
    if (best >= 0) {
        const iio_ctx *c = &m.ctx[best];
        printf("\nbusiest order-2 context (%s -> %s), seen %u times:\n", m.st.s[c->a], m.st.s[c->b], c->total);
        for (uint32_t k = 0; k < c->n && k < 8; k++) {
            const iio_edge *e = &m.edges[c->first + k];
            printf("   %5.1f%%  dist=%4.1f  dt=%7uus  same-burst=%3u%%  %s\n",
                   100.0 * e->cnt / c->total, e->dist16 / 16.0, e->dt_us,
                   100u * e->bcnt / e->cnt, m.st.s[e->to]);
        }
    }
    iio_model_free(&m);
    return 0;
}

/* ------------------------------------------------------------ run / bench */
static void apply_run_opt(const char *k, const char *v)
{
    if (!strcmp(k, "--thr")) setenv("IIO_THR", v, 1);
    else if (!strcmp(k, "--depth")) setenv("IIO_DEPTH", v, 1);
    else if (!strcmp(k, "--order")) setenv("IIO_ORDER", v, 1);
    else if (!strcmp(k, "--threads")) setenv("IIO_THREADS", v, 1);
    else if (!strcmp(k, "--budget-mb")) setenv("IIO_BUDGET_MB", v, 1);
    else if (!strcmp(k, "--method")) setenv("IIO_METHOD", v, 1);
    else if (!strcmp(k, "--root")) setenv("IIO_ROOT", v, 1);
    else usage();
}

static int cmd_run(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *model = NULL;
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--stats")) setenv("IIO_STATS", "1", 1);
        else if (!strcmp(argv[i], "--baseline")) { setenv("IIO_NOPF", "1", 1); setenv("IIO_STATS", "1", 1); }
        else if (!strcmp(argv[i], "--verbose")) setenv("IIO_VERBOSE", "1", 1);
        else { const char *k = argv[i]; NEED_ARG(); apply_run_opt(k, argv[i]); }
    }
    if (!model) usage();
    char mp[PATH_MAX]; if (!realpath(model, mp)) die("%s: %s", model, strerror(errno));
    setenv("IIO_MODE", "run", 1);
    setenv("IIO_MODEL", mp, 1);
    set_preload();
    double w; int rc = run_cmd(cmd, 0, &w);
    fprintf(stderr, "iio: wall time %.3fs (exit %d)\n", w, rc);
    return rc;
}

static int cmp_d(const void *a, const void *b) { double x = *(double *)a, y = *(double *)b; return x < y ? -1 : x > y; }

static int cmd_bench(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *model = NULL; int runs = 5, evict = 1;
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--runs")) { NEED_ARG(); runs = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--no-evict")) evict = 0;
        else { const char *k = argv[i]; NEED_ARG(); apply_run_opt(k, argv[i]); }
    }
    if (!model) usage();
    char mp[PATH_MAX]; if (!realpath(model, mp)) die("%s: %s", model, strerror(errno));
    iio_model m; if (iio_model_load(&m, mp)) die("cannot load %s", mp);
    const char *root = getenv("IIO_ROOT");
    double *a = calloc(runs, sizeof *a), *b = calloc(runs, sizeof *b);
    for (int r = 0; r < runs; r++) {
        if (evict) do_evict(&m, root);
        unsetenv("IIO_MODE");
        run_cmd(cmd, 1, &a[r]);
        if (evict) do_evict(&m, root);
        setenv("IIO_MODE", "run", 1); setenv("IIO_MODEL", mp, 1); set_preload();
        run_cmd(cmd, 1, &b[r]);
        unsetenv("LD_PRELOAD");
        printf("run %d: baseline %.3fs   iio %.3fs\n", r + 1, a[r], b[r]);
    }
    double sa[runs], sb[runs];
    memcpy(sa, a, sizeof sa); memcpy(sb, b, sizeof sb);
    qsort(sa, runs, sizeof(double), cmp_d); qsort(sb, runs, sizeof(double), cmp_d);
    double ma = sa[runs / 2], mb = sb[runs / 2];
    printf("\nmedian: baseline %.3fs  iio %.3fs  -> %.1f%% %s\n", ma, mb,
           100.0 * fabs(ma - mb) / ma, mb < ma ? "faster" : "slower");
    iio_model_free(&m);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2) usage();
    const char *c = argv[1]; argc -= 2; argv += 2;
    if (!strcmp(c, "record")) return cmd_record(argc, argv);
    if (!strcmp(c, "train")) return cmd_train(argc, argv);
    if (!strcmp(c, "eval")) return cmd_eval(argc, argv);
    if (!strcmp(c, "run")) return cmd_run(argc, argv);
    if (!strcmp(c, "evict")) return cmd_evict(argc, argv);
    if (!strcmp(c, "inspect")) return cmd_inspect(argc, argv);
    if (!strcmp(c, "bench")) return cmd_bench(argc, argv);
    usage();
    return 2;
}
