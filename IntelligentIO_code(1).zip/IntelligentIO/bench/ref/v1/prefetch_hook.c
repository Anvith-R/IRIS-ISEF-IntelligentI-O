/*
 * prefetch_hook.c
 *
 * LD_PRELOAD shim implementing Markov-graph-based inter-file prefetching.
 *
 * On every open()/openat() call:
 *   1. Let the real open happen (so the program is never blocked/broken)
 *   2. Look up the just-opened file in a precomputed transition table
 *      (loaded once at startup from a flat binary file built by
 *      src/export_graph_bin.py from markov_graph.json)
 *   3. For each predicted next file above a probability threshold, call
 *      posix_fadvise(fd, 0, 0, POSIX_FADV_WILLNEED) to hint the kernel to
 *      prefetch it into page cache *before* the program actually asks for it
 *
 * This is the userspace, no-kernel-patch version of "rewriting readahead for
 * inter-file access" - it works entirely through the standard POSIX fadvise
 * hint interface, just driven by a learned graph instead of a human-supplied
 * hint or single-file sequential heuristic.
 *
 * Table format (binary, little-endian, produced by export_graph_bin.py):
 *   uint32_t   n_entries
 *   repeated n_entries times:
 *     uint32_t   src_path_len
 *     char       src_path[src_path_len]      (no null terminator)
 *     uint32_t   n_next
 *     repeated n_next times:
 *       uint32_t dst_path_len
 *       char     dst_path[dst_path_len]
 *       float    prob
 *
 * Build:
 *   gcc -shared -fPIC -o libprefetch_hook.so prefetch_hook.c -ldl -lpthread
 *
 * Use:
 *   GRAPH_BIN=/path/to/graph.bin PREFETCH_THRESHOLD=0.3 \
 *     LD_PRELOAD=./libprefetch_hook.so ./your_program
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <pthread.h>
#include <stdint.h>
#include <stdarg.h>

#define MAX_ENTRIES 200000
#define MAX_NEXT_PER_ENTRY 16

typedef struct {
    char dst[PATH_MAX];
    float prob;
} NextEdge;

typedef struct {
    char src[PATH_MAX];
    int n_next;
    NextEdge next[MAX_NEXT_PER_ENTRY];
} GraphEntry;

static GraphEntry *g_entries = NULL;
static int g_n_entries = 0;
static float g_threshold = 0.15f;

static int (*real_open)(const char *pathname, int flags, ...) = NULL;
static int (*real_openat)(int dirfd, const char *pathname, int flags, ...) = NULL;

static pthread_mutex_t init_mutex = PTHREAD_MUTEX_INITIALIZER;
static int initialized = 0;

/* simple linear scan lookup - fine for a few thousand nodes; a real
 * production version would hash this, left as documented future work */
static GraphEntry *find_entry(const char *path) {
    for (int i = 0; i < g_n_entries; i++) {
        if (strcmp(g_entries[i].src, path) == 0) {
            return &g_entries[i];
        }
    }
    return NULL;
}

static void load_graph(const char *bin_path) {
    FILE *f = fopen(bin_path, "rb");
    if (!f) {
        fprintf(stderr, "[prefetch_hook] could not open graph bin %s\n", bin_path);
        return;
    }
    uint32_t n_entries = 0;
    fread(&n_entries, sizeof(uint32_t), 1, f);
    if (n_entries > MAX_ENTRIES) n_entries = MAX_ENTRIES;

    g_entries = calloc(n_entries, sizeof(GraphEntry));
    g_n_entries = 0;

    for (uint32_t i = 0; i < n_entries; i++) {
        uint32_t src_len = 0;
        if (fread(&src_len, sizeof(uint32_t), 1, f) != 1) break;
        if (src_len >= PATH_MAX) { fseek(f, src_len, SEEK_CUR); continue; }
        fread(g_entries[g_n_entries].src, 1, src_len, f);
        g_entries[g_n_entries].src[src_len] = '\0';

        uint32_t n_next = 0;
        fread(&n_next, sizeof(uint32_t), 1, f);
        int keep = n_next < MAX_NEXT_PER_ENTRY ? n_next : MAX_NEXT_PER_ENTRY;
        g_entries[g_n_entries].n_next = keep;

        for (uint32_t j = 0; j < n_next; j++) {
            uint32_t dst_len = 0;
            fread(&dst_len, sizeof(uint32_t), 1, f);
            char dst_buf[PATH_MAX];
            if (dst_len >= PATH_MAX) {
                fseek(f, dst_len, SEEK_CUR);
                dst_buf[0] = '\0';
            } else {
                fread(dst_buf, 1, dst_len, f);
                dst_buf[dst_len] = '\0';
            }
            float prob = 0.0f;
            fread(&prob, sizeof(float), 1, f);
            if ((int)j < keep) {
                strncpy(g_entries[g_n_entries].next[j].dst, dst_buf, PATH_MAX - 1);
                g_entries[g_n_entries].next[j].prob = prob;
            }
        }
        g_n_entries++;
    }
    fclose(f);
    fprintf(stderr, "[prefetch_hook] loaded %d graph nodes\n", g_n_entries);
}

static void ensure_init(void) {
    if (initialized) return;
    pthread_mutex_lock(&init_mutex);
    if (!initialized) {
        real_open = dlsym(RTLD_NEXT, "open");
        real_openat = dlsym(RTLD_NEXT, "openat");

        const char *bin_path = getenv("GRAPH_BIN");
        if (bin_path) load_graph(bin_path);

        const char *thresh_env = getenv("PREFETCH_THRESHOLD");
        if (thresh_env) g_threshold = strtof(thresh_env, NULL);

        initialized = 1;
    }
    pthread_mutex_unlock(&init_mutex);
}

/* Called after a file is opened: look up predicted successors and issue
 * posix_fadvise(WILLNEED) on each above the probability threshold. */
static void predictive_prefetch(const char *opened_path) {
    char abspath[PATH_MAX];
    const char *key = opened_path;
    if (opened_path[0] != '/' && realpath(opened_path, abspath)) {
        key = abspath;
    }
    GraphEntry *e = find_entry(key);
    if (!e) return;

    for (int i = 0; i < e->n_next; i++) {
        if (e->next[i].prob < g_threshold) continue;
        int fd = real_open(e->next[i].dst, O_RDONLY);
        if (fd >= 0) {
            posix_fadvise(fd, 0, 0, POSIX_FADV_WILLNEED);
            close(fd);
        }
    }
}

int open(const char *pathname, int flags, ...) {
    ensure_init();
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
    }
    int fd = real_open(pathname, flags, mode);
    if (fd >= 0) predictive_prefetch(pathname);
    return fd;
}

int openat(int dirfd, const char *pathname, int flags, ...) {
    ensure_init();
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = va_arg(args, mode_t);
        va_end(args);
    }
    int fd = real_openat(dirfd, pathname, flags, mode);
    if (fd >= 0) predictive_prefetch(pathname);
    return fd;
}
