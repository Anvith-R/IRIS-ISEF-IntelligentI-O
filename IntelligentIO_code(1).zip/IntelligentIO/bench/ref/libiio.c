/*
 * libiio.so - LD_PRELOAD interposer.  Does NOTHING unless IIO_MODE is set,
 * and IIO_MODE is only set by `iio record` / `iio run` for the one process
 * the developer launches.
 *
 *   IIO_MODE=record  : append "<t_us>\t<file key>" for every successful
 *                      read-only open (open/openat/fopen families).
 *   IIO_MODE=run     : load model, on every open predict what comes next and
 *                      hand file ids to low-priority worker threads that call
 *                      readahead()/posix_fadvise(WILLNEED).
 *
 * Environment (all optional, normally set by the iio CLI):
 *   IIO_TRACE, IIO_MODEL, IIO_ROOT (colon list), IIO_STATS=1, IIO_NOPF=1,
 *   IIO_THREADS, IIO_BUDGET_MB, IIO_MAXPF_MB, IIO_METHOD=readahead|fadvise,
 *   IIO_ADAPT=0|1, IIO_REPF_MS, IIO_VERBOSE, IIO_THR/IIO_DEPTH/IIO_ORDER...
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#include "iio_common.h"

#define EXPORT __attribute__((visibility("default")))
#define QCAP 2048

typedef int (*open_fn)(const char *, int, ...);
typedef int (*openat_fn)(int, const char *, int, ...);
typedef FILE *(*fopen_fn)(const char *, const char *);

static open_fn   r_open, r_open64;
static openat_fn r_openat, r_openat64;
static fopen_fn  r_fopen, r_fopen64;

enum { M_OFF = 0, M_RECORD = 1, M_RUN = 2 };
static volatile int g_mode;
static volatile int g_disabled;           /* set in forked children */
static __thread int t_busy;

static uint64_t g_t0;
static int      g_trace_fd = -1;
static char     g_trace_path[PATH_MAX];

static char    *g_roots[IIO_MAX_ROOTS];
static size_t   g_rootlen[IIO_MAX_ROOTS];
static uint32_t g_nroots;

/* run-mode state */
static iio_model  g_m;
static iio_params g_p;
static double     g_thr_floor;
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
static uint32_t   g_prev = IIO_NONE, g_cur = IIO_START;
static uint64_t  *g_pf_last;
static uint8_t   *g_pf_pend;
static int  g_nopf, g_stats, g_adapt = 1, g_verbose, g_use_readahead = 1;
static uint64_t g_repf_us = 5000000, g_budget, g_maxpf;
static char g_model_path[PATH_MAX];

static struct {
    uint64_t opens, known, unknown, hits, issued, dropped, pf_files, pf_bytes, pf_fail;
    uint64_t res_pages, tot_pages, full_res, meas_files;
    uint64_t win_issued, win_hits, win_opens;
} S;
#define ADD(f, v) __atomic_add_fetch(&S.f, (v), __ATOMIC_RELAXED)

/* prefetch queue */
static pthread_mutex_t q_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  q_cv = PTHREAD_COND_INITIALIZER;
static uint32_t q_buf[QCAP];
static int q_head, q_n;

static uint64_t now_us(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000ull + ts.tv_nsec / 1000;
}

static void resolve(void)
{
    if (r_open) return;
    r_open     = (open_fn)dlsym(RTLD_NEXT, "open");
    r_open64   = (open_fn)dlsym(RTLD_NEXT, "open64");
    r_openat   = (openat_fn)dlsym(RTLD_NEXT, "openat");
    r_openat64 = (openat_fn)dlsym(RTLD_NEXT, "openat64");
    r_fopen    = (fopen_fn)dlsym(RTLD_NEXT, "fopen");
    r_fopen64  = (fopen_fn)dlsym(RTLD_NEXT, "fopen64");
    if (!r_open64)   r_open64 = r_open;
    if (!r_openat64) r_openat64 = r_openat;
    if (!r_fopen64)  r_fopen64 = r_fopen;
}

/* ---------------------------------------------------------------- keys */
static int make_key(int fd, char *out, size_t outsz)
{
    char link[64], abs[PATH_MAX];
    snprintf(link, sizeof link, "/proc/self/fd/%d", fd);
    ssize_t n = readlink(link, abs, sizeof abs - 1);
    if (n <= 1) return -1;
    abs[n] = 0;
    if (abs[0] != '/') return -1;                       /* pipe:[..], socket:[..] */
    if (n > 10 && !strcmp(abs + n - 10, " (deleted)")) return -1;

    if (g_nroots) {
        for (uint32_t i = 0; i < g_nroots; i++) {
            size_t l = g_rootlen[i];
            if (!strncmp(abs, g_roots[i], l) && abs[l] == '/')
                return snprintf(out, outsz, "@%u%s", i, abs + l) < (int)outsz ? 0 : -1;
        }
        return -1;
    }
    static const char *deny[] = { "/proc/", "/sys/", "/dev/", "/run/", "/lib/", "/lib64/",
                                  "/usr/lib/", "/usr/lib64/", "/etc/ld.so", NULL };
    for (int i = 0; deny[i]; i++)
        if (!strncmp(abs, deny[i], strlen(deny[i]))) return -1;
    return snprintf(out, outsz, "%s", abs) < (int)outsz ? 0 : -1;
}

/* ---------------------------------------------------------------- worker */
static void do_prefetch(uint32_t id)
{
    char path[PATH_MAX];
    if (iio_key_to_path(g_roots, g_nroots, g_m.st.s[id], path, sizeof path)) return;
    if (g_budget && S.pf_bytes >= g_budget) return;
    int fd = r_open(path, O_RDONLY | O_CLOEXEC | O_NOCTTY);
    if (fd < 0) { ADD(pf_fail, 1); return; }
    struct stat st;
    if (fstat(fd, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0) {
        uint64_t len = (uint64_t)st.st_size;
        if (g_maxpf && len > g_maxpf) len = g_maxpf;
        if (g_use_readahead) readahead(fd, 0, (size_t)len);
        else posix_fadvise(fd, 0, (off_t)len, POSIX_FADV_WILLNEED);
        ADD(pf_files, 1); ADD(pf_bytes, len);
    }
    close(fd);
}

static void *worker(void *arg)
{
    (void)arg;
    /* stay out of the game's way: lowest best-effort IO class + nice 10 */
    syscall(SYS_ioprio_set, 1 /*WHO_PROCESS*/, 0, (2 << 13) | 7);
    setpriority(PRIO_PROCESS, 0, 10);
    for (;;) {
        pthread_mutex_lock(&q_lock);
        while (!q_n) pthread_cond_wait(&q_cv, &q_lock);
        uint32_t id = q_buf[q_head];
        q_head = (q_head + 1) % QCAP; q_n--;
        pthread_mutex_unlock(&q_lock);
        t_busy = 1;
        do_prefetch(id);
    }
    return NULL;
}

static void enqueue(uint32_t id)
{
    pthread_mutex_lock(&q_lock);
    if (q_n < QCAP) { q_buf[(q_head + q_n) % QCAP] = id; q_n++; pthread_cond_signal(&q_cv); }
    else ADD(dropped, 1);
    pthread_mutex_unlock(&q_lock);
}

/* called with g_lock held */
static void issue(const iio_cand *c, int n, uint64_t now)
{
    for (int i = 0; i < n; i++) {
        uint32_t id = c[i].id;
        if (id == g_cur) continue;
        if (g_pf_last[id] && now - g_pf_last[id] < g_repf_us) continue;
        g_pf_last[id] = now; g_pf_pend[id] = 1;
        ADD(issued, 1); ADD(win_issued, 1);
        if (g_verbose)
            fprintf(stderr, "[iio] prefetch %s score=%.2f dist=%.1f\n",
                    g_m.st.s[id], c[i].score, c[i].dist16 / 16.0);
        enqueue(id);
    }
}

/* ------------------------------------------------------------ residency */
static void measure_residency(int fd)
{
    struct stat st;
    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0 ||
        st.st_size > (256 << 20)) return;
    long ps = sysconf(_SC_PAGESIZE);
    size_t pages = ((size_t)st.st_size + ps - 1) / ps;
    void *a = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_SHARED, fd, 0);
    if (a == MAP_FAILED) return;
    unsigned char *vec = malloc(pages);
    if (vec && mincore(a, (size_t)st.st_size, vec) == 0) {
        size_t r = 0;
        for (size_t i = 0; i < pages; i++) r += vec[i] & 1;
        ADD(res_pages, r); ADD(tot_pages, pages); ADD(meas_files, 1);
        if (r == pages) ADD(full_res, 1);
    }
    free(vec);
    munmap(a, (size_t)st.st_size);
}

/* ---------------------------------------------------------------- core */
static void on_open_run(const char *key, int fd)
{
    uint32_t id = iio_st_find(&g_m.st, key);
    ADD(opens, 1);
    if (g_stats) measure_residency(fd);        /* before we touch history */
    if (id == IIO_NONE || id == IIO_START) { ADD(unknown, 1); return; }
    ADD(known, 1);

    uint64_t now = now_us();
    pthread_mutex_lock(&g_lock);
    if (g_pf_pend[id]) { g_pf_pend[id] = 0; ADD(hits, 1); ADD(win_hits, 1); }
    g_prev = g_cur; g_cur = id;
    if (!g_nopf) {
        iio_cand cand[IIO_MAXC];
        int n = iio_predict(&g_m, &g_p, g_prev, g_cur, cand, IIO_MAXC);
        issue(cand, n, now);
    }
    /* overhead governor: tighten threshold when precision drops */
    if (g_adapt && ++S.win_opens >= 64) {
        if (S.win_issued >= 16) {
            double prec = (double)S.win_hits / (double)S.win_issued;
            if (prec < 0.30 && g_p.thr < 0.90) g_p.thr += 0.05;
            else if (prec > 0.75 && g_p.thr > g_thr_floor) g_p.thr -= 0.03;
        }
        S.win_issued = S.win_hits = S.win_opens = 0;
    }
    pthread_mutex_unlock(&g_lock);
}

static void on_open_record(const char *key)
{
    char line[PATH_MAX + 40];
    int n = snprintf(line, sizeof line, "%llu\t%s\n",
                     (unsigned long long)(now_us() - g_t0), key);
    if (n > 0 && n < (int)sizeof line && !memchr(key, '\n', strlen(key)))
        if (write(g_trace_fd, line, (size_t)n) < 0) { /* ignore */ }
    ADD(opens, 1);
}

static void note_fd(int fd, int flags)
{
    if (g_mode == M_OFF || g_disabled || fd < 0 || t_busy) return;
    if ((flags & O_ACCMODE) != O_RDONLY || (flags & (O_DIRECTORY | O_PATH | O_CREAT))) return;
    int saved = errno;
    t_busy = 1;
    char key[PATH_MAX + 8];
    if (make_key(fd, key, sizeof key) == 0) {
        if (g_mode == M_RECORD) on_open_record(key);
        else if (g_mode == M_RUN) on_open_run(key, fd);
    }
    t_busy = 0;
    errno = saved;
}

/* ---------------------------------------------------------------- hooks */
#define NEEDS_MODE(fl) (((fl) & O_CREAT) || (((fl) & O_TMPFILE) == O_TMPFILE))

EXPORT int open(const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_open(path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int open64(const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_open64(path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int openat(int dirfd, const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_openat(dirfd, path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
EXPORT int openat64(int dirfd, const char *path, int flags, ...)
{
    mode_t mode = 0;
    if (NEEDS_MODE(flags)) { va_list ap; va_start(ap, flags); mode = va_arg(ap, mode_t); va_end(ap); }
    resolve();
    int fd = r_openat64(dirfd, path, flags, mode);
    note_fd(fd, flags);
    return fd;
}
/* glibc _FORTIFY_SOURCE entry points */
EXPORT int __open_2(const char *p, int f)        { resolve(); int fd = r_open(p, f);        note_fd(fd, f); return fd; }
EXPORT int __open64_2(const char *p, int f)      { resolve(); int fd = r_open64(p, f);      note_fd(fd, f); return fd; }
EXPORT int __openat_2(int d, const char *p, int f)   { resolve(); int fd = r_openat(d, p, f);   note_fd(fd, f); return fd; }
EXPORT int __openat64_2(int d, const char *p, int f) { resolve(); int fd = r_openat64(d, p, f); note_fd(fd, f); return fd; }

static FILE *fopen_common(fopen_fn fn, const char *p, const char *m)
{
    resolve();
    FILE *f = fn(p, m);
    if (f && m && m[0] == 'r' && !strchr(m, '+')) note_fd(fileno(f), O_RDONLY);
    return f;
}
EXPORT FILE *fopen(const char *p, const char *m)   { resolve(); return fopen_common(r_fopen, p, m); }
EXPORT FILE *fopen64(const char *p, const char *m) { resolve(); return fopen_common(r_fopen64, p, m); }

/* ---------------------------------------------------------------- init */
static void parse_roots(const char *list)
{
    char *dup = strdup(list), *save = NULL;
    for (char *tok = strtok_r(dup, ":", &save); tok && g_nroots < IIO_MAX_ROOTS;
         tok = strtok_r(NULL, ":", &save)) {
        char rp[PATH_MAX];
        if (!realpath(tok, rp)) continue;
        size_t l = strlen(rp);
        while (l > 1 && rp[l - 1] == '/') rp[--l] = 0;
        g_roots[g_nroots] = strdup(rp);
        g_rootlen[g_nroots] = l;
        g_nroots++;
    }
    free(dup);
}

static void child_after_fork(void) { g_disabled = 1; }

static void print_stats(void)
{
    if (g_mode == M_RECORD) {
        fprintf(stderr, "[iio] recorded %llu opens -> %s\n",
                (unsigned long long)S.opens, g_trace_path);
        return;
    }
    if (g_mode != M_RUN || !g_stats) return;
    fprintf(stderr, "[iio] ---- %s ----\n", g_nopf ? "baseline (prefetch OFF)" : "prefetch ON");
    fprintf(stderr, "[iio] opens=%llu known=%llu unknown=%llu\n",
            (unsigned long long)S.opens, (unsigned long long)S.known,
            (unsigned long long)S.unknown);
    if (!g_nopf) {
        fprintf(stderr, "[iio] prefetch issued=%llu used=%llu precision=%.1f%% coverage=%.1f%% "
                        "read=%.1f MB failed=%llu dropped=%llu thr_final=%.2f\n",
                (unsigned long long)S.issued, (unsigned long long)S.hits,
                S.issued ? 100.0 * S.hits / S.issued : 0.0,
                S.known ? 100.0 * S.hits / S.known : 0.0,
                S.pf_bytes / 1048576.0, (unsigned long long)S.pf_fail,
                (unsigned long long)S.dropped, g_p.thr);
    }
    if (S.tot_pages)
        fprintf(stderr, "[iio] page-cache residency at open: %.1f%% of pages, %.1f%% of files fully cached "
                        "(%llu files measured)\n",
                100.0 * S.res_pages / S.tot_pages,
                100.0 * S.full_res / S.meas_files, (unsigned long long)S.meas_files);
}

__attribute__((constructor)) static void iio_init(void)
{
    const char *mode = getenv("IIO_MODE");
    if (!mode || !*mode) return;                 /* inert */
    const char *owner = getenv("IIO_OWNER_PID"); /* ignore spawned subprocesses */
    if (owner && (pid_t)atol(owner) != getpid()) return;
    resolve();
    g_t0 = now_us();
    const char *s;
    if ((s = getenv("IIO_STATS")) && atoi(s)) g_stats = 1;
    if ((s = getenv("IIO_VERBOSE")) && atoi(s)) g_verbose = 1;

    if (!strcmp(mode, "record")) {
        const char *tp = getenv("IIO_TRACE");
        if (!tp) return;
        if ((s = getenv("IIO_ROOT"))) parse_roots(s);
        g_trace_fd = r_open(tp, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
        if (g_trace_fd < 0) { perror("[iio] cannot open trace"); return; }
        snprintf(g_trace_path, sizeof g_trace_path, "%s", tp);
        char hdr[PATH_MAX + 32];
        int n = snprintf(hdr, sizeof hdr, "#iio1\n");
        if (write(g_trace_fd, hdr, n) < 0) {}
        for (uint32_t i = 0; i < g_nroots; i++) {
            n = snprintf(hdr, sizeof hdr, "#root %u %s\n", i, g_roots[i]);
            if (write(g_trace_fd, hdr, n) < 0) {}
        }
        g_mode = M_RECORD;
    } else if (!strcmp(mode, "run")) {
        const char *mp = getenv("IIO_MODEL");
        if (!mp || iio_model_load(&g_m, mp)) { fprintf(stderr, "[iio] cannot load model '%s'\n", mp ? mp : "(unset)"); return; }
        snprintf(g_model_path, sizeof g_model_path, "%s", mp);
        /* roots: model's, optionally relocated through IIO_ROOT (same count) */
        if ((s = getenv("IIO_ROOT"))) parse_roots(s);
        if (g_nroots != g_m.n_roots) {
            for (uint32_t i = 0; i < g_nroots; i++) free(g_roots[i]);
            g_nroots = 0;
            for (uint32_t i = 0; i < g_m.n_roots; i++) {
                char rp[PATH_MAX];
                const char *r = g_m.roots[i] ? g_m.roots[i] : "";
                if (!realpath(r, rp)) snprintf(rp, sizeof rp, "%s", r);
                g_roots[i] = strdup(rp); g_rootlen[i] = strlen(rp); g_nroots++;
            }
        }
        iio_params_from_env(&g_p);
        g_thr_floor = g_p.thr > 0.30 ? 0.30 : g_p.thr;
        if ((s = getenv("IIO_ADAPT"))) g_adapt = atoi(s);
        if ((s = getenv("IIO_NOPF")) && atoi(s)) g_nopf = 1;
        if ((s = getenv("IIO_METHOD")) && !strcmp(s, "fadvise")) g_use_readahead = 0;
        if ((s = getenv("IIO_REPF_MS"))) g_repf_us = (uint64_t)atol(s) * 1000;
        g_budget = (uint64_t)((s = getenv("IIO_BUDGET_MB")) ? atol(s) : 2048) << 20;
        g_maxpf  = (uint64_t)((s = getenv("IIO_MAXPF_MB")) ? atol(s) : 128) << 20;
        g_pf_last = calloc(g_m.st.n, sizeof *g_pf_last);
        g_pf_pend = calloc(g_m.st.n, 1);
        g_mode = M_RUN;
        int nt = (s = getenv("IIO_THREADS")) ? atoi(s) : 2;
        if (nt < 1) nt = 1;
        if (nt > 8) nt = 8;
        if (!g_nopf) {
            for (int i = 0; i < nt; i++) {
                pthread_t th;
                if (pthread_create(&th, NULL, worker, NULL) == 0) pthread_detach(th);
            }
            /* process start: whatever always opens first */
            iio_cand cand[IIO_MAXC];
            int n = iio_predict(&g_m, &g_p, IIO_NONE, IIO_START, cand, IIO_MAXC);
            pthread_mutex_lock(&g_lock);
            issue(cand, n, now_us());
            pthread_mutex_unlock(&g_lock);
        }
    }
    pthread_atfork(NULL, NULL, child_after_fork);
}

__attribute__((destructor)) static void iio_fini(void)
{
    if (g_mode == M_OFF || g_disabled) return;
    print_stats();
    if (g_trace_fd >= 0) close(g_trace_fd);
}
