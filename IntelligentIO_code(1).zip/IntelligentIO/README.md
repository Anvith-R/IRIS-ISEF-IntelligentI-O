# iio — IntelligentI/O  (v0.3, algorithm BCL-3)

A **developer-invoked** file-open predictor and prefetcher for Linux. It learns which
files a program opens after which, optionally primed by a hand-written manifest, and asks
the kernel to read the likely next files early. Nothing is installed system-wide and
nothing stays resident: `libiio.so` is injected with `LD_PRELOAD` into the one process
you launch with `iio run`; child processes are ignored.

Not a database tool (databases manage their own cache), not for single-archive games,
and of no use where storage is already as fast as RAM for your workload — `iio doctor`
tells you which case you are in.

## Build
    sudo dnf install gcc make        # or: apt install build-essential
    make                             # -> ./iio  ./libiio.so  + bench helpers
    sudo make install                # optional: /usr/local/bin/iio, lib/iio/libiio.so, man page

## First, check that measuring is even meaningful on this machine
    ./iio doctor --dir ~             # NOT /tmp on Fedora (tmpfs). Use sudo for the drop_caches test.

## Workflow
    ROOT=/path/to/game/data
    ./iio record --root $ROOT --out traces -- ./mygame          # 3-6 varied sessions
    ./iio train -o game.iiom traces/*.trace                     # counting, < 1 s
    ./iio eval traces/*.trace                                   # leave-one-out accuracy
    ./iio curve --ks 1,2,4 traces/*.trace                       # accuracy vs sessions learned
    sudo ./iio bench --model game.iiom --runs 5 -- ./mygame     # cold-cache A/B (cmd must exit)
    ./iio run --model game.iiom --stats -- ./mygame             # interactive run with stats

### Developer manifest (works with zero recordings)
    ./iio train -o game.iiom --manifest game.manifest --root $ROOT      # manifest only
    ./iio train -o game.iiom --manifest game.manifest traces/*.trace    # manifest + learning
See `examples/supertux.manifest` and `man iio`. Declared edges are pseudo-counts, so
recorded evidence out-votes a wrong declaration.

### In-code hint (optional, header-only)
    #include <iio_hint.h>
    iio_hint_file("assets/level7/atlas.bin");   // no-op unless run under `iio run`

## Safety rails (all enforced off the application thread)
| Rail | Default |
| --- | --- |
| speculative bytes resident-but-unconsumed | min(512 MB, MemAvailable/8), floor 32 MB (`--spec-mb`) |
| guess time-to-live | 30 s |
| memory guard | no prefetch while MemAvailable < max(128 MB, 8% RAM) |
| per-file / total bytes | 128 MB / 2 GB |
| precision governor | threshold rises when < 30% of fetches are used |
| deadline-aware issue | off; `--jit` delays fetches to about when they are needed |
| worker threads | 2, I/O class best-effort 7, nice 10, 128 KB stacks |

`--stats` prints fetched/used/late/wasted bytes, peak unconsumed bytes and the hook's
cost per event on exit.

## Benchmarks
    sudo python3 bench/live.py gameload --profile native --data ~/.iio-bench
    sudo python3 bench/live.py gameload --profile hdd    --data ~/.iio-bench   # emulated slow disk
`live.py` drops caches before every run, randomizes condition order, replays identical
seeds under every condition, verifies that an emulated-disk cap really slows a timed read
(otherwise it refuses to report), and prints p50/p95/p99/max with bootstrap CIs, CPU, RSS
and speculative memory. Raw rows go to `bench/results/*.csv`.

## Limits
* Sees libc `open/openat/fopen/dlopen`. Not seen: static binaries, raw syscalls, io_uring,
  Flatpak/sandboxed apps, ld.so's own dependency loading, Wine/Proton paths.
* Whole-file readahead (capped). No offset-level prediction inside archives.
* Emulated slow storage (cgroup caps) models bandwidth/IOPS limits, not seek latency.
* Linux + glibc only. Tested on x86-64.

## Replaying a real recording (`iio replay`)

Games that cannot exit on their own cannot be timed by `iio bench`. Record a few sessions
(`iio record`), then:

    sudo ./iio replay --root /usr/share/supertux2 --runs 3 traces/*.trace
    sudo ./iio replay --root /usr/share/supertux2 --manifest examples/supertux.manifest traces/*.trace

Each trace is replayed with a cold page cache, with and without the prefetcher, using a model
trained on the *other* traces. It prints per-load stall (summed open+read time of a burst of
opens) and the paired change in total I/O stall. It reads each file whole and does not pause
inside a load, so it is conservative for the prefetcher but is not the game itself.
Needs at least 2 traces; `sudo` is needed to drop the cache.

## In-game load times (`bench/ingame.sh`)

    cd iio && make
    ./iio train -o st.iiom --root /usr/share/supertux2 traces/*.trace
    bench/ingame.sh --model st.iiom --root /usr/share/supertux2 --rounds 3 -- supertux2

Run it as your normal user. Each round launches the game twice in random order (prefetch off,
then on, same model loaded in both), clears the page cache first, and hides which run was which
until the end. Do the same actions every run. Load time is the first-to-last-open duration of a
burst of opens, taken from `iio run --timeline`, not from a stopwatch. `iio loads` prints it.
Use a model trained on earlier recordings, not on the runs being tested.

Author: github.com/Anvith-R

## AdaptiveIO (`adio/`)

A small library that issues a *known list* of cached reads with the cheapest of: pread loop,
merged pread/preadv, io_uring. It merges file-adjacent requests, then picks using constants
calibrated at startup (~4 ms). `iio doctor` prints them. See `adio/PAPER.md` (also .docx).

    make adio-test                           # property test, ASan/UBSan
    make adio-bench DIR=/path/on/real/disk   # synthetic hardware profiles (labeled SYNTHETIC)

Not a prefetcher, not a kernel API, and not useful for callers that read one thing at a time.
Hook cost of iio itself is about 2 us per intercepted open (not nanoseconds).
