---
title: "When Does Batching Beat a Syscall? (v2)"
subtitle: "A calibrated cost model and picker for known lists of cached reads on Linux"
---

# Abstract

Linux offers several ways to read file data that is already in the page cache: a `pread` per request, one `preadv`, or an `io_uring` batch. Each has a fixed entry cost and a per-request cost, so the winner changes with the request list. AdaptiveIO v0.2 takes a list of reads the caller already knows, merges file-adjacent requests, estimates the cost of each strategy with a linear model calibrated on the machine itself, and runs the cheapest. On the author's VM it stayed within 1.5% of an oracle that ran every strategy (nine layouts, 120 interleaved rounds each). Across six emulated hardware profiles the mean regret was 1.0–2.8%. Frozen constants from another machine were 85–274% worse on the two profiles where io_uring is expensive. The largest effect was not the choice between pread and io_uring but merging adjacent requests: a naive loop was 134–564% slower than the merged call on adjacent layouts. A cold-cache test showed io_uring faster than a serial pread loop for 16–128 scattered 4 KiB reads (3–8x on a virtual disk, 1.4–1.9x on a real HDD-class SATA disk), but not for 1–4 reads. This is a picker for callers that already hold the list. It is not a kernel API and not a prefetcher.

# 1. What changed from v0.1

| v0.1 claim or method | Problem found | v0.2 |
|---|---|---|
| preadv is legal when requests share a file descriptor | Wrong. preadv reads one contiguous file range. Scattered pages of one file are not legal. | Legality means file-adjacent on one fd. |
| 64-byte reads, many fds vs one file | Missed the largest effect: merging adjacent requests. | Requests are sorted and merged before costing. |
| Two-point fit per interface | Sensitive to noise. A two-point io_uring slope of about 376 ns against a true value of about 200 ns made the picker choose wrongly (17–22% regret). | Least-squares fit over 4 batch sizes. |
| Calibration on a memfd | tmpfs/memfd can take a slower io_uring path (about 23–30 microseconds fixed). | Calibrate on an unlinked file in the data directory. |
| One VM said "io_uring never wins" | That was the memfd artifact, plus a real emulated case (below). | Reproduced deliberately as a synthetic profile. |
| Measure one strategy then the next | Machine drift favored whichever ran first. | Interleaved, rotating order, 98% trimmed mean. |

# 2. Method

**Request list.** An array of {fd, offset, length, buffer}. The caller must know the list before issuing it.

**Strategies.** (1) loop of `pread`; (2) merged runs, one `pread` or `preadv` per run of file-adjacent requests; (3) io_uring with merging (READ for one buffer, READV for several); (4) io_uring without merging.

**Model.** syscall run: `pread_fixed + gamma*bytes` when the buffers are contiguous, else `min(count*pread_fixed, preadv_fixed + preadv_per_iov*count) + gamma*bytes`. Ring: `uring_fixed*chunks + uring_per_sqe*runs + gamma*bytes + uring_per_iov*extra iovecs`. The constants are fitted at startup by timing small cached reads (about 4 ms; `iio doctor` prints it).

**Correctness.** A property test generates random request lists (15,000 cases) and requires every strategy to return the same bytes as a plain pread loop. Result: 0 mismatches, under AddressSanitizer and UBSan.

**Benchmark.** Nine layouts, warm cache, 120 rounds, strategies interleaved in rotating order. The oracle is the best strategy measured in the same run. Regret is the picker's mean time over the oracle's, minus one.

**Synthetic hardware profiles (labeled SYNTHETIC).** I cannot rent other machines, so the harness adds busy-wait delay to each syscall, each io_uring submit, and ring setup. These emulate costs the way a mitigation-heavy kernel or a restricted VM would, but they are not measurements of those machines. They test whether the picker adapts to a changed cost structure, not what a given real machine does.

# 3. Results

## 3.1 Picker vs oracle (this VM, ext4, warm; measured)

| Layout | Oracle | Picker | Regret | Loop of pread |
|---|---|---|---|---|
| 64 x 4K adjacent, one buffer | merged syscalls | merged syscalls | 1% | +134% |
| 64 x 4K adjacent, separate buffers | merged syscalls | merged syscalls | 0% | +162% |
| 64 x 4K scattered, one file | plain ring | merged ring | 7% | +6% |
| 32 files x 4K | plain ring | merged ring | 0% | +14% |
| 3 runs of 16 + 16 scattered | merged ring | merged ring | -1% | +65% |
| one 4K header | merged syscalls | merged syscalls | 1% | +1% |
| 100 x 64 B adjacent | merged syscalls | merged syscalls | 1% | +564% |
| 16 x 64K adjacent | merged syscalls | merged syscalls | -1% | +13% |
| 32 files x 64 B | loop | merged ring | 5% | 0% |

Mean regret 1.5%; no layout more than 10% worse. The two largest regrets are close calls between two nearly equal strategies. The model's own prediction error was 18% on average, so the picker is right because the strategies are usually far apart, not because the model is exact.

## 3.2 Across emulated hardware (SYNTHETIC)

| Profile | Added cost | Calibrated regret | Stale-constants regret | Always loop | Always plain ring |
|---|---|---|---|---|---|
| real | none | 1.4% | 0.9% | 117% | 104% |
| mitigated | +500 ns/syscall | 1.2% | 1.0% | 417% | 80% |
| slow | +2 us/syscall, +0.5 us/submit | 1.1% | 1.1% | 1032% | 73% |
| ringfree | +6 us/syscall | 1.0% | 0.9% | 2033% | 42% |
| vmring | +25 us/submit, +100 us setup | 2.1% | 89% | 109% | 1009% |
| hostile | +80 us/submit, +300 us setup | 2.8% | 274% | 110% | 3257% |

(Profile rows come from separate runs, so the "real" row differs slightly from 3.1.) The calibrated picker stays within 3% everywhere. Constants frozen from a machine with cheap io_uring pick the ring on the two profiles where it is expensive and lose 89% and 274%. Constants fitted on the author's Fedora machine (pread about 684 ns, io_uring 730 ns + 274 ns per request) behave like the stale-constants column: right when the machine resembles it, badly wrong when it does not. This supports H4 (constants do not transfer) and the case for calibrating at startup.

## 3.3 Cold cache (measured, real devices, not emulated)

512 MiB file, page cache dropped before every trial, N random 4 KiB reads, mean of 10–20 trials (serial `pread` loop vs one io_uring batch):

| N | VM virtual disk (ext4) | Author's Fedora machine (SATA, LUKS, btrfs, about 123 MB/s cold) |
|---|---|---|
| 1 | 1.2x | 0.64x (ring slower) |
| 4 | 13x (noisy outlier) | 0.92x (tie) |
| 16 | 3.3x | 1.72x |
| 64 | 5.9x | 1.36x |
| 128 | 7.8x | 1.91x |

On both devices the ring wins once the list is 16 or longer and does not win at 1–4 requests. On the real disk the gain is 1.4–1.9x, much smaller than on the virtual disk, as expected when the device must seek. Single-read timings on a spinning-class disk are very noisy (tens of ms), so the N=1 and N=4 cells are best read as "no gain", not as a measured loss. The warm-cache model does not describe this regime, and the picker is calibrated on cached reads. A cold-aware rule ("use the ring for lists of 16 or more") is suggested by these numbers but is not implemented or validated beyond these two devices.

## 3.4 The picker on the author's own machine (measured / SYNTHETIC)

Same benchmark, run on the Fedora machine (btrfs, warm). Calibrated constants: pread 500 ns, preadv 573 + 13 ns per iovec, io_uring 485 + 268 ns per request.

| Profile | Calibrated regret | Stale-defaults regret | Always loop | Always plain ring |
|---|---|---|---|---|
| real | 1.2% | 1.5% | 252% | 108% |
| mitigated (SYNTHETIC) | 1.6% | 1.4% | 489% | 95% |
| slow (SYNTHETIC) | 0.4% | 0.8% | 945% | 77% |
| ringfree (SYNTHETIC) | 0.6% | 0.4% | 1709% | 47% |
| vmring (SYNTHETIC) | 0.8% | 29% | 228% | 682% |
| hostile (SYNTHETIC) | 1.4% | 123% | 229% | 1955% |

The result matches the VM: calibrated regret of 0.4–1.6% on all six profiles; none of the 54 layout-profile cells was more than 10% worse. The built-in default constants are fine where io_uring is cheap and 29–123% worse where it is expensive. On this machine the plain pread loop is 2.5x slower than the best choice on average, a larger gap than on the VM (about 1.1x), because pread costs 500 ns here against about 220 ns there.

# 4. Limits (said plainly)

- Needs the list up front. It does nothing for programs that issue one read at a time.
- Not for databases with their own buffer pool, and not for games that read from a single archive with no list.
- Gains vanish if storage is as fast as RAM and the caller already merges its reads.
- The hardware-profile results are synthetic taxes, not measurements of other machines. Only the "real" profile is a measurement; it ran on two machines (a VM and the author's Fedora laptop). The cold-cache test covers two disks.
- The picker's regret is 0.4–3%, not 0. It is not "optimal".
- The overhead of the cost model itself is a planning pass over the list (sort-checked, so already-sorted lists are not re-sorted).
- Claims not made: zero overhead, a new kernel API, a speedup for any named application, a novel algorithm. Request merging and `preadv` are old; the contribution is a measured crossover map and a small calibrated chooser.

# 5. Relationship to iio

iio decides what to read before the application asks. AdaptiveIO decides how to issue reads once a list exists. They share a build and `iio doctor` prints AdaptiveIO's calibration. I did not test routing iio's prefetcher through AdaptiveIO, and I expect little gain there, since its reads are whole-file and mostly device-bound. A loader that takes a manifest list and reads it with `adio_read_batch` is the plausible joint use, and it has not been tested on a real game.

# 6. Reproduce

    make adio-test                         # 15,000-case property test (ASan/UBSan)
    make adio-bench DIR=/path/on/real/disk  # six synthetic profiles, 9 layouts
    ./iio doctor --dir ~                    # prints your machine's constants
