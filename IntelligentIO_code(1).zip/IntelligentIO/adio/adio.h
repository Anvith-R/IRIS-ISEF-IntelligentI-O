/*
 * adio - pick the cheapest way to issue a KNOWN list of cached reads.     v0.2
 *
 * You hand over the whole list (fd, offset, length, buffer). adio
 *   1. sorts it and merges requests that are adjacent in the file into runs,
 *   2. issues each run with one pread (contiguous buffers) or one preadv,
 *   3. or submits all runs as one io_uring batch,
 * choosing between 2 and 3 with a fitted linear cost model:
 *      syscall(run)  = a_pread  + g * bytes                      (one buffer)
 *                    = a_preadv + b_preadv * iovecs + g * bytes  (scattered buffers)
 *      ring(batch)   = a_uring  + b_uring * runs + g * bytes
 * The five-or-so constants differ per machine, so adio_open() re-fits them in
 * a few milliseconds (adio_calibrate). Userspace only: not a kernel API, no
 * dependency beyond libc and <linux/io_uring.h>. One adio_ctx per thread.
 *
 * It helps only when the caller already knows the next N reads and the data
 * is (or will be) in the page cache. For cold data see the note in README.
 */
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

typedef struct {
    int     fd;
    off_t   off;
    size_t  len;
    void   *buf;
    ssize_t got;            /* out: bytes read (0 at EOF), set by adio_read_batch */
} adio_req;

typedef struct {
    double pread_fixed_ns;      /* one pread syscall, 0 bytes                   */
    double preadv_fixed_ns;     /* one preadv syscall                           */
    double preadv_per_iov_ns;   /* each extra iovec                             */
    double uring_fixed_ns;      /* one io_uring_enter round trip                */
    double uring_per_sqe_ns;    /* each SQE (one per run)                       */
    double uring_per_iov_ns;    /* each iovec inside a READV SQE                */
    double per_byte_ns;         /* copy cost, shared by all paths               */
    int    uring_ok;            /* 0: ring unavailable or unusable here         */
} adio_model;

typedef enum {
    ADIO_AUTO = 0,
    ADIO_LOOP,          /* one pread per request, no merging (the naive loop)   */
    ADIO_RUNS,          /* merge, then one pread/preadv syscall per run          */
    ADIO_RING,          /* merge, then one io_uring batch                        */
    ADIO_RING_NOMERGE   /* one SQE per request (what a plain uring loop does)    */
} adio_strategy;

typedef struct adio_ctx adio_ctx;

void   adio_model_default(adio_model *m);          /* the author's Fedora fit   */
int    adio_calibrate(adio_model *m);              /* re-fit here; returns 0 ok */
int    adio_calibrate_in(adio_model *m, const char *dir); /* ...using a temp file in dir's filesystem */
struct adio_ctx *adio_open_in(const char *dir);    /* calibrated for the filesystem under dir  */
adio_ctx *adio_open(int calibrate);                /* NULL on allocation failure */
void   adio_close(adio_ctx *c);
const adio_model *adio_get_model(const adio_ctx *c);
void   adio_set_model(adio_ctx *c, const adio_model *m);
void   adio_force(adio_ctx *c, adio_strategy s);   /* benchmarking / overriding */

/* Predicted ns for a strategy on this list (without running it). */
double adio_estimate(adio_ctx *c, const adio_req *r, int n, adio_strategy s);
/* The strategy AUTO would pick. */
adio_strategy adio_plan(adio_ctx *c, const adio_req *r, int n);
/* Run the list. Returns total bytes read, or -errno. Requests are filled in
 * place; r[i].got is set. The request array is not reordered. */
ssize_t adio_read_batch(adio_ctx *c, adio_req *r, int n);

const char *adio_strategy_name(adio_strategy s);

#ifdef ADIO_SIM
/* Test-only machine emulation: extra ns of busy-wait added to every syscall
 * entry and to every io_uring_enter / io_uring_setup. Not compiled normally. */
extern volatile long adio_sim_syscall_tax_ns, adio_sim_enter_tax_ns, adio_sim_setup_tax_ns;
#endif
