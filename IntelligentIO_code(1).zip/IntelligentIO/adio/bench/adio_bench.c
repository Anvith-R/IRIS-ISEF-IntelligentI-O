/* adio_bench - planner vs always-X policies vs an oracle, on layouts of KNOWN lists, warm cache.
 *   adio_bench [--profile real|mitigated|slow|vmring|ringfree|hostile] [--dir D] [--rounds N] [--csv F]
 * Built with -DADIO_SIM. Profiles ADD busy-wait to syscalls to emulate other machines; they are
 * synthetic and labelled as such in every output line. */
#define _GNU_SOURCE
#include "../adio.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static long long now_ns(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC_RAW, &t); return (long long)t.tv_sec * 1000000000LL + t.tv_nsec; }
static int cmp_d(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return x < y ? -1 : x > y; }
static uint64_t rng = 0x9E3779B97F4A7C15ULL;
static uint32_t rnd(void) { rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17; return (uint32_t)(rng >> 16); }

#define PACK_PAGES 16384            /* 64 MiB file */
#define NFILES 64
#define MAXREQ 128
static int packfd, filefd[NFILES];
static char *arena;                 /* destination memory */

typedef struct { const char *name; int n; adio_req r[MAXREQ]; } layout;

static void mk_layouts(layout *L, int *nl)
{
    int k = 0;
    /* 1: 64 adjacent 4K pages -> one big buffer */
    L[k].name = "pack 64x4K adjacent, one buffer"; L[k].n = 64;
    for (int i = 0; i < 64; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(100 + i) * 4096, 4096, arena + i * 4096, 0 };
    k++;
    /* 2: same file range, separate (strided) buffers */
    L[k].name = "pack 64x4K adjacent, separate buffers"; L[k].n = 64;
    for (int i = 0; i < 64; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(500 + i) * 4096, 4096, arena + i * 8192, 0 };
    k++;
    /* 3: 64 scattered pages of one file */
    L[k].name = "one file, 64x4K scattered"; L[k].n = 64;
    for (int i = 0; i < 64; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(rnd() % PACK_PAGES) * 4096, 4096, arena + i * 4096, 0 };
    k++;
    /* 4: 32 files x 4K */
    L[k].name = "32 files x 4K"; L[k].n = 32;
    for (int i = 0; i < 32; i++) L[k].r[i] = (adio_req){ filefd[i], 0, 4096, arena + i * 4096, 0 };
    k++;
    /* 5: 3 adjacent runs of 16 + 16 scattered */
    L[k].name = "mixed: 3 runs of 16 + 16 scattered"; L[k].n = 64;
    for (int i = 0; i < 48; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(2000 + (i / 16) * 3000 + i % 16) * 4096, 4096, arena + i * 4096, 0 };
    for (int i = 48; i < 64; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(rnd() % PACK_PAGES) * 4096, 4096, arena + i * 4096, 0 };
    k++;
    /* 6: one header */
    L[k].name = "1 header 4K"; L[k].n = 1;
    L[k].r[0] = (adio_req){ packfd, 0, 4096, arena, 0 };
    k++;
    /* 7: 100 small 64 B adjacent reads (the paper's headline), separate buffers */
    L[k].name = "100 x 64B adjacent, separate buffers"; L[k].n = 100;
    for (int i = 0; i < 100; i++) L[k].r[i] = (adio_req){ packfd, (off_t)30000 + i * 64, 64, arena + i * 128, 0 };
    k++;
    /* 8: 16 x 64K adjacent (copy dominated) */
    L[k].name = "16 x 64K adjacent, one buffer"; L[k].n = 16;
    for (int i = 0; i < 16; i++) L[k].r[i] = (adio_req){ packfd, (off_t)(4000 * 4096) + (off_t)i * 65536, 65536, arena + (size_t)i * 65536, 0 };
    k++;
    /* 9: 32 small files, 64 B each (config files) */
    L[k].name = "32 files x 64B"; L[k].n = 32;
    for (int i = 0; i < 32; i++) L[k].r[i] = (adio_req){ filefd[i], 0, 64, arena + i * 128, 0 };
    k++;
    *nl = k;
}

static const adio_strategy FIXED[4] = { ADIO_LOOP, ADIO_RUNS, ADIO_RING, ADIO_RING_NOMERGE };

/* Interleaved measurement: every configuration is timed in every round, in rotating order, so machine
 * drift hits all of them alike. Statistic = mean of the fastest 98% of pooled batches (robust to VM jitter). */
typedef struct { adio_ctx *c; adio_strategy s; double *v; int nv; double mean, p99; } cfg_t;

static void measure_all(cfg_t *cf, int ncf, layout *l, int rounds)
{
    enum { INNER = 20 };
    for (int k = 0; k < ncf; k++) {
        cf[k].v = malloc(sizeof(double) * rounds * INNER); cf[k].nv = 0;
        adio_force(cf[k].c, cf[k].s);
        for (int w = 0; w < 20; w++) if (adio_read_batch(cf[k].c, l->r, l->n) < 0) { cf[k].nv = -1; break; }
    }
    for (int r = 0; r < rounds; r++)
        for (int q = 0; q < ncf; q++) {
            cfg_t *x = &cf[(q + r) % ncf]; if (x->nv < 0) continue;
            adio_force(x->c, x->s);
            for (int i = 0; i < INNER; i++) { long long t0 = now_ns(); adio_read_batch(x->c, l->r, l->n); x->v[x->nv++] = (double)(now_ns() - t0); }
        }
    for (int k = 0; k < ncf; k++) {
        if (cf[k].nv < 0) { cf[k].mean = cf[k].p99 = 1e18; free(cf[k].v); continue; }
        qsort(cf[k].v, cf[k].nv, sizeof(double), cmp_d);
        int keep = cf[k].nv * 98 / 100; double sum = 0; for (int i = 0; i < keep; i++) sum += cf[k].v[i];
        cf[k].mean = sum / keep; cf[k].p99 = cf[k].v[cf[k].nv * 99 / 100]; free(cf[k].v);
    }
}

int main(int argc, char **argv)
{
    const char *prof = "real", *dir = "."; int rounds = 40; const char *csv = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--profile") && i + 1 < argc) prof = argv[++i];
        else if (!strcmp(argv[i], "--dir") && i + 1 < argc) dir = argv[++i];
        else if (!strcmp(argv[i], "--rounds") && i + 1 < argc) rounds = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--csv") && i + 1 < argc) csv = argv[++i];
    }
    long sys = 0, enter = 0, setup = 0;
    if (!strcmp(prof, "mitigated")) sys = 500;           /* heavier kernel entry (mitigations, older CPU)      */
    else if (!strcmp(prof, "slow")) { sys = 2000; enter = 500; }       /* slow entry, e.g. nested virtualisation  */
    else if (!strcmp(prof, "vmring")) { enter = 25000; setup = 100000; } /* io_uring expensive (paper's VM)       */
    else if (!strcmp(prof, "ringfree")) { sys = 6000; }  /* syscalls so dear that any batch wins                */
    else if (!strcmp(prof, "hostile")) { sys = 0; enter = 80000; setup = 300000; }
    else if (strcmp(prof, "real")) { fprintf(stderr, "unknown profile\n"); return 2; }
    char p[600];
    snprintf(p, sizeof p, "%s/adio_pack.bin", dir); packfd = open(p, O_CREAT | O_RDWR, 0644);
    if (packfd < 0) { perror("open"); return 1; }
    if (lseek(packfd, 0, SEEK_END) < (off_t)PACK_PAGES * 4096) {
        char *z = malloc(1 << 20); for (int i = 0; i < (1 << 20); i++) z[i] = (char)rnd();
        for (int i = 0; i < PACK_PAGES / 256; i++) if (pwrite(packfd, z, 1 << 20, (off_t)i << 20) != (1 << 20)) return 1;
        free(z); fsync(packfd);
    }
    for (int i = 0; i < NFILES; i++) {
        snprintf(p, sizeof p, "%s/adio_f%02d.bin", dir, i); filefd[i] = open(p, O_CREAT | O_RDWR, 0644);
        char b[4096]; memset(b, i, sizeof b); if (pwrite(filefd[i], b, 4096, 0) != 4096) return 1;
    }
    arena = aligned_alloc(4096, 1 << 20);
    memset(arena, 1, 1 << 20);
    { char *w = malloc(1 << 20); for (int i = 0; i < PACK_PAGES / 256; i++) if (pread(packfd, w, 1 << 20, (off_t)i << 20) < 0) return 1; free(w); }   /* warm */
#ifdef ADIO_SIM
    adio_sim_syscall_tax_ns = sys; adio_sim_enter_tax_ns = enter; adio_sim_setup_tax_ns = setup;
#endif
    adio_ctx *cal = adio_open_in(dir), *stale = adio_open(0);
    const adio_model *m = adio_get_model(cal);
    printf("== adio_bench  profile=%s (SYNTHETIC tax: syscall +%ld ns, enter +%ld ns, setup +%ld ns)  rounds=%d ==\n", prof, sys, enter, setup, rounds);
    printf("calibrated here: pread %.0f ns, preadv %.0f+%.0f/iov, uring %.0f+%.0f/sqe+%.0f/iov (ok=%d), %.3f ns/B\n",
           m->pread_fixed_ns, m->preadv_fixed_ns, m->preadv_per_iov_ns, m->uring_fixed_ns, m->uring_per_sqe_ns, m->uring_per_iov_ns, m->uring_ok, m->per_byte_ns);
    layout L[16]; int nl; mk_layouts(L, &nl);
    FILE *cf0 = csv ? fopen(csv, "a") : NULL;
    printf("%-40s %9s %9s | %-16s %9s %7s | %-16s %7s | %7s %7s\n", "layout (mean ns, warm)", "oracle", "oracle=", "calibrated pick", "mean", "regret", "stale pick", "regret", "loop", "plainring");
    double sum_cal = 0, sum_stale = 0, sum_loop = 0, sum_ring = 0, sum_best_static = 0; int wrong_cal = 0, wrong_stale = 0, wrong_loop = 0, wrong_ring = 0;
    double sum_err = 0; int nerr = 0;
    for (int li = 0; li < nl; li++) {
        layout *l = &L[li];
        cfg_t cf[6] = { { cal, ADIO_LOOP }, { cal, ADIO_RUNS }, { cal, ADIO_RING }, { cal, ADIO_RING_NOMERGE }, { cal, ADIO_AUTO }, { stale, ADIO_AUTO } };
        if (!m->uring_ok) { cf[2].s = cf[3].s = ADIO_RUNS; }
        measure_all(cf, 6, l, rounds);
        double mean[4]; for (int s = 0; s < 4; s++) mean[s] = cf[s].mean;
        if (!m->uring_ok) { mean[2] = mean[3] = 1e18; }
        for (int s = 0; s < 4; s++) {
            double est = adio_estimate(cal, l->r, l->n, FIXED[s]);
            if (est < 1e17 && mean[s] < 1e17) { double e2 = (est - mean[s]) / mean[s]; sum_err += e2 < 0 ? -e2 : e2; nerr++; }
        }
        int best = 0; for (int s = 1; s < 4; s++) if (mean[s] < mean[best]) best = s;
        adio_strategy pc = adio_plan(cal, l->r, l->n), ps = adio_plan(stale, l->r, l->n);
        double mc = cf[4].mean, ms = cf[5].mean;
        double o = mean[best], rc = mc / o - 1, rs = ms / o - 1, rl = mean[0] / o - 1, rr = mean[3] / o - 1;
        sum_cal += rc; sum_stale += rs; sum_loop += rl; sum_ring += rr;
        if (rc > 0.10) wrong_cal++;
        if (rs > 0.10) wrong_stale++;
        if (rl > 0.10) wrong_loop++;
        if (rr > 0.10) wrong_ring++;
        printf("%-40s %9.0f %9s | %-16s %9.0f %6.0f%% | %-16s %6.0f%% | %6.0f%% %8.0f%%\n", l->name, o, adio_strategy_name(FIXED[best]),
               adio_strategy_name(pc), mc, rc * 100, adio_strategy_name(ps), rs * 100, rl * 100, rr * 100);
        if (cf0) fprintf(cf0, "%s,%s,%.0f,%s,%.0f,%.4f,%.4f,%.4f,%.4f,%.0f,%.0f\n", prof, l->name, o, adio_strategy_name(FIXED[best]), mc, rc, rs, rl, rr, mean[1], mean[2]);
    }
    printf("summary %s: mean regret vs oracle  calibrated %.1f%% (%d/%d layouts >10%% worse)  stale-defaults %.1f%% (%d/%d)  always-loop %.1f%% (%d/%d)  always-plain-ring %.1f%% (%d/%d)  | model |error| %.0f%%\n",
           prof, 100 * sum_cal / nl, wrong_cal, nl, 100 * sum_stale / nl, wrong_stale, nl, 100 * sum_loop / nl, wrong_loop, nl, 100 * sum_ring / nl, wrong_ring, nl, nerr ? 100 * sum_err / nerr : 0);
    (void)sum_best_static; (void)wrong_stale;
    if (cf0) fclose(cf0);
    adio_close(cal); adio_close(stale);
    return 0;
}
