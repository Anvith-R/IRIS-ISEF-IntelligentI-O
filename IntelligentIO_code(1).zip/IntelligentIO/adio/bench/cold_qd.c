/* cold_qd: cold-cache scattered 4K reads, serial pread loop vs one io_uring batch (queue depth N).
 * Usage: cold_qd FILE N TRIALS   (needs root for drop_caches). Real device, nothing emulated. */
#define _GNU_SOURCE
#include "../adio.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
static long long now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000LL+t.tv_nsec;}
static void drop(void){sync();int f=open("/proc/sys/vm/drop_caches",O_WRONLY);if(f>=0){(void)!write(f,"3",1);close(f);}}
int main(int argc,char**argv){
  if(argc<4)return 2; const char*path=argv[1]; int N=atoi(argv[2]),T=atoi(argv[3]);
  int fd=open(path,O_RDONLY); struct stat st; fstat(fd,&st); long pages=st.st_size/4096;
  adio_ctx*c=adio_open_in(NULL); char*buf=aligned_alloc(4096,(size_t)N*4096); srand(7);
  double sl=0,sr=0; 
  for(int t=0;t<T;t++){
    adio_req r[256]; for(int i=0;i<N;i++){r[i].fd=fd;r[i].off=(off_t)(rand()%pages)*4096;r[i].len=4096;r[i].buf=buf+(size_t)i*4096;}
    for(int m=0;m<2;m++){ int ring=(t+m)&1; drop();
      adio_force(c,ring?ADIO_RING_NOMERGE:ADIO_LOOP); long long a=now(); adio_read_batch(c,r,N); long long b=now()-a;
      if(ring)sr+=b; else sl+=b; } }
  printf("N=%d  serial-pread %.0f us   io_uring %.0f us   speedup %.2fx  (mean of %d, cold)\n",N,sl/T/1e3,sr/T/1e3,sl/sr,T); return 0; }
