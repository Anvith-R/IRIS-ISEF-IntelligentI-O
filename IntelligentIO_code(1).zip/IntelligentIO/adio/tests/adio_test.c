/* Property test: every strategy must return exactly the bytes a naive pread loop returns. */
#define _GNU_SOURCE
#include "../adio.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define NF 4
#define FSZ 300000
static uint64_t rng = 88172645463325252ULL;
static uint32_t rnd(void) { rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17; return (uint32_t)(rng >> 16); }

int main(void)
{
    char path[] = "/tmp/adio_test_XXXXXX"; int fds[NF];
    for (int f = 0; f < NF; f++) {
        char p[64]; snprintf(p, sizeof p, "%s_%d", path, f);
        char tmpl[64]; snprintf(tmpl, sizeof tmpl, "/tmp/adio_test_%d_XXXXXX", f);
        fds[f] = mkstemp(tmpl); unlink(tmpl);
        char *d = malloc(FSZ); for (int i = 0; i < FSZ; i++) d[i] = (char)(rnd() ^ f);
        if (write(fds[f], d, FSZ) != FSZ) return 2;
        free(d);
    }
    adio_ctx *c = adio_open(1);
    const adio_model *m = adio_get_model(c);
    printf("calibrated: pread %.0f ns, preadv %.0f+%.0f/iov, uring %.0f+%.0f/sqe (ok=%d), %.3f ns/B\n",
           m->pread_fixed_ns, m->preadv_fixed_ns, m->preadv_per_iov_ns, m->uring_fixed_ns, m->uring_per_sqe_ns, m->uring_ok, m->per_byte_ns);
    adio_strategy strat[] = { ADIO_AUTO, ADIO_LOOP, ADIO_RUNS, ADIO_RING, ADIO_RING_NOMERGE };
    long cases = 0, bad = 0;
    for (int iter = 0; iter < 3000; iter++) {
        int n = 1 + rnd() % 200;
        enum { ARENA = 1 << 22 };
        static char ref[ARENA], out[ARENA];
        adio_req r[200], q[200]; size_t pos = 0; off_t off = 0; int fd = fds[rnd() % NF];
        int mode = rnd() % 4;
        for (int i = 0; i < n; i++) {
            size_t len = (rnd() % 8 == 0) ? 0 : 1 + rnd() % (mode == 3 ? 20000 : 3000);
            if (mode == 0) { /* adjacent in file, contiguous buffers */ }
            else if (mode == 1) off += rnd() % 5000;                   /* scattered, sorted-ish */
            else off = rnd() % (FSZ + 1000);                           /* random, may pass EOF, may overlap */
            if (mode == 2 && rnd() % 3 == 0) fd = fds[rnd() % NF];     /* multi fd */
            if (pos + len + 64 > ARENA) { n = i; break; }
            size_t gap = (mode == 0) ? 0 : (rnd() % 3 == 0 ? 17 : 0);   /* sometimes non-contiguous buffers */
            pos += gap;
            r[i].fd = fd; r[i].off = off; r[i].len = len; r[i].buf = out + pos; r[i].got = -1;
            q[i] = r[i]; q[i].buf = ref + pos;
            pos += len; if (mode == 0 || mode == 3) off += len; else if (mode == 1) off += len;
        }
        /* reference: naive pread */
        memset(ref, 0, ARENA);
        long tot_ref = 0; ssize_t gotref[200];
        for (int i = 0; i < n; i++) {
            size_t g = 0;
            while (g < q[i].len) { ssize_t k = pread(q[i].fd, (char *)q[i].buf + g, q[i].len - g, q[i].off + g); if (k <= 0) break; g += k; }
            gotref[i] = g; tot_ref += g;
        }
        for (unsigned s = 0; s < sizeof strat / sizeof *strat; s++) {
            adio_force(c, strat[s]); memset(out, 0, ARENA);
            ssize_t tot = adio_read_batch(c, r, n); cases++;
            int ok = (tot == tot_ref);
            for (int i = 0; ok && i < n; i++) ok = (r[i].got == gotref[i]) && memcmp(r[i].buf, q[i].buf, gotref[i]) == 0;
            if (!ok) { bad++; if (bad < 5) printf("MISMATCH iter %d mode %d strat %s n=%d tot %zd vs %ld\n", iter, mode, adio_strategy_name(strat[s]), n, tot, tot_ref); }
        }
    }
    /* error path */
    static char eb[8]; adio_req e = { .fd = -1, .off = 0, .len = 8, .buf = eb };
    for (unsigned s = 0; s < sizeof strat / sizeof *strat; s++) { adio_force(c, strat[s]); if (adio_read_batch(c, &e, 1) >= 0) { bad++; printf("bad fd not reported (%s)\n", adio_strategy_name(strat[s])); } }
    printf("%ld cases, %ld mismatches\n", cases, bad);
    adio_close(c);
    return bad != 0;
}
