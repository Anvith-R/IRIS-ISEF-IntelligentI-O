/* adio.c - see adio.h.  C11, glibc + <linux/io_uring.h> only. */
#define _GNU_SOURCE
#include "adio.h"
#include <errno.h>
#include <fcntl.h>
#include <linux/io_uring.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <time.h>
#include <unistd.h>

#define RING_ENTRIES 128
#define INF 1e18

#ifdef ADIO_SIM
volatile long adio_sim_syscall_tax_ns, adio_sim_enter_tax_ns, adio_sim_setup_tax_ns;
#endif

static long long now_ns(void)
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return (long long)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}
#ifdef ADIO_SIM
static inline void tax(long ns) { if (ns > 0) { long long t = now_ns() + ns; while (now_ns() < t) {} } }
#define TAX_SYS()   tax(adio_sim_syscall_tax_ns)
#define TAX_ENTER() tax(adio_sim_syscall_tax_ns + adio_sim_enter_tax_ns)
#define TAX_SETUP() tax(adio_sim_setup_tax_ns)
#else
#define TAX_SYS()   ((void)0)
#define TAX_ENTER() ((void)0)
#define TAX_SETUP() ((void)0)
#endif

static inline ssize_t sys_pread(int fd, void *b, size_t n, off_t o) { TAX_SYS(); return pread(fd, b, n, o); }
static inline ssize_t sys_preadv(int fd, const struct iovec *v, int c, off_t o) { TAX_SYS(); return preadv(fd, v, c, o); }

/* ------------------------------------------------------------ ring */
typedef struct {
    int fd;
    unsigned entries, sq_mask, cq_mask;
    unsigned *sq_head, *sq_tail, *sq_array, *cq_head, *cq_tail;
    struct io_uring_sqe *sqes;
    struct io_uring_cqe *cqes;
    void *sq_map, *cq_map, *sqe_map; size_t sq_sz, cq_sz, sqe_sz;
} ring_t;

static int ring_setup(ring_t *r)
{
    struct io_uring_params p; memset(&p, 0, sizeof p); memset(r, 0, sizeof *r); r->fd = -1;
    TAX_SETUP();
    int fd = (int)syscall(__NR_io_uring_setup, RING_ENTRIES, &p);
    if (fd < 0) return -1;
    r->fd = fd; r->entries = p.sq_entries;
    size_t sq = p.sq_off.array + p.sq_entries * sizeof(unsigned);
    size_t cq = p.cq_off.cqes + p.cq_entries * sizeof(struct io_uring_cqe);
    int single = (p.features & IORING_FEAT_SINGLE_MMAP) != 0;
    if (single && cq > sq) sq = cq;
    r->sq_sz = sq;
    r->sq_map = mmap(NULL, sq, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_POPULATE, fd, IORING_OFF_SQ_RING);
    if (r->sq_map == MAP_FAILED) goto fail;
    if (single) r->cq_map = r->sq_map;
    else {
        r->cq_sz = cq;
        r->cq_map = mmap(NULL, cq, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_POPULATE, fd, IORING_OFF_CQ_RING);
        if (r->cq_map == MAP_FAILED) goto fail;
    }
    r->sqe_sz = p.sq_entries * sizeof(struct io_uring_sqe);
    r->sqe_map = mmap(NULL, r->sqe_sz, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_POPULATE, fd, IORING_OFF_SQES);
    if (r->sqe_map == MAP_FAILED) goto fail;
    r->sqes = r->sqe_map;
    r->sq_head = (unsigned *)((char *)r->sq_map + p.sq_off.head);
    r->sq_tail = (unsigned *)((char *)r->sq_map + p.sq_off.tail);
    r->sq_array = (unsigned *)((char *)r->sq_map + p.sq_off.array);
    r->sq_mask = *(unsigned *)((char *)r->sq_map + p.sq_off.ring_mask);
    r->cq_head = (unsigned *)((char *)r->cq_map + p.cq_off.head);
    r->cq_tail = (unsigned *)((char *)r->cq_map + p.cq_off.tail);
    r->cq_mask = *(unsigned *)((char *)r->cq_map + p.cq_off.ring_mask);
    r->cqes = (struct io_uring_cqe *)((char *)r->cq_map + p.cq_off.cqes);
    return 0;
fail:
    close(fd); r->fd = -1; return -1;
}

static void ring_close(ring_t *r)
{
    if (r->fd < 0) return;
    if (r->sqe_map && r->sqe_map != MAP_FAILED) munmap(r->sqe_map, r->sqe_sz);
    if (r->cq_map && r->cq_map != r->sq_map && r->cq_map != MAP_FAILED) munmap(r->cq_map, r->cq_sz);
    if (r->sq_map && r->sq_map != MAP_FAILED) munmap(r->sq_map, r->sq_sz);
    close(r->fd); r->fd = -1;
}

/* ------------------------------------------------------------ context */
typedef struct { int first, cnt; int fd; off_t off; size_t bytes; int bufcontig; } run_t;

struct adio_ctx {
    adio_model m;
    ring_t ring;
    adio_strategy force;
    int *ord; size_t ord_cap;
    run_t *runs; size_t runs_cap;
    struct iovec *iov; size_t iov_cap;
};

void adio_model_default(adio_model *m)
{   /* author's Fedora fit (64 B warm, Oct 2026) re-expressed in this model */
    m->pread_fixed_ns = 580; m->preadv_fixed_ns = 600; m->preadv_per_iov_ns = 16;
    m->uring_fixed_ns = 590; m->uring_per_sqe_ns = 270; m->uring_per_iov_ns = 30; m->per_byte_ns = 0.05; m->uring_ok = 1;
}

const char *adio_strategy_name(adio_strategy s)
{
    switch (s) { case ADIO_LOOP: return "loop-pread"; case ADIO_RUNS: return "merged-syscalls";
                 case ADIO_RING: return "merged-ring"; case ADIO_RING_NOMERGE: return "plain-ring";
                 default: return "auto"; }
}

/* ------------------------------------------------------------ planning */
typedef struct { const adio_req *r; } cmpctx;
static int cmp_req(const void *a, const void *b, void *ctx)
{
    const adio_req *r = ((cmpctx *)ctx)->r; int x = *(const int *)a, y = *(const int *)b;
    if (r[x].fd != r[y].fd) return r[x].fd < r[y].fd ? -1 : 1;
    if (r[x].off != r[y].off) return r[x].off < r[y].off ? -1 : 1;
    return x < y ? -1 : x > y;
}

static int grow(void **p, size_t *cap, size_t need, size_t esz)
{
    if (*cap >= need) return 0;
    size_t nc = *cap ? *cap : 64; while (nc < need) nc *= 2;
    void *q = realloc(*p, nc * esz); if (!q) return -1;
    *p = q; *cap = nc; return 0;
}

/* Build ord[] (sorted indices) and runs[]. merge=0: one run per request, order kept. Returns #runs or -1. */
static int build_runs(adio_ctx *c, const adio_req *r, int n, int merge)
{
    if (grow((void **)&c->ord, &c->ord_cap, n, sizeof(int)) || grow((void **)&c->runs, &c->runs_cap, n, sizeof(run_t))) return -1;
    int k = 0;
    for (int i = 0; i < n; i++) if (r[i].len) c->ord[k++] = i;
    if (merge && k > 1) {
        int sorted = 1;
        for (int i = 1; i < k && sorted; i++) { int a = c->ord[i - 1], b = c->ord[i]; if (cmp_req(&a, &b, &(cmpctx){ r }) > 0) sorted = 0; }
        if (!sorted) { cmpctx cx = { r }; qsort_r(c->ord, k, sizeof(int), cmp_req, &cx); }
    }
    int nr = 0;
    for (int i = 0; i < k; i++) {
        const adio_req *q = &r[c->ord[i]];
        if (merge && nr) {
            run_t *p = &c->runs[nr - 1];
            const adio_req *last = &r[c->ord[p->first + p->cnt - 1]];
            if (p->fd == q->fd && last->off + (off_t)last->len == q->off) {
                if (p->bufcontig && (char *)last->buf + last->len != (char *)q->buf) p->bufcontig = 0;
                p->cnt++; p->bytes += q->len; continue;
            }
        }
        run_t *p = &c->runs[nr++];
        p->first = i; p->cnt = 1; p->fd = q->fd; p->off = q->off; p->bytes = q->len; p->bufcontig = 1;
    }
    return nr;
}

static double run_cost_sys(const adio_model *m, const run_t *p)
{
    double bytes = m->per_byte_ns * (double)p->bytes;
    if (p->bufcontig || p->cnt == 1) return m->pread_fixed_ns + bytes;
    double a = m->pread_fixed_ns * p->cnt;                        /* one pread per request */
    double v = m->preadv_fixed_ns + m->preadv_per_iov_ns * p->cnt;
    return (v < a ? v : a) + bytes;
}

static double est_from_runs(const adio_model *m, const adio_req *r, const run_t *runs, int nr, int n, adio_strategy s, const int *ord)
{
    (void)r; (void)ord;
    double bytes = 0; for (int i = 0; i < nr; i++) bytes += (double)runs[i].bytes;
    if (s == ADIO_LOOP) return m->pread_fixed_ns * n + m->per_byte_ns * bytes;
    if (s == ADIO_RUNS) { double t = 0; for (int i = 0; i < nr; i++) t += run_cost_sys(m, &runs[i]); return t; }
    if (!m->uring_ok) return INF;
    int chunks = (nr + RING_ENTRIES - 1) / RING_ENTRIES; if (chunks < 1) chunks = 1;
    double t = m->uring_fixed_ns * chunks + m->uring_per_sqe_ns * nr + m->per_byte_ns * bytes;
    for (int i = 0; i < nr; i++) if (runs[i].cnt > 1 && !runs[i].bufcontig) t += m->uring_per_iov_ns * runs[i].cnt;
    return t;
}

double adio_estimate(adio_ctx *c, const adio_req *r, int n, adio_strategy s)
{
    if (n <= 0) return 0;
    int merge = !(s == ADIO_LOOP || s == ADIO_RING_NOMERGE);
    int nr = build_runs(c, r, n, merge); if (nr < 0) return INF;
    return est_from_runs(&c->m, r, c->runs, nr, n, s == ADIO_RING_NOMERGE ? ADIO_RING : s, c->ord);
}

adio_strategy adio_plan(adio_ctx *c, const adio_req *r, int n)
{
    if (n <= 1) return ADIO_RUNS;
    int nr = build_runs(c, r, n, 1); if (nr < 0) return ADIO_RUNS;
    double s = est_from_runs(&c->m, r, c->runs, nr, n, ADIO_RUNS, c->ord);
    double g = est_from_runs(&c->m, r, c->runs, nr, n, ADIO_RING, c->ord);
    return g < s ? ADIO_RING : ADIO_RUNS;
}

/* ------------------------------------------------------------ execution */
static void distribute(adio_req *r, const int *ord, const run_t *p, size_t got)
{
    for (int i = 0; i < p->cnt; i++) {
        adio_req *q = &r[ord[p->first + i]];
        size_t g = got < q->len ? got : q->len; q->got = (ssize_t)g; got -= g;
    }
}

/* finish whatever a run did not complete, request by request. Returns 0 or -errno. */
static int finish_slow(adio_req *r, const int *ord, const run_t *p)
{
    for (int i = 0; i < p->cnt; i++) {
        adio_req *q = &r[ord[p->first + i]];
        while ((size_t)q->got < q->len) {
            ssize_t k = sys_pread(q->fd, (char *)q->buf + q->got, q->len - q->got, q->off + q->got);
            if (k < 0) { if (errno == EINTR) continue; return -errno; }
            if (k == 0) break;
            q->got += k;
        }
    }
    return 0;
}

static int exec_run_sys(adio_req *r, const int *ord, const run_t *p, adio_ctx *c)
{
    ssize_t k;
    if (p->cnt == 1 || p->bufcontig) {
        k = sys_pread(p->fd, r[ord[p->first]].buf, p->bytes, p->off);
    } else {
        double a = c->m.pread_fixed_ns * p->cnt, v = c->m.preadv_fixed_ns + c->m.preadv_per_iov_ns * p->cnt;
        if (a <= v) {                                        /* cheaper as separate preads */
            for (int i = 0; i < p->cnt; i++) {
                adio_req *q = &r[ord[p->first + i]];
                ssize_t t = sys_pread(q->fd, q->buf, q->len, q->off);
                if (t < 0) return -errno;
                q->got = t;
            }
            return finish_slow(r, ord, p);
        }
        if (grow((void **)&c->iov, &c->iov_cap, p->cnt, sizeof(struct iovec))) return -ENOMEM;
        for (int i = 0; i < p->cnt; i++) { adio_req *q = &r[ord[p->first + i]]; c->iov[i].iov_base = q->buf; c->iov[i].iov_len = q->len; }
        int cnt = p->cnt > 1024 ? 1024 : p->cnt;                    /* IOV_MAX */
        if (cnt < p->cnt) { distribute(r, ord, p, 0); return finish_slow(r, ord, p); }
        k = sys_preadv(p->fd, c->iov, cnt, p->off);
    }
    if (k < 0) return -errno;
    distribute(r, ord, p, (size_t)k);
    return finish_slow(r, ord, p);
}

static int exec_ring(adio_ctx *c, adio_req *r, int nr)
{
    ring_t *g = &c->ring; int err = 0;
    size_t need_iov = 0; for (int i = 0; i < nr; i++) if (!(c->runs[i].cnt == 1 || c->runs[i].bufcontig)) need_iov += c->runs[i].cnt;
    if (need_iov && grow((void **)&c->iov, &c->iov_cap, need_iov, sizeof(struct iovec))) return -ENOMEM;
    size_t iv = 0;
    for (int base = 0; base < nr; base += (int)g->entries) {
        int chunk = nr - base < (int)g->entries ? nr - base : (int)g->entries;
        unsigned tail = *g->sq_tail;
        for (int j = 0; j < chunk; j++) {
            const run_t *p = &c->runs[base + j];
            struct io_uring_sqe *s = &g->sqes[tail & g->sq_mask];
            memset(s, 0, sizeof *s);
            s->fd = p->fd; s->off = (unsigned long long)p->off; s->user_data = (unsigned long long)(base + j);
            if (p->cnt == 1 || p->bufcontig) {
                s->opcode = IORING_OP_READ; s->addr = (unsigned long long)(uintptr_t)r[c->ord[p->first]].buf; s->len = (unsigned)p->bytes;
            } else {
                struct iovec *v = &c->iov[iv];
                for (int i = 0; i < p->cnt; i++) { adio_req *q = &r[c->ord[p->first + i]]; v[i].iov_base = q->buf; v[i].iov_len = q->len; }
                iv += p->cnt;
                s->opcode = IORING_OP_READV; s->addr = (unsigned long long)(uintptr_t)v; s->len = (unsigned)p->cnt;
            }
            g->sq_array[tail & g->sq_mask] = tail & g->sq_mask; tail++;
        }
        atomic_store_explicit((_Atomic unsigned *)g->sq_tail, tail, memory_order_release);
        int done = 0;
        while (done < chunk) {
            TAX_ENTER();
            long rc = syscall(__NR_io_uring_enter, g->fd, done ? 0 : chunk, chunk - done, IORING_ENTER_GETEVENTS, NULL, 0);
            if (rc < 0 && errno != EINTR) { err = -errno; return err; }
            unsigned head = *g->cq_head, ctail = atomic_load_explicit((_Atomic unsigned *)g->cq_tail, memory_order_acquire);
            while (head != ctail) {
                struct io_uring_cqe *e = &g->cqes[head & g->cq_mask]; head++; done++;
                const run_t *p = &c->runs[e->user_data];
                if (e->res < 0) { if (!err) err = e->res; }
                else distribute(r, c->ord, p, (size_t)e->res);
            }
            atomic_store_explicit((_Atomic unsigned *)g->cq_head, head, memory_order_release);
        }
    }
    if (err) return err;
    for (int i = 0; i < nr; i++) { int e = finish_slow(r, c->ord, &c->runs[i]); if (e) return e; }
    return 0;
}

ssize_t adio_read_batch(adio_ctx *c, adio_req *r, int n)
{
    if (n <= 0) return 0;
    for (int i = 0; i < n; i++) r[i].got = 0;
    adio_strategy s = c->force;
    int nr;
    if (s == ADIO_AUTO || s == ADIO_RUNS || s == ADIO_RING) {
        nr = build_runs(c, r, n, 1); if (nr < 0) return -ENOMEM;
        if (s == ADIO_AUTO) {
            s = ADIO_RUNS;
            if (n > 1) {
                double a = est_from_runs(&c->m, r, c->runs, nr, n, ADIO_RUNS, c->ord);
                double g = est_from_runs(&c->m, r, c->runs, nr, n, ADIO_RING, c->ord);
                if (g < a) s = ADIO_RING;
            }
        }
    } else { nr = build_runs(c, r, n, 0); if (nr < 0) return -ENOMEM; }
    if ((s == ADIO_RING || s == ADIO_RING_NOMERGE) && c->ring.fd < 0 && ring_setup(&c->ring)) {
        s = ADIO_RUNS; nr = build_runs(c, r, n, 1); if (nr < 0) return -ENOMEM;
    }
    int err = 0;
    if (s == ADIO_RING || s == ADIO_RING_NOMERGE) err = exec_ring(c, r, nr);
    else for (int i = 0; i < nr && !err; i++) err = exec_run_sys(r, c->ord, &c->runs[i], c);
    if (err) return err;
    ssize_t tot = 0; for (int i = 0; i < n; i++) tot += r[i].got;
    return tot;
}

/* ------------------------------------------------------------ calibration */
static int cmp_d(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return x < y ? -1 : x > y; }

#define SAMPLES 9
#define INNER 12
static double med(double *v) { qsort(v, SAMPLES, sizeof(double), cmp_d); return v[SAMPLES / 2]; }

/* least-squares line y = a + b*x */
static void linfit(const double *x, const double *y, int k, double *a, double *b)
{
    double sx = 0, sy = 0, sxx = 0, sxy = 0;
    for (int i = 0; i < k; i++) { sx += x[i]; sy += y[i]; sxx += x[i] * x[i]; sxy += x[i] * y[i]; }
    double d = k * sxx - sx * sx;
    *b = d != 0 ? (k * sxy - sx * sy) / d : 0; *a = (sy - *b * sx) / k;
}


static int cal_tmpfd(const char *dir)
{   /* an unlinked file on the filesystem the data lives on: memfd/tmpfs can take a different (slower) io_uring path */
    const char *cand[4]; int nc = 0;
    if (dir) cand[nc++] = dir;
    const char *e = getenv("ADIO_CAL_DIR"); if (e && *e) cand[nc++] = e;
    cand[nc++] = "."; cand[nc++] = "/var/tmp";
    for (int i = 0; i < nc; i++) { int fd = open(cand[i], O_TMPFILE | O_RDWR, 0600); if (fd >= 0) return fd; }
    return memfd_create("adio", 0);
}

int adio_calibrate_in(adio_model *m, const char *dir)
{
    adio_model_default(m);
    int fd = cal_tmpfd(dir);
    if (fd < 0) return -1;
    enum { FSZ = 1 << 20, BIG = 1 << 16 };
    char *buf = malloc(FSZ);
    if (!buf) { close(fd); return -1; }
    memset(buf, 0x5a, FSZ);
    if (write(fd, buf, FSZ) != FSZ) { free(buf); close(fd); return -1; }
    double v[SAMPLES];
    #define TIME_LOOP(expr) do { for (int s_ = 0; s_ < SAMPLES; s_++) { long long t0_ = now_ns(); \
        for (int i_ = 0; i_ < INNER; i_++) { expr; } v[s_] = (double)(now_ns() - t0_) / INNER; } } while (0)
    for (int w = 0; w < 20; w++) (void)sys_pread(fd, buf, 64, 0);                 /* warm */
    TIME_LOOP((void)sys_pread(fd, buf, 64, 0));      double p64 = med(v);
    TIME_LOOP((void)sys_pread(fd, buf, BIG, 0));     double pbig = med(v);
    double g = (pbig - p64) / (double)(BIG - 64);
    if (g < 0.005) g = 0.005;
    if (g > 1.0) g = 1.0;
    m->per_byte_ns = g;
    m->pread_fixed_ns = p64 - 64 * g; if (m->pread_fixed_ns < 30) m->pread_fixed_ns = 30;

    /* preadv: least-squares over iovec counts */
    struct iovec iv[64];
    for (int i = 0; i < 64; i++) { iv[i].iov_base = buf + i * 64; iv[i].iov_len = 64; }
    { static const int ks[4] = { 1, 4, 16, 64 }; double x[4], y[4], a, b;
      for (int j = 0; j < 4; j++) { TIME_LOOP((void)sys_preadv(fd, iv, ks[j], 0)); x[j] = ks[j]; y[j] = med(v) - ks[j] * 64 * g; }
      linfit(x, y, 4, &a, &b);
      if (b < 1) b = 1;
      if (a < 30) a = 30;
      m->preadv_per_iov_ns = b; m->preadv_fixed_ns = a; }

    ring_t rg;
    if (ring_setup(&rg) == 0) {
        adio_ctx tmp; memset(&tmp, 0, sizeof tmp); tmp.m = *m; tmp.ring = rg; tmp.force = ADIO_RING_NOMERGE;
        adio_req q[64];
        for (int i = 0; i < 64; i++) { q[i].fd = fd; q[i].off = i * 64; q[i].len = 64; q[i].buf = buf + i * 64; }
        int ok = 1;
        static const int ns[4] = { 2, 8, 32, 64 }; double x[4], y[4], a, b;
        for (int j = 0; j < 4; j++) { TIME_LOOP(if (adio_read_batch(&tmp, q, ns[j]) < 0) ok = 0); x[j] = ns[j]; y[j] = med(v) - ns[j] * 64 * g; }
        linfit(x, y, 4, &a, &b);
        if (b < 1) b = 1;
      if (a < 30) a = 30;
        m->uring_per_sqe_ns = b; m->uring_fixed_ns = a;
        /* one READV SQE carrying k iovecs (file-contiguous, strided in memory): slope = per-iovec cost on top of the SQE */
        adio_req qv[64];
        for (int i = 0; i < 64; i++) { qv[i].fd = fd; qv[i].off = i * 64; qv[i].len = 64; qv[i].buf = buf + i * 128; }
        tmp.force = ADIO_RING;
        static const int kv[3] = { 4, 16, 64 }; double xv[3], yv[3], av, bv;
        for (int j = 0; j < 3; j++) { TIME_LOOP(if (adio_read_batch(&tmp, qv, kv[j]) < 0) ok = 0); xv[j] = kv[j]; yv[j] = med(v) - kv[j] * 64 * g; }
        linfit(xv, yv, 3, &av, &bv);
        if (bv < 1) bv = 1;
        m->uring_per_iov_ns = bv;
        m->uring_ok = ok;
        free(tmp.ord); free(tmp.runs); free(tmp.iov);
        ring_close(&rg);
    } else m->uring_ok = 0;
    free(buf); close(fd);
    return 0;
}

int adio_calibrate(adio_model *m) { return adio_calibrate_in(m, NULL); }

adio_ctx *adio_open_in(const char *dir)
{
    adio_ctx *c = calloc(1, sizeof *c); if (!c) return NULL;
    c->ring.fd = -1; c->force = ADIO_AUTO;
    if (adio_calibrate_in(&c->m, dir)) adio_model_default(&c->m);
    return c;
}

adio_ctx *adio_open(int calibrate)
{
    adio_ctx *c = calloc(1, sizeof *c); if (!c) return NULL;
    c->ring.fd = -1; c->force = ADIO_AUTO;
    if (calibrate) { if (adio_calibrate(&c->m)) adio_model_default(&c->m); } else adio_model_default(&c->m);
    return c;
}
void adio_close(adio_ctx *c)
{
    if (!c) return;
    ring_close(&c->ring); free(c->ord); free(c->runs); free(c->iov); free(c);
}
const adio_model *adio_get_model(const adio_ctx *c) { return &c->m; }
void adio_set_model(adio_ctx *c, const adio_model *m) { c->m = *m; }
void adio_force(adio_ctx *c, adio_strategy s) { c->force = s; }
