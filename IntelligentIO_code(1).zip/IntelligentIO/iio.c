/*
 * iio - developer-invoked front end for IntelligentI/O.            v0.3
 *
 *   iio record  [--root R[:R2]] [--out DIR] -- cmd...      record one session
 *   iio train   -o m.iiom [--manifest F] [--prior N] [--root R] [--window N]
 *               [--burst-us N] [--min-count N] [--max-edges N] [trace...]
 *   iio eval    [--model m] [--horizon N] [--manifest F] trace...
 *   iio curve   [--ks 1,2,4,8] [--manifest F] [--root R] trace...
 *   iio run     --model m [flags] -- cmd...                A/B-able live run
 *   iio bench   --model m [--runs N] [--cold auto|drop|fadvise|none] -- cmd...
 *   iio replay  [--manifest F] [--runs N] trace trace...   cold replay of recorded sessions
 *   iio doctor  [--dir D] [--size-mb N]                    can this machine do cold-cache tests?
 *   iio evict   --model m [--root R]
 *   iio inspect model
 *
 * Nothing here installs anything or stays resident: the helper library is
 * injected only into the one process tree started by record/run/bench.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "iio_common.h"
#include "adio/adio.h"

static void die(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    fprintf(stderr, "iio: "); vfprintf(stderr, fmt, ap); fprintf(stderr, "\n");
    va_end(ap); exit(1);
}

static double now_s(void)
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static void usage(void)
{
    fputs(
"iio " IIO_VERSION_STR " - IntelligentI/O (BCL-3 file-open predictor + prefetcher)\n\n"
"  iio record [--root R[:R2]] [--out DIR] -- cmd...   record one session\n"
"  iio train  -o model.iiom [--manifest F] [--prior N] [--root R] [--window N]\n"
"             [--burst-us N] [--min-count N] [--max-edges N] [trace...]\n"
"                                                     build the model (manifest-only is fine)\n"
"  iio eval   [--model m] [--horizon N] [--manifest F] trace...   leave-one-out accuracy\n"
"  iio curve  [--ks 1,2,4,8] [--manifest F] [--root R] trace...   accuracy vs #sessions learned\n"
"  iio run    --model m [--stats] [--baseline] [--residency] [--verbose] [--root R]\n"
"             [--thr X] [--depth N] [--order 1|2] [--threads N] [--budget-mb N]\n"
"             [--spec-mb N] [--jit] [--lead-ms N] [--jit-frac X] [--no-memguard]\n"
"             [--method readahead|fadvise] -- cmd...\n"
"  iio run    --hints -- cmd...                       only the iio_hint() API, no model\n"
"  iio bench  --model m [--runs N] [--cold auto|drop|fadvise|none] -- cmd...\n"
"                                                     cold-cache A/B (cmd must exit)\n"
"  iio replay [--manifest F] [--runs N] [--root R] [--think-ms N] trace trace...\n"
"                                                     replay recorded sessions cold, with/without iio\n"
"  iio run ... --timeline F                           also write a timestamped open log\n"
"  iio loads  [--gap-ms N] name:file ...              in-game load durations from timelines\n"
"  iio doctor [--dir D] [--size-mb N]                 is a cold-cache benchmark valid here?\n"
"  iio evict  --model m [--root R]                    drop modeled files from page cache\n"
"  iio inspect model\n", stderr);
    exit(2);
}

/* ------------------------------------------------------------ helpers */
static const char *find_lib(char *buf, size_t n)
{
    const char *e = getenv("IIO_LIB");
    if (e) return e;
    char self[PATH_MAX], tmp[PATH_MAX];
    ssize_t k = readlink("/proc/self/exe", self, sizeof self - 1);
    if (k > 0) {
        self[k] = 0;
        char *d = dirname(self);
        snprintf(tmp, sizeof tmp, "%s/libiio.so", d);
        if (access(tmp, R_OK) == 0) { snprintf(buf, n, "%s", tmp); return buf; }
        snprintf(tmp, sizeof tmp, "%s/../lib/iio/libiio.so", d);
        if (access(tmp, R_OK) == 0) { snprintf(buf, n, "%s", tmp); return buf; }
    }
    static const char *cand[] = { "./libiio.so", "/usr/local/lib/iio/libiio.so",
                                  "/usr/lib/iio/libiio.so", "/usr/lib64/iio/libiio.so", NULL };
    for (int i = 0; cand[i]; i++)
        if (access(cand[i], R_OK) == 0) { snprintf(buf, n, "%s", cand[i]); return buf; }
    die("cannot find libiio.so (set IIO_LIB)");
    return NULL;
}

static void set_preload(void)
{
    char buf[PATH_MAX];
    const char *lib = find_lib(buf, sizeof buf);
    char full[PATH_MAX];
    if (!realpath(lib, full)) die("libiio.so: %s", strerror(errno));
    const char *old = getenv("LD_PRELOAD");
    char val[2 * PATH_MAX + 2];
    if (old && *old) snprintf(val, sizeof val, "%s:%s", full, old);
    else snprintf(val, sizeof val, "%s", full);
    setenv("LD_PRELOAD", val, 1);
}

static int run_cmd(char **argv, int quiet, double *wall)
{
    double t0 = now_s();
    fflush(NULL);
    pid_t pid = fork();
    if (pid < 0) die("fork: %s", strerror(errno));
    if (pid == 0) {
        if (getenv("IIO_MODE")) {            /* only this pid (and its exec chain) is instrumented */
            char ob[32]; snprintf(ob, sizeof ob, "%d", (int)getpid());
            setenv("IIO_OWNER_PID", ob, 1);
        }
        if (quiet) {
            int dn = open("/dev/null", O_WRONLY);
            if (dn >= 0) { dup2(dn, 1); dup2(dn, 2); }
        }
        execvp(argv[0], argv);
        fprintf(stderr, "iio: exec %s: %s\n", argv[0], strerror(errno));
        _exit(127);
    }
    int st = 0;
    while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {}
    if (wall) *wall = now_s() - t0;
    return WIFEXITED(st) ? WEXITSTATUS(st) : 128 + WTERMSIG(st);
}

static char **after_dashdash(int argc, char **argv, int *stop)
{
    for (int i = 0; i < argc; i++)
        if (!strcmp(argv[i], "--")) { *stop = i; return argv + i + 1; }
    *stop = argc;
    return NULL;
}

#define NEED_ARG() do { if (++i >= argc) usage(); } while (0)

/* ------------------------------------------------------------ record */
static int cmd_record(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *root = NULL, *out = "iio-traces";
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; }
        else if (!strcmp(argv[i], "--out")) { NEED_ARG(); out = argv[i]; }
        else usage();
    }
    mkdir(out, 0755);
    char *tmp = strdup(cmd[0]);
    char path[PATH_MAX];
    snprintf(path, sizeof path, "%s/%s.%ld.%d.trace", out, basename(tmp), (long)time(NULL), (int)getpid());
    setenv("IIO_MODE", "record", 1);
    setenv("IIO_TRACE", path, 1);
    if (root) setenv("IIO_ROOT", root, 1);
    set_preload();
    int rc = run_cmd(cmd, 0, NULL);
    fprintf(stderr, "iio: trace written to %s (exit %d)\n", path, rc);
    return rc;
}

/* ------------------------------------------------------------ train */
static void split_roots(const char *list, char **out, uint32_t *n)
{
    char *dup = strdup(list), *save = NULL;
    *n = 0;
    for (char *t = strtok_r(dup, ":", &save); t && *n < IIO_MAX_ROOTS; t = strtok_r(NULL, ":", &save))
        out[(*n)++] = strdup(t);
    free(dup);
}

static int cmd_train(int argc, char **argv)
{
    const char *out = NULL, *manifest = NULL, *rootarg = NULL;
    int window = 8, burst = 5000, min_cnt = 1, max_edges = 0, prior = 6;
    int nfiles = 0; char **files = calloc(argc + 1, sizeof *files);
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-o")) { NEED_ARG(); out = argv[i]; }
        else if (!strcmp(argv[i], "--window")) { NEED_ARG(); window = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--burst-us")) { NEED_ARG(); burst = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--min-count")) { NEED_ARG(); min_cnt = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--max-edges")) { NEED_ARG(); max_edges = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--manifest")) { NEED_ARG(); manifest = argv[i]; }
        else if (!strcmp(argv[i], "--prior")) { NEED_ARG(); prior = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); rootarg = argv[i]; }
        else files[nfiles++] = argv[i];
    }
    if (!out || (!nfiles && !manifest)) usage();
    if (!max_edges) max_edges = manifest ? 64 : 24;
    iio_trainer *T = iio_trainer_new(window, burst);
    if (rootarg && !nfiles) {
        char *r[IIO_MAX_ROOTS]; uint32_t n;
        split_roots(rootarg, r, &n);
        iio_trainer_set_roots(T, r, n);
    }
    size_t events = 0;
    for (int i = 0; i < nfiles; i++) {
        iio_trace *t = iio_trace_load(files[i]);
        if (!t) die("cannot read %s", files[i]);
        events += t->n;
        iio_trainer_add(T, t);
        iio_trace_free(t);
    }
    int nrules = 0, nwarn = 0;
    if (manifest) {
        char err[512];
        nrules = iio_trainer_add_manifest(T, manifest, prior, err, sizeof err, &nwarn);
        if (nrules < 0) die("manifest %s: %s", manifest, err);
    }
    iio_model m;
    iio_trainer_finish(T, min_cnt, max_edges, &m);
    if (iio_model_save(&m, out)) die("cannot write %s", out);
    struct stat st; stat(out, &st);
    printf("trained on %d session(s), %zu opens", nfiles, events);
    if (manifest) printf(" + manifest (%d rules, prior %d, %d warnings)", nrules, prior, nwarn);
    printf(" -> %u files, %u contexts, %u edges, %lld bytes\n",
           m.st.n - 1, m.n_ctx, m.n_edges, (long long)st.st_size);
    iio_model_free(&m); iio_trainer_free(T);
    return 0;
}

/* ------------------------------------------------------------ eval / curve */
typedef struct { const char *name; iio_params p; } variant;
typedef struct { long opens, known, hits, issued; } evres;

static void make_variants(variant v[4])
{
    for (int i = 0; i < 4; i++) iio_params_from_env(&v[i].p);
    v[0].name = "order-1, next-file only (v1-style)";
    v[0].p.use_o2 = 0; v[0].p.depth = 0; v[0].p.max_dist16 = 16; v[0].p.beta = 0;
    v[1].name = "order-1 + lookahead window (Griffioen-Appleton)";
    v[1].p.use_o2 = 0; v[1].p.depth = 0; v[1].p.beta = 0;
    v[2].name = "order-2 blend + lookahead";
    v[2].p.use_o2 = 1; v[2].p.depth = 0; v[2].p.beta = 0;
    v[3].name = "BCL: order-2 + burst bonus + chaining";
}

static void eval_trace(const iio_model *m, const iio_params *p, const iio_trace *tr,
                       int horizon, evres *r)
{
    long *pred_at = malloc((m->st.n + 1) * sizeof *pred_at);
    for (uint32_t i = 0; i < m->st.n; i++) pred_at[i] = -1;
    uint32_t prev = IIO_NONE, cur = IIO_START;
    iio_cand cand[IIO_MAXC];
    long k = 0;
    int n = iio_predict(m, p, prev, cur, cand, IIO_MAXC);
    for (int i = 0; i < n; i++) { pred_at[cand[i].id] = 0; r->issued++; }
    for (size_t e = 0; e < tr->n; e++) {
        r->opens++;
        uint32_t id = iio_st_find(&m->st, tr->key[e]);
        if (id == IIO_NONE || id == IIO_START) continue;
        k++; r->known++;
        if (pred_at[id] >= 0 && k - pred_at[id] <= horizon) r->hits++;
        pred_at[id] = -1;
        prev = cur; cur = id;
        n = iio_predict(m, p, prev, cur, cand, IIO_MAXC);
        for (int i = 0; i < n; i++) {
            uint32_t c = cand[i].id;
            if (pred_at[c] < 0 || k - pred_at[c] > horizon) { pred_at[c] = k; r->issued++; }
        }
    }
    free(pred_at);
}

static int load_manifest_into(iio_trainer *T, const char *manifest, int prior)
{
    char err[512]; int nw = 0;
    int r = iio_trainer_add_manifest(T, manifest, prior, err, sizeof err, &nw);
    if (r < 0) die("manifest %s: %s", manifest, err);
    return r;
}

static void build_model(iio_trace **tr, const int *idx, int n, int window, int burst,
                        const char *manifest, char *const *roots, uint32_t nroots, iio_model *m)
{
    iio_trainer *T = iio_trainer_new(window, burst);
    if (nroots && !n) iio_trainer_set_roots(T, roots, nroots);
    for (int i = 0; i < n; i++) iio_trainer_add(T, tr[idx[i]]);
    if (manifest) load_manifest_into(T, manifest, 6);
    iio_trainer_finish(T, 1, manifest ? 64 : 24, m);
    iio_trainer_free(T);
}

static int cmd_eval(int argc, char **argv)
{
    const char *model = NULL, *manifest = NULL; int horizon = 16, nfiles = 0, window = 8, burst = 5000;
    char **files = calloc(argc + 1, sizeof *files);
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--horizon")) { NEED_ARG(); horizon = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--window")) { NEED_ARG(); window = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--burst-us")) { NEED_ARG(); burst = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--manifest")) { NEED_ARG(); manifest = argv[i]; }
        else files[nfiles++] = argv[i];
    }
    if (!nfiles || (!model && nfiles < 2)) usage();

    variant v[4]; make_variants(v);
    iio_trace **tr = calloc(nfiles, sizeof *tr);
    for (int i = 0; i < nfiles; i++)
        if (!(tr[i] = iio_trace_load(files[i]))) die("cannot read %s", files[i]);

    evres res[4]; memset(res, 0, sizeof res);
    if (model) {
        iio_model m;
        if (iio_model_load(&m, model)) die("cannot load %s", model);
        for (int a = 0; a < 4; a++)
            for (int i = 0; i < nfiles; i++) eval_trace(&m, &v[a].p, tr[i], horizon, &res[a]);
        iio_model_free(&m);
        printf("evaluating on %d trace(s) with model %s (NOT held out: optimistic)\n", nfiles, model);
    } else {
        for (int hold = 0; hold < nfiles; hold++) {
            int idx[256], n = 0;
            for (int i = 0; i < nfiles && n < 256; i++) if (i != hold) idx[n++] = i;
            iio_model m;
            build_model(tr, idx, n, window, burst, manifest, NULL, 0, &m);
            for (int a = 0; a < 4; a++) eval_trace(&m, &v[a].p, tr[hold], horizon, &res[a]);
            iio_model_free(&m);
        }
        printf("leave-one-out over %d traces (each trace predicted by a model that never saw it)%s\n",
               nfiles, manifest ? " [+manifest]" : "");
    }
    printf("hit = file opened within %d opens after being predicted\n\n", horizon);
    printf("%-50s %9s %9s %10s %12s\n", "variant", "cover/knw", "cover/all", "precision", "issued/open");
    for (int a = 0; a < 4; a++)
        printf("%-50s %8.1f%% %8.1f%% %9.1f%% %12.2f\n", v[a].name,
               res[a].known ? 100.0 * res[a].hits / res[a].known : 0.0,
               res[a].opens ? 100.0 * res[a].hits / res[a].opens : 0.0,
               res[a].issued ? 100.0 * res[a].hits / res[a].issued : 0.0,
               res[a].known ? (double)res[a].issued / res[a].known : 0.0);
    for (int i = 0; i < nfiles; i++) iio_trace_free(tr[i]);
    return 0;
}

/* learning curve: train on k sessions, predict a held-out one; all rotations */
static int cmd_curve(int argc, char **argv)
{
    const char *manifest = NULL, *rootarg = NULL, *kslist = "1,2,4,8";
    int horizon = 16, nfiles = 0, window = 8, burst = 5000;
    char **files = calloc(argc + 1, sizeof *files);
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--ks")) { NEED_ARG(); kslist = argv[i]; }
        else if (!strcmp(argv[i], "--manifest")) { NEED_ARG(); manifest = argv[i]; }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); rootarg = argv[i]; }
        else if (!strcmp(argv[i], "--horizon")) { NEED_ARG(); horizon = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--window")) { NEED_ARG(); window = atoi(argv[i]); }
        else files[nfiles++] = argv[i];
    }
    if (nfiles < 2) usage();
    iio_trace **tr = calloc(nfiles, sizeof *tr);
    for (int i = 0; i < nfiles; i++)
        if (!(tr[i] = iio_trace_load(files[i]))) die("cannot read %s", files[i]);
    variant v[4]; make_variants(v);
    char *roots[IIO_MAX_ROOTS]; uint32_t nroots = 0;
    if (rootarg) split_roots(rootarg, roots, &nroots);

    printf("learning curve over %d traces: train on k sessions, predict a held-out one "
           "(every rotation)\nhorizon=%d opens; cover = predicted-in-time / ALL opens "
           "(unseen files count against it)\n\n", nfiles, horizon);
    printf("%3s | %6s | %-17s | %-17s | %-17s%s\n", "k", "unseen", "order-1 next-only",
           "+lookahead (G&A)", "BCL (no manifest)", manifest ? " | BCL + manifest" : "");
    printf("%3s | %6s | %-8s %-8s | %-8s %-8s | %-8s %-8s%s\n", "", "files", "cover", "prec",
           "cover", "prec", "cover", "prec", manifest ? " | cover    prec" : "");

    /* k = 0 row only makes sense with a manifest */
    char *dup = strdup(kslist), *save = NULL;
    int ks[32], nk = 0;
    if (manifest) ks[nk++] = 0;
    for (char *t = strtok_r(dup, ",", &save); t && nk < 32; t = strtok_r(NULL, ",", &save)) {
        int k = atoi(t);
        if (k >= 1 && k <= nfiles - 1) ks[nk++] = k;
    }
    for (int q = 0; q < nk; q++) {
        int k = ks[q];
        evres r[3]; memset(r, 0, sizeof r);        /* v1, G&A, BCL */
        evres rm; memset(&rm, 0, sizeof rm);       /* BCL + manifest */
        long unseen = 0, opens = 0;
        int reps = k == 0 ? 1 : nfiles;
        for (int hold = 0; hold < reps; hold++) {
            int idx[256], n = 0;
            for (int d = 1; d <= nfiles && n < k; d++) { int j = (hold + d) % nfiles; if (j != hold) idx[n++] = j; }
            const iio_trace *test = tr[k == 0 ? 0 : hold];
            if (k == 0) {                          /* manifest only: score on every trace */
                iio_model mm;
                build_model(tr, idx, 0, window, burst, manifest, roots, nroots, &mm);
                for (int i = 0; i < nfiles; i++) eval_trace(&mm, &v[3].p, tr[i], horizon, &rm);
                for (int i = 0; i < nfiles; i++) {
                    for (size_t e = 0; e < tr[i]->n; e++)
                        if (iio_st_find(&mm.st, tr[i]->key[e]) == IIO_NONE) unseen++;
                    opens += (long)tr[i]->n;
                }
                iio_model_free(&mm);
                continue;
            }
            iio_model m;
            build_model(tr, idx, n, window, burst, NULL, NULL, 0, &m);
            eval_trace(&m, &v[0].p, test, horizon, &r[0]);
            eval_trace(&m, &v[1].p, test, horizon, &r[1]);
            eval_trace(&m, &v[3].p, test, horizon, &r[2]);
            for (size_t e = 0; e < test->n; e++)
                if (iio_st_find(&m.st, test->key[e]) == IIO_NONE) unseen++;
            opens += (long)test->n;
            iio_model_free(&m);
            if (manifest) {
                iio_model mm;
                build_model(tr, idx, n, window, burst, manifest, NULL, 0, &mm);
                eval_trace(&mm, &v[3].p, test, horizon, &rm);
                iio_model_free(&mm);
            }
        }
        if (k == 0) {
            printf("%3d | %5.1f%% | %-8s %-8s | %-8s %-8s | %-8s %-8s | %7.1f%% %7.1f%%\n", 0,
                   opens ? 100.0 * unseen / opens : 0.0, "-", "-", "-", "-", "-", "-",
                   rm.opens ? 100.0 * rm.hits / rm.opens : 0.0, rm.issued ? 100.0 * rm.hits / rm.issued : 0.0);
            continue;
        }
        printf("%3d | %5.1f%% |", k, opens ? 100.0 * unseen / opens : 0.0);
        for (int a = 0; a < 3; a++)
            printf(" %7.1f%% %7.1f%% |", r[a].opens ? 100.0 * r[a].hits / r[a].opens : 0.0,
                   r[a].issued ? 100.0 * r[a].hits / r[a].issued : 0.0);
        if (manifest)
            printf(" %7.1f%% %7.1f%%", rm.opens ? 100.0 * rm.hits / rm.opens : 0.0,
                   rm.issued ? 100.0 * rm.hits / rm.issued : 0.0);
        printf("\n");
    }
    return 0;
}

/* ------------------------------------------------------------ cold cache */
static int drop_all_caches(void)
{
    sync();
    int fd = open("/proc/sys/vm/drop_caches", O_WRONLY);
    if (fd < 0) return -1;
    int rc = write(fd, "3\n", 2) == 2 ? 0 : -1;
    close(fd);
    return rc;
}

static double fd_residency(int fd)
{
    struct stat st;
    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0) return -1;
    long ps = sysconf(_SC_PAGESIZE);
    size_t pages = ((size_t)st.st_size + ps - 1) / ps;
    void *a = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_SHARED, fd, 0);
    if (a == MAP_FAILED) return -1;
    unsigned char *vec = malloc(pages);
    double r = -1;
    if (vec && mincore(a, (size_t)st.st_size, vec) == 0) {
        size_t c = 0;
        for (size_t i = 0; i < pages; i++) c += vec[i] & 1;
        r = (double)c / (double)pages;
    }
    free(vec);
    munmap(a, (size_t)st.st_size);
    return r;
}

static void model_roots(const iio_model *m, const char *root_override, char **roots, uint32_t *nr, char **dup)
{
    *nr = m->n_roots;
    for (uint32_t i = 0; i < *nr; i++) roots[i] = m->roots[i];
    *dup = NULL;
    if (root_override) {
        *dup = strdup(root_override);
        char *save; uint32_t i = 0;
        for (char *t = strtok_r(*dup, ":", &save); t && i < IIO_MAX_ROOTS; t = strtok_r(NULL, ":", &save)) roots[i++] = t;
        *nr = i;
    }
}

static int do_evict(const iio_model *m, const char *root_override)
{
    char *roots[IIO_MAX_ROOTS] = { 0 }; uint32_t nr; char *dup;
    model_roots(m, root_override, roots, &nr, &dup);
    int done = 0;
    for (uint32_t id = 1; id < m->st.n; id++) {
        char p[PATH_MAX];
        if (iio_key_to_path(roots, nr, m->st.s[id], p, sizeof p)) continue;
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        fdatasync(fd);                       /* dirty pages are skipped by DONTNEED */
        posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
        close(fd); done++;
    }
    free(dup);
    return done;
}

/* average page residency of up to `maxfiles` evenly spaced model files */
static double sample_residency(const iio_model *m, const char *root_override, int maxfiles, int *nsampled)
{
    char *roots[IIO_MAX_ROOTS] = { 0 }; uint32_t nr; char *dup;
    model_roots(m, root_override, roots, &nr, &dup);
    uint32_t total = m->st.n > 1 ? m->st.n - 1 : 0;
    uint32_t step = total > (uint32_t)maxfiles ? total / (uint32_t)maxfiles : 1;
    double sum = 0; int cnt = 0;
    for (uint32_t id = 1; id < m->st.n && cnt < maxfiles; id += step) {
        char p[PATH_MAX];
        if (iio_key_to_path(roots, nr, m->st.s[id], p, sizeof p)) continue;
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        if (fd < 0) continue;
        double r = fd_residency(fd);
        close(fd);
        if (r >= 0) { sum += r; cnt++; }
    }
    free(dup);
    *nsampled = cnt;
    return cnt ? sum / cnt : -1;
}

static int cmd_evict(int argc, char **argv)
{
    const char *model = NULL, *root = NULL;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; }
        else usage();
    }
    if (!model) usage();
    iio_model m; if (iio_model_load(&m, model)) die("cannot load %s", model);
    int n = do_evict(&m, root);
    int cnt; double r = sample_residency(&m, root, 64, &cnt);
    printf("asked the kernel to drop %d file(s); %.0f%% of sampled pages still resident afterwards.\n", n, r * 100);
    if (r > 0.5)
        printf("-> eviction did NOT work on this filesystem. Use `sudo iio bench --cold drop`, or run `iio doctor`.\n");
    iio_model_free(&m);
    return 0;
}

static int cmd_inspect(int argc, char **argv)
{
    if (argc < 1) usage();
    iio_model m; if (iio_model_load(&m, argv[0])) die("cannot load %s", argv[0]);
    struct stat st; stat(argv[0], &st);
    printf("model %s: %lld bytes, %u files, %u contexts (%u edges), window=%u burst_gap=%uus\n",
           argv[0], (long long)st.st_size, m.st.n - 1, m.n_ctx, m.n_edges, m.window, m.burst_gap_us);
    for (uint32_t i = 0; i < m.n_roots; i++) printf("root @%u = %s\n", i, m.roots[i]);
    int best = -1;
    for (uint32_t i = 0; i < m.n_ctx; i++)
        if (m.ctx[i].b != IIO_NONE && (best < 0 || m.ctx[i].total > m.ctx[best].total)) best = (int)i;
    if (best >= 0) {
        const iio_ctx *c = &m.ctx[best];
        printf("\nbusiest order-2 context (%s -> %s), seen %u times:\n", m.st.s[c->a], m.st.s[c->b], c->total);
        for (uint32_t k = 0; k < c->n && k < 8; k++) {
            const iio_edge *e = &m.edges[c->first + k];
            printf("   %5.1f%%  dist=%4.1f  dt=%7uus  same-burst=%3u%%  %s\n",
                   100.0 * e->cnt / c->total, e->dist16 / 16.0, e->dt_us,
                   100u * e->bcnt / e->cnt, m.st.s[e->to]);
        }
    }
    const iio_ctx *s = iio_find_ctx(&m, IIO_START, IIO_NONE);
    if (s) {
        printf("\nat process start (%u edges):\n", s->n);
        for (uint32_t k = 0; k < s->n && k < 8; k++)
            printf("   %5.1f%%  %s\n", 100.0 * m.edges[s->first + k].cnt / s->total, m.st.s[m.edges[s->first + k].to]);
    }
    iio_model_free(&m);
    return 0;
}

/* ------------------------------------------------------------ run / bench */
static int apply_run_flag(const char *k)
{
    if (!strcmp(k, "--stats")) setenv("IIO_STATS", "1", 1);
    else if (!strcmp(k, "--baseline")) { setenv("IIO_NOPF", "1", 1); setenv("IIO_STATS", "1", 1); }
    else if (!strcmp(k, "--residency")) { setenv("IIO_STATS", "1", 1); setenv("IIO_RESIDENCY", "1", 1); }
    else if (!strcmp(k, "--verbose")) setenv("IIO_VERBOSE", "1", 1);
    else if (!strcmp(k, "--jit")) setenv("IIO_JIT", "1", 1);
    else if (!strcmp(k, "--no-memguard")) setenv("IIO_MEMGUARD", "0", 1);
    else if (!strcmp(k, "--hints")) { setenv("IIO_HINTS", "1", 1); setenv("IIO_STATS", "1", 1); }
    else return 0;
    return 1;
}

static void apply_run_opt(const char *k, const char *v)
{
    if (!strcmp(k, "--thr")) setenv("IIO_THR", v, 1);
    else if (!strcmp(k, "--depth")) setenv("IIO_DEPTH", v, 1);
    else if (!strcmp(k, "--order")) setenv("IIO_ORDER", v, 1);
    else if (!strcmp(k, "--threads")) setenv("IIO_THREADS", v, 1);
    else if (!strcmp(k, "--budget-mb")) setenv("IIO_BUDGET_MB", v, 1);
    else if (!strcmp(k, "--spec-mb")) setenv("IIO_SPEC_MB", v, 1);
    else if (!strcmp(k, "--ttl-ms")) setenv("IIO_TTL_MS", v, 1);
    else if (!strcmp(k, "--lead-ms")) setenv("IIO_LEAD_MS", v, 1);
    else if (!strcmp(k, "--jit-frac")) setenv("IIO_JIT_FRAC", v, 1);
    else if (!strcmp(k, "--method")) setenv("IIO_METHOD", v, 1);
    else if (!strcmp(k, "--root")) setenv("IIO_ROOT", v, 1);
    else if (!strcmp(k, "--timeline")) {         /* absolute: the program may chdir */
        char ab[PATH_MAX];
        if (v[0] != '/') { if (!getcwd(ab, sizeof ab)) die("getcwd"); size_t l = strlen(ab); snprintf(ab + l, sizeof ab - l, "/%s", v); }
        else snprintf(ab, sizeof ab, "%s", v);
        setenv("IIO_TIMELINE", ab, 1);
    }
    else usage();
}

static int cmd_run(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *model = NULL;
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (apply_run_flag(argv[i])) continue;
        else { const char *k = argv[i]; NEED_ARG(); apply_run_opt(k, argv[i]); }
    }
    setenv("IIO_MODE", "run", 1);
    if (model) {
        char mp[PATH_MAX]; if (!realpath(model, mp)) die("%s: %s", model, strerror(errno));
        setenv("IIO_MODEL", mp, 1);
    } else if (!getenv("IIO_HINTS")) usage();
    set_preload();
    double w; int rc = run_cmd(cmd, 0, &w);
    fprintf(stderr, "iio: wall time %.3fs (exit %d)\n", w, rc);
    return rc;
}

static int cmp_d(const void *a, const void *b) { double x = *(double *)a, y = *(double *)b; return x < y ? -1 : x > y; }

enum { COLD_AUTO, COLD_DROP, COLD_FADVISE, COLD_NONE };

static int make_cold(const iio_model *m, const char *root, int method)
{
    if (method == COLD_NONE) return COLD_NONE;
    if (method == COLD_AUTO || method == COLD_DROP) {
        if (drop_all_caches() == 0) return COLD_DROP;
        if (method == COLD_DROP) return -1;
    }
    do_evict(m, root);
    return COLD_FADVISE;
}

static int cmd_bench(int argc, char **argv)
{
    int stop; char **cmd = after_dashdash(argc, argv, &stop);
    if (!cmd || !cmd[0]) usage();
    const char *model = NULL; int runs = 5, cold = COLD_AUTO;
    for (int i = 0; i < stop; i++) {
        if (!strcmp(argv[i], "--model")) { NEED_ARG(); model = argv[i]; }
        else if (!strcmp(argv[i], "--runs")) { NEED_ARG(); runs = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--no-evict")) cold = COLD_NONE;
        else if (!strcmp(argv[i], "--cold")) {
            NEED_ARG();
            cold = !strcmp(argv[i], "drop") ? COLD_DROP : !strcmp(argv[i], "fadvise") ? COLD_FADVISE
                 : !strcmp(argv[i], "none") ? COLD_NONE : COLD_AUTO;
        }
        else if (apply_run_flag(argv[i])) continue;
        else { const char *k = argv[i]; NEED_ARG(); apply_run_opt(k, argv[i]); }
    }
    if (!model) usage();
    if (runs < 1) runs = 1;
    char mp[PATH_MAX]; if (!realpath(model, mp)) die("%s: %s", model, strerror(errno));
    iio_model m; if (iio_model_load(&m, mp)) die("cannot load %s", mp);
    const char *root = getenv("IIO_ROOT");
    double *a = calloc(runs, sizeof *a), *b = calloc(runs, sizeof *b);
    int warm_runs = 0, total_checks = 0;
    for (int r = 0; r < runs; r++) {
        for (int side = 0; side < 2; side++) {
            int used = make_cold(&m, root, cold);
            if (used < 0) die("cannot write /proc/sys/vm/drop_caches (need root). Use --cold fadvise or sudo.");
            if (cold != COLD_NONE) {
                int cnt; double res = sample_residency(&m, root, 48, &cnt);
                total_checks++;
                if (r == 0 && side == 0)
                    printf("cold check: method=%s, %.0f%% of sampled pages resident after clearing (%d files)\n",
                           used == COLD_DROP ? "drop_caches" : "fadvise", res * 100, cnt);
                if (res > 0.5) warm_runs++;
            }
            if (side == 0) {
                unsetenv("IIO_MODE"); unsetenv("LD_PRELOAD");
                run_cmd(cmd, 1, &a[r]);
            } else {
                setenv("IIO_MODE", "run", 1); setenv("IIO_MODEL", mp, 1); set_preload();
                run_cmd(cmd, 1, &b[r]);
                unsetenv("LD_PRELOAD");
            }
        }
        printf("run %d: baseline %.3fs   iio %.3fs\n", r + 1, a[r], b[r]);
    }
    double *sa = malloc(runs * sizeof *sa), *sb = malloc(runs * sizeof *sb);
    memcpy(sa, a, runs * sizeof *sa); memcpy(sb, b, runs * sizeof *sb);
    qsort(sa, runs, sizeof(double), cmp_d); qsort(sb, runs, sizeof(double), cmp_d);
    double ma = sa[runs / 2], mb = sb[runs / 2];
    printf("\nmedian: baseline %.3fs (min %.3f max %.3f)   iio %.3fs (min %.3f max %.3f)  -> %.1f%% %s\n",
           ma, sa[0], sa[runs - 1], mb, sb[0], sb[runs - 1], 100.0 * fabs(ma - mb) / ma, mb < ma ? "faster" : "slower");
    if (cold == COLD_NONE)
        printf("NOTE: cache was not cleared (--cold none): this is a warm-cache comparison.\n");
    else if (warm_runs)
        printf("WARNING: the cache was still >50%% resident before %d of %d runs. These numbers are NOT\n"
               "         cold-cache results. Run `sudo iio doctor` to see what this machine supports.\n",
               warm_runs, total_checks);
    iio_model_free(&m);
    return 0;
}

/* ------------------------------------------------------------ doctor */
static const char *fs_name(long t)
{
    switch ((unsigned long)t) {
    case 0xEF53: return "ext2/3/4"; case 0x9123683E: return "btrfs"; case 0x58465342: return "xfs";
    case 0x01021994: return "tmpfs (RAM: nothing to evict!)"; case 0x794c7630: return "overlayfs";
    case 0xF2F52010: return "f2fs"; case 0x2fc12fc1: return "zfs"; case 0x6969: return "nfs";
    case 0x65735546: return "fuse"; case 0x4d44: return "vfat"; case 0x5346544e: return "ntfs";
    case 0x9fa0: return "procfs"; case 0x858458f6: return "ramfs"; case 0xCAFE4A11: return "bpf";
    default: return "other";
    }
}

static double read_all_mbps(int fd, size_t size)
{
    size_t chunk = 1 << 20;
    char *buf = malloc(chunk);
    double t0 = now_s();
    size_t done = 0;
    while (done < size) {
        ssize_t n = pread(fd, buf, chunk, (off_t)done);
        if (n <= 0) break;
        done += (size_t)n;
    }
    double dt = now_s() - t0;
    free(buf);
    return dt > 0 ? (done / 1048576.0) / dt : 0;
}

static int cmp_u(const void *a, const void *b) { double x = *(double *)a, y = *(double *)b; return x < y ? -1 : x > y; }

static long long now_ns_doctor(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000LL+t.tv_nsec;}
static int cmd_doctor(int argc, char **argv)
{
    const char *dir = "."; int size_mb = 128;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--dir")) { NEED_ARG(); dir = argv[i]; }
        else if (!strcmp(argv[i], "--size-mb")) { NEED_ARG(); size_mb = atoi(argv[i]); }
        else usage();
    }
    if (size_mb < 16) size_mb = 16;
    struct utsname u; uname(&u);
    long ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    printf("iio doctor %s on %s %s, %ld cpu(s), uid=%d%s\n", IIO_VERSION_STR, u.sysname, u.release, ncpu,
           (int)geteuid(), geteuid() == 0 ? " (root)" : " (not root: drop_caches test will be skipped)");
    struct statfs sf;
    if (statfs(dir, &sf) == 0) printf("test dir %s: filesystem %s\n", dir, fs_name((long)sf.f_type));
    if (sf.f_type == 0x01021994 || sf.f_type == 0x858458f6) {
        printf("FAIL: %s is RAM-backed. Choose a directory on a real disk with --dir (not /tmp on Fedora).\n", dir);
        return 1;
    }
    { adio_model am; long long t0 = now_ns_doctor();
      if (adio_calibrate_in(&am, dir) == 0)
          printf("adio batch-read costs here (cached, %.1f ms): pread %.0f ns, preadv %.0f+%.0f/iov, io_uring %.0f+%.0f/sqe%s\n",
                 (now_ns_doctor() - t0) / 1e6, am.pread_fixed_ns, am.preadv_fixed_ns, am.preadv_per_iov_ns,
                 am.uring_fixed_ns, am.uring_per_sqe_ns, am.uring_ok ? "" : " (io_uring unavailable)"); }
    char path[PATH_MAX]; snprintf(path, sizeof path, "%s/.iio-doctor.XXXXXX", dir);
    int fd = mkstemp(path);
    if (fd < 0) die("cannot create test file in %s: %s", dir, strerror(errno));
    unlink(path);
    size_t size = (size_t)size_mb << 20, chunk = 1 << 20;
    uint64_t *buf = malloc(chunk), x = 88172645463325252ull;
    for (size_t w = 0; w < size; w += chunk) {             /* incompressible data */
        for (size_t i = 0; i < chunk / 8; i++) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; buf[i] = x; }
        if (write(fd, buf, chunk) != (ssize_t)chunk) die("write failed: %s", strerror(errno));
    }
    fsync(fd);
    printf("\ncreated %d MB test file\n", size_mb);
    printf("  residency right after writing           : %5.1f%%\n", fd_residency(fd) * 100);

    fdatasync(fd); posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
    double r_fad = fd_residency(fd);
    printf("  residency after posix_fadvise(DONTNEED) : %5.1f%%   %s\n", r_fad * 100,
           r_fad < 0.1 ? "(works)" : "(DOES NOT WORK on this filesystem/kernel)");
    double r_drop = -1;
    if (geteuid() == 0) {
        if (drop_all_caches() == 0) {
            r_drop = fd_residency(fd);
            printf("  residency after drop_caches             : %5.1f%%   %s\n", r_drop * 100,
                   r_drop < 0.1 ? "(works)" : "(mincore still reports cached - see timing below)");
        } else printf("  drop_caches                             : not writable (container/sandbox?)\n");
    } else printf("  drop_caches                             : skipped (run with sudo)\n");

    int method = (r_drop >= 0 && r_drop < 0.1) ? COLD_DROP : (r_fad < 0.1 ? COLD_FADVISE : COLD_DROP);
    int can_drop = geteuid() == 0 && r_drop >= 0;
    #define MAKE_COLD() do { if (method == COLD_DROP && can_drop) drop_all_caches(); \
                             else { fdatasync(fd); posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED); } } while (0)
    MAKE_COLD();
    double cold = read_all_mbps(fd, size);
    double warm = read_all_mbps(fd, size);
    printf("\ntiming (ground truth; independent of mincore):\n");
    printf("  cold sequential read : %9.0f MB/s\n  warm sequential read : %9.0f MB/s   (ratio %.1fx)\n",
           cold, warm, cold > 0 ? warm / cold : 0);

    MAKE_COLD();
    enum { NS = 96 }; double lat[NS];
    uint64_t s = 12345;
    char *rb = malloc(16384);
    for (int i = 0; i < NS; i++) {
        s = s * 6364136223846793005ull + 1442695040888963407ull;
        off_t off = (off_t)((s >> 20) % (size / 16384)) * 16384;
        double t0 = now_s();
        if (pread(fd, rb, 16384, off) < 0) {}
        lat[i] = (now_s() - t0) * 1e6;
    }
    qsort(lat, NS, sizeof lat[0], cmp_u);
    printf("  cold random 16K read : p50 %.0f us, p99 %.0f us  (%s)\n", lat[NS / 2], lat[NS * 99 / 100],
           lat[NS / 2] < 250 ? "NVMe-class" : lat[NS / 2] < 3000 ? "SATA-SSD-class" : "HDD/network-class");

    double ratio = cold > 0 ? warm / cold : 0;
    printf("\nverdict:\n");
    if (ratio < 1.3) {
        printf("  * cold is not meaningfully slower than warm (%.1fx). Either the cache is not really\n"
               "    being cleared here, or the storage is as fast as RAM for this access pattern.\n"
               "    Either way a cold-cache prefetch benchmark on this machine would show ~nothing,\n"
               "    and any big difference you measure is NOT caused by prefetching.\n", ratio);
        if (r_drop >= 0.9 || r_fad >= 0.9)
            printf("  * mincore/fincore reported high residency after clearing: do not trust `iio run\n"
                   "    --residency` numbers here; use wall-clock timing only.\n");
    } else {
        printf("  * cold reads are %.1fx slower than warm: cold-cache benchmarks are VALID here.\n", ratio);
        printf("    Clear the cache with: %s\n", method == COLD_DROP && can_drop ? "sudo iio bench --cold drop (recommended)" :
               "iio bench --cold fadvise (drop_caches needs sudo)");
        if (r_drop >= 0.9 && r_fad >= 0.9)
            printf("  * mincore says 'cached' even though timing says 'cold': residency lines are unreliable.\n");
    }
    printf("  * expected gain from prefetching scales with the cold-vs-warm gap; with a %.1fx gap the\n"
           "    ceiling is roughly the I/O share of your load time, never more.\n", ratio);
    close(fd);
    return 0;
}

/* ------------------------------------------------------------ replay
 * Replays the open sequence of a RECORDED session (real file names, real order)
 * against a cold page cache, with and without the prefetcher, and reports how
 * long each "load" (a burst of opens) stalled on I/O. Needs no cooperation from
 * the program that made the trace, so it works for games that cannot exit.
 *
 * Fairness rules (also stated in the paper):
 *  - the prefetch model for trace h is trained on the OTHER traces only;
 *  - the baseline and iio runs of one (trace, round) are paired and alternate order;
 *  - inside a burst the replay does not sleep (gap-scale 0): that gives the
 *    prefetcher the least possible time to run ahead, i.e. it is conservative;
 *  - gaps between bursts (play time) are replayed but capped at --think-ms;
 *  - every file is read whole (up to --max-read-mb), which may differ from the
 *    program's real read pattern.
 */
static int cmd_replay_worker(int argc, char **argv)
{
    const char *trace = NULL, *out = NULL, *root = NULL;
    double burst_ms = 50, think_ms = 500, scale = 0; int maxmb = 16;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--trace")) { NEED_ARG(); trace = argv[i]; }
        else if (!strcmp(argv[i], "--out")) { NEED_ARG(); out = argv[i]; }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; }
        else if (!strcmp(argv[i], "--burst-ms")) { NEED_ARG(); burst_ms = atof(argv[i]); }
        else if (!strcmp(argv[i], "--think-ms")) { NEED_ARG(); think_ms = atof(argv[i]); }
        else if (!strcmp(argv[i], "--gap-scale")) { NEED_ARG(); scale = atof(argv[i]); }
        else if (!strcmp(argv[i], "--max-read-mb")) { NEED_ARG(); maxmb = atoi(argv[i]); }
    }
    if (!trace || !out) return 2;
    iio_trace *tr = iio_trace_load(trace);
    if (!tr) die("cannot read %s", trace);
    char *roots[IIO_MAX_ROOTS] = { 0 }; uint32_t nr = tr->n_roots; char *dup = NULL;
    for (uint32_t i = 0; i < nr; i++) roots[i] = tr->roots[i];
    if (root) {
        dup = strdup(root); nr = 0; char *sv;
        for (char *t = strtok_r(dup, ":", &sv); t && nr < IIO_MAX_ROOTS; t = strtok_r(NULL, ":", &sv)) roots[nr++] = t;
    }
    FILE *fo = fopen(out, "w");
    if (!fo) die("%s: %s", out, strerror(errno));
    size_t bsz = 256 * 1024; char *buf = malloc(bsz);
    uint64_t burst_us = (uint64_t)(burst_ms * 1000), cap_us = (uint64_t)(think_ms * 1000);
    size_t maxb = (size_t)maxmb << 20; uint32_t burst = 0;
    for (size_t i = 0; i < tr->n; i++) {
        uint64_t gap = i ? tr->t[i] - tr->t[i - 1] : 0;
        if (i && gap >= burst_us) { burst++; usleep(gap < cap_us ? gap : cap_us); }
        else if (gap && scale > 0) usleep((useconds_t)(gap * scale));
        char p[PATH_MAX];
        if (iio_key_to_path(roots, nr, tr->key[i], p, sizeof p)) continue;
        double t0 = now_s();
        int fd = open(p, O_RDONLY | O_CLOEXEC);
        size_t got = 0;
        if (fd >= 0) {
            ssize_t k;
            while (got < maxb && (k = read(fd, buf, bsz)) > 0) got += (size_t)k;
            close(fd);
        } else continue;                         /* missing file: not timed */
        fprintf(fo, "%u,%.0f,%zu\n", burst, (now_s() - t0) * 1e6, got);
    }
    fclose(fo); free(buf); free(dup); iio_trace_free(tr);
    return 0;
}

typedef struct { double *v; size_t n, cap; } dvec;
static void dv_add(dvec *d, double x)
{
    if (d->n == d->cap) { d->cap = d->cap ? d->cap * 2 : 256; d->v = realloc(d->v, d->cap * sizeof *d->v); }
    d->v[d->n++] = x;
}
static double dv_pct(dvec *d, double p)
{
    if (!d->n) return 0;
    qsort(d->v, d->n, sizeof(double), cmp_d);
    size_t k = (size_t)(p * (d->n - 1) + 0.5);
    return d->v[k];
}

#define RP_MAXC 3
typedef struct { const char *name; dvec loads, evs, tot; } rp_cond;

/* parse a worker CSV: per-burst stall (ms) for bursts with >= minev events, per-event ms, total ms */
static void rp_parse(const char *file, rp_cond *c, int minev, double *total_out)
{
    FILE *f = fopen(file, "r"); if (!f) die("cannot read %s", file);
    unsigned b, cb = 0; double us; size_t bytes; double stall = 0, tot = 0; int cnt = 0, any = 0;
    while (fscanf(f, "%u,%lf,%zu\n", &b, &us, &bytes) == 3) {
        if (any && b != cb) { if (cnt >= minev) dv_add(&c->loads, stall / 1000); stall = 0; cnt = 0; }
        cb = b; any = 1; stall += us; cnt++; tot += us; dv_add(&c->evs, us / 1000);
    }
    if (any && cnt >= minev) dv_add(&c->loads, stall / 1000);
    fclose(f);
    dv_add(&c->tot, tot / 1000); *total_out = tot / 1000;
}

static int cmd_replay(int argc, char **argv)
{
    const char *manifest = NULL, *root = NULL; int runs = 3, cold = COLD_AUTO, minev = 5, maxmb = 16;
    double burst_ms = 50, think_ms = 500, scale = 0;
    char **files = calloc(argc + 1, sizeof *files); int nfiles = 0;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--manifest")) { NEED_ARG(); manifest = argv[i]; }
        else if (!strcmp(argv[i], "--runs")) { NEED_ARG(); runs = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--root")) { NEED_ARG(); root = argv[i]; setenv("IIO_ROOT", argv[i], 1); }
        else if (!strcmp(argv[i], "--burst-ms")) { NEED_ARG(); burst_ms = atof(argv[i]); }
        else if (!strcmp(argv[i], "--think-ms")) { NEED_ARG(); think_ms = atof(argv[i]); }
        else if (!strcmp(argv[i], "--gap-scale")) { NEED_ARG(); scale = atof(argv[i]); }
        else if (!strcmp(argv[i], "--max-read-mb")) { NEED_ARG(); maxmb = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--min-events")) { NEED_ARG(); minev = atoi(argv[i]); }
        else if (!strcmp(argv[i], "--cold")) {
            NEED_ARG();
            cold = !strcmp(argv[i], "drop") ? COLD_DROP : !strcmp(argv[i], "fadvise") ? COLD_FADVISE : COLD_AUTO;
        }
        else if (apply_run_flag(argv[i])) continue;
        else if (argv[i][0] == '-' && argv[i][1] == '-') { const char *k = argv[i]; NEED_ARG(); apply_run_opt(k, argv[i]); }
        else files[nfiles++] = argv[i];
    }
    if (nfiles < 2) die("replay needs at least 2 traces (each is predicted by a model trained on the others)");
    if (runs < 1) runs = 1;
    char self[PATH_MAX]; ssize_t sl = readlink("/proc/self/exe", self, sizeof self - 1);
    if (sl <= 0) die("cannot find own path");
    self[sl] = 0;
    iio_trace **tr = calloc(nfiles, sizeof *tr);
    for (int i = 0; i < nfiles; i++) if (!(tr[i] = iio_trace_load(files[i]))) die("cannot read %s", files[i]);

    int nc = manifest ? 3 : 2;
    rp_cond cond[RP_MAXC]; memset(cond, 0, sizeof cond);
    cond[0].name = "baseline (no prefetch)"; cond[1].name = "iio (learned from other traces)";
    cond[2].name = "iio manifest only (no traces)";
    char tmpd[256]; snprintf(tmpd, sizeof tmpd, "/tmp/iio-replay-%d", (int)getpid());
    mkdir(tmpd, 0700);
    char csv[512]; snprintf(csv, sizeof csv, "%s/out.csv", tmpd);
    int warm = 0, checks = 0; int npair = 0, faster = 0; double *rel = calloc((size_t)nfiles * runs, sizeof *rel);
    printf("replaying %d traces, %d round(s) each; model for each trace is trained on the other %d\n",
           nfiles, runs, nfiles - 1);

    for (int h = 0; h < nfiles; h++) {
        int idx[256], n = 0;
        for (int i = 0; i < nfiles && n < 256; i++) if (i != h) idx[n++] = i;
        iio_model mod[RP_MAXC]; char mpath[RP_MAXC][512];
        build_model(tr, idx, n, 8, 5000, manifest, NULL, 0, &mod[1]);
        if (manifest) build_model(tr, idx, 0, 8, 5000, manifest, tr[h]->roots, tr[h]->n_roots, &mod[2]);
        for (int c = 1; c < nc; c++) {
            snprintf(mpath[c], 512, "%s/m%d_%d.iiom", tmpd, h, c);
            if (iio_model_save(&mod[c], mpath[c])) die("cannot write model");
        }
        double tot[RP_MAXC] = { 0 };
        for (int r = 0; r < runs; r++) {
            for (int s = 0; s < nc; s++) {
                int c = (s + r + h) % nc;           /* rotate condition order between rounds */
                int used = make_cold(&mod[1], root, cold);
                if (used < 0) die("cannot write /proc/sys/vm/drop_caches (need root). Use --cold fadvise or sudo.");
                int cnt; double res = sample_residency(&mod[1], root, 48, &cnt);
                checks++; if (res > 0.5) warm++;
                if (h == 0 && r == 0 && s == 0)
                    printf("cold check: method=%s, %.0f%% of sampled pages resident after clearing (%d files)\n",
                           used == COLD_DROP ? "drop_caches" : "fadvise", res * 100, cnt);
                char burst[32], think[32], gs[32], mm[16];
                snprintf(burst, sizeof burst, "%g", burst_ms); snprintf(think, sizeof think, "%g", think_ms);
                snprintf(gs, sizeof gs, "%g", scale); snprintf(mm, sizeof mm, "%d", maxmb);
                char *wa[24]; int k = 0;
                wa[k++] = self; wa[k++] = "replay-worker"; wa[k++] = "--trace"; wa[k++] = files[h];
                wa[k++] = "--out"; wa[k++] = csv; wa[k++] = "--burst-ms"; wa[k++] = burst;
                wa[k++] = "--think-ms"; wa[k++] = think; wa[k++] = "--gap-scale"; wa[k++] = gs;
                wa[k++] = "--max-read-mb"; wa[k++] = mm;
                if (root) { wa[k++] = "--root"; wa[k++] = (char *)root; }
                wa[k] = NULL;
                unlink(csv);
                if (c == 0) { unsetenv("IIO_MODE"); unsetenv("LD_PRELOAD"); }
                else { setenv("IIO_MODE", "run", 1); setenv("IIO_MODEL", mpath[c], 1); set_preload(); }
                run_cmd(wa, 1, NULL);
                unsetenv("LD_PRELOAD"); unsetenv("IIO_MODE");
                double t; rp_parse(csv, &cond[c], minev, &t); tot[c] = t;
            }
            rel[npair] = (tot[1] - tot[0]) / tot[0] * 100; npair++; if (tot[1] < tot[0]) faster++;
            printf("trace %d round %d: total I/O stall baseline %.0f ms, iio %.0f ms%s\n", h + 1, r + 1, tot[0], tot[1],
                   manifest ? "" : "");
        }
        for (int c = 1; c < nc; c++) { iio_model_free(&mod[c]); unlink(mpath[c]); }
    }
    unlink(csv); rmdir(tmpd);
    printf("\nper-load stall = summed open+read time of one burst of opens (bursts with >= %d opens), ms\n", minev);
    printf("%-34s %7s %7s %7s %7s %7s | %8s %8s\n", "condition", "loads", "p50", "p95", "p99", "max", "ev p95", "ev p99");
    for (int c = 0; c < nc; c++) {
        double mx = 0; for (size_t i = 0; i < cond[c].loads.n; i++) if (cond[c].loads.v[i] > mx) mx = cond[c].loads.v[i];
        printf("%-34s %7zu %7.1f %7.1f %7.1f %7.1f | %8.2f %8.2f\n", cond[c].name, cond[c].loads.n,
               dv_pct(&cond[c].loads, .5), dv_pct(&cond[c].loads, .95), dv_pct(&cond[c].loads, .99), mx,
               dv_pct(&cond[c].evs, .95), dv_pct(&cond[c].evs, .99));
    }
    qsort(rel, npair, sizeof(double), cmp_d);
    printf("\ntotal I/O stall per replay, iio vs baseline (paired by trace and round): median %+.1f%%, "
           "range %+.1f%% .. %+.1f%%, faster in %d of %d pairs\n", rel[npair / 2], rel[0], rel[npair - 1], faster, npair);
    printf("(negative = less time waiting on storage)\n");
    if (warm) printf("WARNING: the cache was still >50%% resident before %d of %d runs; run `sudo iio doctor`.\n", warm, checks);
    printf("Caveat: replay reads each file whole and does not pause inside a load; real programs differ.\n");
    return 0;
}

/* ------------------------------------------------------------ loads
 * In-game load times from timelines written by `iio run --timeline F`.
 * A load = a burst of opens with no gap >= --gap-ms; its duration is first open to last open.
 * Every file is opened after the previous one was read, so a slow read delays the next open:
 * the duration includes storage stalls, but not the final file's own read.
 *   iio loads [--gap-ms N] [--min-events N] name:file name:file ...
 */
static int cmd_loads(int argc, char **argv)
{
    double gap_ms = 400; int minev = 5, ngrp = 0;
    struct { char name[48]; dvec d; } g[8]; memset(g, 0, sizeof g);
    int verbose_files = 1;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--gap-ms")) { NEED_ARG(); gap_ms = atof(argv[i]); continue; }
        if (!strcmp(argv[i], "--min-events")) { NEED_ARG(); minev = atoi(argv[i]); continue; }
        char *col = strchr(argv[i], ':');
        if (!col) die("expected name:file, got %s", argv[i]);
        char nm[48]; snprintf(nm, sizeof nm, "%.*s", (int)(col - argv[i]) > 47 ? 47 : (int)(col - argv[i]), argv[i]);
        int gi = -1;
        for (int k = 0; k < ngrp; k++) if (!strcmp(g[k].name, nm)) gi = k;
        if (gi < 0) { if (ngrp == 8) die("at most 8 groups"); gi = ngrp++; snprintf(g[gi].name, 48, "%s", nm); }
        iio_trace *tr = iio_trace_load(col + 1);
        if (!tr) die("cannot read %s", col + 1);
        uint64_t gap = (uint64_t)(gap_ms * 1000); size_t start = 0, nload = 0;
        if (verbose_files) printf("%-12s %s:", nm, col + 1);
        for (size_t e = 1; e <= tr->n; e++) {
            if (e == tr->n || tr->t[e] - tr->t[e - 1] >= gap) {
                if ((int)(e - start) >= minev) {
                    double ms = (tr->t[e - 1] - tr->t[start]) / 1000.0;
                    dv_add(&g[gi].d, ms); nload++;
                    if (verbose_files) printf(" %.0f", ms);
                }
                start = e;
            }
        }
        if (verbose_files) printf("   (%zu loads, ms)\n", nload);
        iio_trace_free(tr);
    }
    if (!ngrp) die("usage: iio loads [--gap-ms N] [--min-events N] name:file ...");
    printf("\nload duration (first to last open of a burst of >= %d opens, gap < %.0f ms), ms\n", minev, gap_ms);
    printf("%-14s %6s %8s %8s %8s %8s\n", "condition", "loads", "p50", "p95", "max", "mean");
    double med[8];
    for (int k = 0; k < ngrp; k++) {
        double mx = 0, sm = 0; for (size_t i = 0; i < g[k].d.n; i++) { sm += g[k].d.v[i]; if (g[k].d.v[i] > mx) mx = g[k].d.v[i]; }
        med[k] = dv_pct(&g[k].d, .5);
        printf("%-14s %6zu %8.0f %8.0f %8.0f %8.0f\n", g[k].name, g[k].d.n, med[k], dv_pct(&g[k].d, .95), mx,
               g[k].d.n ? sm / g[k].d.n : 0);
    }
    for (int k = 1; k < ngrp; k++)
        if (med[0] > 0) printf("median load, %s vs %s: %+.1f%%\n", g[k].name, g[0].name, 100.0 * (med[k] - med[0]) / med[0]);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2) usage();
    const char *c = argv[1]; argc -= 2; argv += 2;
    if (!strcmp(c, "--version") || !strcmp(c, "version")) { puts("iio " IIO_VERSION_STR); return 0; }
    if (!strcmp(c, "record")) return cmd_record(argc, argv);
    if (!strcmp(c, "train")) return cmd_train(argc, argv);
    if (!strcmp(c, "eval")) return cmd_eval(argc, argv);
    if (!strcmp(c, "curve")) return cmd_curve(argc, argv);
    if (!strcmp(c, "run")) return cmd_run(argc, argv);
    if (!strcmp(c, "evict")) return cmd_evict(argc, argv);
    if (!strcmp(c, "inspect")) return cmd_inspect(argc, argv);
    if (!strcmp(c, "bench")) return cmd_bench(argc, argv);
    if (!strcmp(c, "doctor")) return cmd_doctor(argc, argv);
    if (!strcmp(c, "replay")) return cmd_replay(argc, argv);
    if (!strcmp(c, "loads")) return cmd_loads(argc, argv);
    if (!strcmp(c, "replay-worker")) return cmd_replay_worker(argc, argv);
    usage();
    return 2;
}
