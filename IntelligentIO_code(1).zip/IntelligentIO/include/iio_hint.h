/*
 * iio_hint.h - optional developer API (header-only, no link dependency).
 *
 *   #include <iio_hint.h>
 *   iio_hint_file("assets/level7/atlas.bin");   // "I will read this soon"
 *
 * Resolves iio_hint() from libiio.so at run time. If the process was not
 * started through `iio run`, the call is a no-op returning -1 (cost: one
 * cached dlsym). Safe to ship in a release build.
 */
#ifndef IIO_HINT_H
#define IIO_HINT_H
#define _GNU_SOURCE
#include <dlfcn.h>
static inline int iio_hint_file(const char *path)
{
    static int (*fn)(const char *);
    static int resolved;
    if (!resolved) { fn = (int (*)(const char *))dlsym(RTLD_DEFAULT, "iio_hint"); resolved = 1; }
    return fn ? fn(path) : -1;
}
#endif
