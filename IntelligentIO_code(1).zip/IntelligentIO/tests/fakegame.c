/* fakegame: synthetic "game" for testing iio. Usage: fakegame DIR NLOADS SEED [delay_us]
 * Creates DIR/ data on first run. Each level load opens: shared icon + font (shared by
 * every level -> order-1 ambiguity), level meta, atlas, music, tiles. */
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#define LEVELS 8
static char dir[512];
static void mk(const char *name, size_t sz) {
    char p[1024]; snprintf(p, sizeof p, "%s/%s", dir, name);
    if (access(p, F_OK) == 0) return;
    FILE *f = fopen(p, "wb"); char *b = malloc(sz); memset(b, name[0], sz);
    fwrite(b, 1, sz, f); fclose(f); free(b);
}
static void slurp(const char *name, int use_fopen) {
    char p[1024], buf[65536]; snprintf(p, sizeof p, "%s/%s", dir, name);
    if (use_fopen) { FILE *f = fopen(p, "rb"); if (!f) return; while (fread(buf, 1, sizeof buf, f) > 0); fclose(f); }
    else { int fd = open(p, O_RDONLY); if (fd < 0) return; while (read(fd, buf, sizeof buf) > 0); close(fd); }
}
int main(int argc, char **argv) {
    if (argc < 4) return 2;
    snprintf(dir, sizeof dir, "%s", argv[1]);
    int loads = atoi(argv[2]); srand(atoi(argv[3]));
    useconds_t delay = argc > 4 ? atoi(argv[4]) : 300;
    mkdir(dir, 0755);
    mk("icons.png", 400000); mk("font.ttf", 900000); mk("menu.meta", 2000); mk("menu.bin", 3000000);
    for (int l = 0; l < LEVELS; l++) {
        char n[64];
        snprintf(n, sizeof n, "level%d.meta", l); mk(n, 4000);
        snprintf(n, sizeof n, "atlas%d.bin", l);  mk(n, 2500000);
        snprintf(n, sizeof n, "music%d.ogg", l);  mk(n, 3500000);
        for (int t = 0; t < 4; t++) { snprintf(n, sizeof n, "tiles%d_%d.bin", l, t); mk(n, 300000); }
    }
    slurp("menu.meta", 1); usleep(delay); slurp("menu.bin", 0); slurp("font.ttf", 1);
    int level = 0;
    for (int i = 0; i < loads; i++) {
        usleep(20000);                                /* player plays */
        /* story-ish progression with some randomness: mostly next level, sometimes a random one */
        level = (rand() % 10 < 7) ? (level + 1) % LEVELS : rand() % LEVELS;
        char n[64];
        slurp("icons.png", 0); usleep(delay);
        snprintf(n, sizeof n, "level%d.meta", level); slurp(n, 1); usleep(delay);
        snprintf(n, sizeof n, "atlas%d.bin", level); slurp(n, 0); usleep(delay);
        for (int t = 0; t < 4; t++) { snprintf(n, sizeof n, "tiles%d_%d.bin", level, t); slurp(n, 0); usleep(delay); }
        slurp("font.ttf", 1);
        snprintf(n, sizeof n, "music%d.ogg", level); slurp(n, 0);
    }
    return 0;
}
