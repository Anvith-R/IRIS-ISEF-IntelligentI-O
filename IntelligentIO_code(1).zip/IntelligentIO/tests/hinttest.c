#define _GNU_SOURCE
#include <unistd.h>
#include <stdio.h>
#include "iio_hint.h"
int main(int argc, char **argv) { int r = iio_hint_file(argc > 1 ? argv[1] : "/etc/hostname"); usleep(200000); printf("hint rc=%d\n", r); return 0; }
