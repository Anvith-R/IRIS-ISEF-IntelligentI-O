#!/bin/bash
# End-to-end smoke test using the synthetic game. No root needed.
set -e
cd "$(dirname "$0")/.."
# NOTE: not /tmp - on Fedora that is tmpfs, whose pages can never be evicted.
D=$(mktemp -d -p "${IIO_TEST_DIR:-$HOME}" .iio-test.XXXXXX); trap 'rm -rf "$D"' EXIT
./tests/fakegame $D/data 1 1 >/dev/null            # create data
echo "== record 6 sessions"
for s in 11 12 13 14 15 16; do ./iio record --root $D/data --out $D/traces -- ./tests/fakegame $D/data 25 $s 2>&1 | tail -1; done
echo "== train"
./iio train -o $D/game.iiom $D/traces/*.trace
./iio inspect $D/game.iiom
echo; echo "== offline eval (leave-one-out)"
./iio eval $D/traces/*.trace
echo; echo "== live A/B (new unseen session seed 99)"
./iio evict --model $D/game.iiom >/dev/null
./iio run --model $D/game.iiom --baseline -- ./tests/fakegame $D/data 25 99 0
./iio evict --model $D/game.iiom >/dev/null
./iio run --model $D/game.iiom --stats -- ./tests/fakegame $D/data 25 99 0
