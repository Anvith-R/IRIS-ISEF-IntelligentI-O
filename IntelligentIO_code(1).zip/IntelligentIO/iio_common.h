/*
 * IntelligentI/O (iio) - shared definitions                      v0.3 / BCL-3
 *
 * Algorithm: BCL-3  (Burst-aware Chained Lookahead, order-2, declared priors)
 *   - Griffioen & Appleton: probability graph with a lookahead window
 *     (P[b opens within next W opens | a just opened]).
 *   - SEER-style semantic distance: every edge stores the mean number of
 *     intervening opens (dist) and mean wall time (dt) between a and b, used
 *     to order prefetches by "needed soonest first".
 *   - Order-2 context (prev,cur) with confidence-weighted back-off to order-1.
 *   - Temporal batching: opens are grouped into bursts; edges record how often
 *     b was in the SAME burst as a, which boosts confidence.
 *   - Chained prediction: confident immediate successors are expanded again.
 *   - NEW (0.3) Declared priors: a developer manifest is merged as Dirichlet
 *     style pseudo-counts. It bootstraps the model with zero training
 *     sessions and is out-voted by evidence if it is wrong.
 *   - NEW (0.3) Deadline-aware issue + hard speculative-footprint cap are
 *     runtime features of libiio.c (see there).
 *
 * The model file format is unchanged from 0.2 (IIO_VERSION 2): models trained
 * by the previous release load in this one and vice versa.
 */
#ifndef IIO_COMMON_H
#define IIO_COMMON_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stddef.h>
#include <stdint.h>

#define IIO_VERSION_STR "0.3.0"
#define IIO_MAGIC       0x4d4f4949u /* "IIOM" */
#define IIO_VERSION     2u
#define IIO_NONE        0xFFFFFFFFu
#define IIO_START       0u          /* virtual "process start" node */
#define IIO_MAX_ROOTS   4
#define IIO_MAX_WINDOW  32
#define IIO_MAXC        128         /* max candidates per prediction */

/* 16-byte edge: "to" follows the owning context within the lookahead window */
typedef struct {
    uint32_t to;
    uint16_t cnt;     /* times `to` followed this context within window    */
    uint16_t bcnt;    /* ...of which in the same temporal burst            */
    uint16_t dist16;  /* mean semantic distance (opens in between+1) * 16  */
    uint16_t _pad;
    uint32_t dt_us;   /* mean time until `to` opens                        */
} iio_edge;

/* context: (a,IIO_NONE) = order-1 on a ; (a,b) = order-2 "a then b"      */
typedef struct {
    uint32_t a, b;
    uint32_t total;   /* occurrences of the context                        */
    uint32_t first;   /* index into edges[]                                */
    uint32_t n;       /* number of edges                                   */
} iio_ctx;

typedef struct {
    char    **s;
    uint32_t  n, cap;
    uint32_t *h;
    uint32_t  hcap;
} iio_strtab;

typedef struct {
    uint32_t   window, burst_gap_us, n_roots;
    char      *roots[IIO_MAX_ROOTS];
    iio_strtab st;               /* id -> key ("@0/rel/path" or "/abs")    */
    uint32_t   n_ctx, n_edges;
    iio_ctx   *ctx;              /* sorted by (a,b)                        */
    iio_edge  *edges;
} iio_model;

typedef struct {
    double thr;        /* min compound score to prefetch                   */
    double chain_thr;  /* min compound score to expand further             */
    double k2;         /* order-2 confidence constant (Witten-Bell-like)   */
    double beta;       /* burst-affinity bonus                             */
    int    depth;      /* chain depth (0 = no chaining)                    */
    int    use_o2;     /* 1 = order-2 blending enabled                     */
    int    max_dist16; /* ignore edges with mean distance above this       */
} iio_params;

typedef struct {
    uint32_t id;
    float    score;
    uint32_t dist16;   /* cumulative expected distance, *16                */
    uint32_t dt_us;
} iio_cand;

/* trace (one play session) */
typedef struct {
    size_t    n, cap;
    char    **key;
    uint64_t *t;                 /* microseconds since process start       */
    char     *roots[IIO_MAX_ROOTS];
    uint32_t  n_roots;
} iio_trace;

iio_trace *iio_trace_load(const char *file);
void       iio_trace_free(iio_trace *t);

/* string table */
uint32_t iio_st_find(const iio_strtab *t, const char *s);
uint32_t iio_st_intern(iio_strtab *t, const char *s);

/* training */
typedef struct iio_trainer iio_trainer;
iio_trainer *iio_trainer_new(uint32_t window, uint32_t burst_gap_us);
int  iio_trainer_add(iio_trainer *T, const iio_trace *tr);
void iio_trainer_set_roots(iio_trainer *T, char *const roots[], uint32_t n);
/* Developer manifest ("trigger: dep dep ..."), merged as `prior` pseudo-counts.
 * Returns number of rules applied (>=0) or -1 with a message in err. */
int  iio_trainer_add_manifest(iio_trainer *T, const char *file, int prior,
                              char *err, size_t errsz, int *nwarn);
int  iio_trainer_finish(iio_trainer *T, int min_cnt, int max_edges, iio_model *out);
void iio_trainer_free(iio_trainer *T);

/* model */
int  iio_model_save(const iio_model *m, const char *file);
int  iio_model_load(iio_model *m, const char *file);
void iio_model_free(iio_model *m);
const iio_ctx *iio_find_ctx(const iio_model *m, uint32_t a, uint32_t b);
int  iio_key_to_path(char *const roots[], uint32_t nroots, const char *key,
                     char *out, size_t outsz);

/* prediction */
void iio_params_default(iio_params *p);
void iio_params_from_env(iio_params *p);
int  iio_predict(const iio_model *m, const iio_params *p, uint32_t prev,
                 uint32_t cur, iio_cand *out, int maxout);

#endif
