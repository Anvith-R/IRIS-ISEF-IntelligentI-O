/*
 * IntelligentI/O - trace parsing, trainer (counting), model I/O, predictor.
 * Pure C11/GNU, no dependencies beyond libc.
 */
#define _GNU_SOURCE
#include "iio_common.h"

#include <errno.h>
#include <glob.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/* ======================================================================
 * string table (open addressing, ids are dense)
 * ==================================================================== */
static uint64_t fnv1a(const char *s)
{
    uint64_t h = 1469598103934665603ULL;
    while (*s) { h ^= (unsigned char)*s++; h *= 1099511628211ULL; }
    return h;
}

static void st_rehash(iio_strtab *t, uint32_t hcap)
{
    free(t->h);
    t->h = calloc(hcap, sizeof(uint32_t));
    t->hcap = hcap;
    for (uint32_t i = 0; i < t->n; i++) {
        uint32_t j = (uint32_t)(fnv1a(t->s[i]) & (hcap - 1));
        while (t->h[j]) j = (j + 1) & (hcap - 1);
        t->h[j] = i + 1;
    }
}

uint32_t iio_st_find(const iio_strtab *t, const char *s)
{
    if (!t->hcap) return IIO_NONE;
    uint32_t j = (uint32_t)(fnv1a(s) & (t->hcap - 1));
    while (t->h[j]) {
        if (!strcmp(t->s[t->h[j] - 1], s)) return t->h[j] - 1;
        j = (j + 1) & (t->hcap - 1);
    }
    return IIO_NONE;
}

uint32_t iio_st_intern(iio_strtab *t, const char *s)
{
    uint32_t id = iio_st_find(t, s);
    if (id != IIO_NONE) return id;
    if ((uint64_t)(t->n + 1) * 2 > t->hcap)
        st_rehash(t, t->hcap ? t->hcap * 2 : 1024);
    if (t->n == t->cap) {
        t->cap = t->cap ? t->cap * 2 : 256;
        t->s = realloc(t->s, t->cap * sizeof(char *));
    }
    t->s[t->n] = strdup(s);
    id = t->n++;
    uint32_t j = (uint32_t)(fnv1a(s) & (t->hcap - 1));
    while (t->h[j]) j = (j + 1) & (t->hcap - 1);
    t->h[j] = id + 1;
    return id;
}

static void st_free(iio_strtab *t)
{
    for (uint32_t i = 0; i < t->n; i++) free(t->s[i]);
    free(t->s); free(t->h);
    memset(t, 0, sizeof *t);
}

/* ======================================================================
 * u64 -> u32 hash map (trainer only)
 * ==================================================================== */
typedef struct { uint64_t *k; uint32_t *v; size_t cap, n; } u64map; /* v = val+1 */

static inline uint64_t mix64(uint64_t x)
{
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

static void um_grow(u64map *m)
{
    size_t nc = m->cap ? m->cap * 2 : 1024;
    uint64_t *nk = calloc(nc, sizeof *nk);
    uint32_t *nv = calloc(nc, sizeof *nv);
    for (size_t i = 0; i < m->cap; i++) {
        if (!m->v[i]) continue;
        size_t j = mix64(m->k[i]) & (nc - 1);
        while (nv[j]) j = (j + 1) & (nc - 1);
        nk[j] = m->k[i]; nv[j] = m->v[i];
    }
    free(m->k); free(m->v);
    m->k = nk; m->v = nv; m->cap = nc;
}

static uint32_t um_get(const u64map *m, uint64_t key)
{
    if (!m->cap) return IIO_NONE;
    size_t j = mix64(key) & (m->cap - 1);
    while (m->v[j]) {
        if (m->k[j] == key) return m->v[j] - 1;
        j = (j + 1) & (m->cap - 1);
    }
    return IIO_NONE;
}

static void um_put(u64map *m, uint64_t key, uint32_t val)
{
    if ((m->n + 1) * 2 > m->cap) um_grow(m);
    size_t j = mix64(key) & (m->cap - 1);
    while (m->v[j]) j = (j + 1) & (m->cap - 1);
    m->k[j] = key; m->v[j] = val + 1; m->n++;
}

/* ======================================================================
 * trace files:   #iio1 / #root N path / "<t_us>\t<key>"
 * ==================================================================== */
iio_trace *iio_trace_load(const char *file)
{
    FILE *f = fopen(file, "r");
    if (!f) return NULL;
    iio_trace *t = calloc(1, sizeof *t);
    char *line = NULL; size_t lcap = 0; ssize_t len;
    while ((len = getline(&line, &lcap, f)) > 0) {
        if (line[len - 1] == '\n') line[--len] = 0;
        if (line[0] == '#') {
            int idx, off = 0;
            if (!strncmp(line, "#root ", 6) &&
                sscanf(line + 6, "%d %n", &idx, &off) >= 1 &&
                idx >= 0 && idx < IIO_MAX_ROOTS && off > 0) {
                free(t->roots[idx]);
                t->roots[idx] = strdup(line + 6 + off);
                if ((uint32_t)idx + 1 > t->n_roots) t->n_roots = idx + 1;
            }
            continue;
        }
        char *tab = strchr(line, '\t');
        if (!tab || !tab[1]) continue;
        *tab = 0;
        if (t->n == t->cap) {
            t->cap = t->cap ? t->cap * 2 : 1024;
            t->key = realloc(t->key, t->cap * sizeof(char *));
            t->t = realloc(t->t, t->cap * sizeof(uint64_t));
        }
        t->t[t->n] = strtoull(line, NULL, 10);
        t->key[t->n] = strdup(tab + 1);
        t->n++;
    }
    free(line);
    fclose(f);
    return t;
}

void iio_trace_free(iio_trace *t)
{
    if (!t) return;
    for (size_t i = 0; i < t->n; i++) free(t->key[i]);
    for (int i = 0; i < IIO_MAX_ROOTS; i++) free(t->roots[i]);
    free(t->key); free(t->t); free(t);
}

/* ======================================================================
 * trainer: pure counting
 * ==================================================================== */
typedef struct { uint32_t a, b, total; } tctx;
typedef struct { uint32_t ctx, to, cnt, bcnt; uint64_t sd, sdt; } tedge;

struct iio_trainer {
    iio_model m;
    u64map cmap, emap;
    tctx *c;  size_t nc, cc;
    tedge *e; size_t ne, ce;
    uint32_t sessions;
};

iio_trainer *iio_trainer_new(uint32_t window, uint32_t burst_gap_us)
{
    iio_trainer *T = calloc(1, sizeof *T);
    if (window < 1) window = 1;
    if (window > IIO_MAX_WINDOW) window = IIO_MAX_WINDOW;
    T->m.window = window;
    T->m.burst_gap_us = burst_gap_us;
    iio_st_intern(&T->m.st, "<START>");   /* id 0 */
    return T;
}

static uint32_t ctx_get(iio_trainer *T, uint32_t a, uint32_t b)
{
    uint64_t key = ((uint64_t)a << 32) | b;
    uint32_t i = um_get(&T->cmap, key);
    if (i != IIO_NONE) return i;
    if (T->nc == T->cc) {
        T->cc = T->cc ? T->cc * 2 : 1024;
        T->c = realloc(T->c, T->cc * sizeof *T->c);
    }
    T->c[T->nc] = (tctx){ a, b, 0 };
    um_put(&T->cmap, key, (uint32_t)T->nc);
    return (uint32_t)T->nc++;
}

static void edge_add_w(iio_trainer *T, uint32_t ctx, uint32_t to, uint32_t dist,
                       uint64_t dt, int same_burst, uint32_t w)
{
    uint64_t key = ((uint64_t)ctx << 32) | to;
    uint32_t i = um_get(&T->emap, key);
    if (i == IIO_NONE) {
        if (T->ne == T->ce) {
            T->ce = T->ce ? T->ce * 2 : 4096;
            T->e = realloc(T->e, T->ce * sizeof *T->e);
        }
        T->e[T->ne] = (tedge){ ctx, to, 0, 0, 0, 0 };
        um_put(&T->emap, key, (uint32_t)T->ne);
        i = (uint32_t)T->ne++;
    }
    tedge *e = &T->e[i];
    e->cnt += w; e->bcnt += same_burst ? w : 0;
    e->sd += (uint64_t)dist * w; e->sdt += dt * w;
}

static inline void edge_add(iio_trainer *T, uint32_t ctx, uint32_t to, uint32_t dist,
                            uint64_t dt, int same_burst)
{
    edge_add_w(T, ctx, to, dist, dt, same_burst, 1);
}

int iio_trainer_add(iio_trainer *T, const iio_trace *tr)
{
    size_t n = tr->n;
    if (!n) return 0;
    if (!T->m.n_roots)
        for (uint32_t i = 0; i < tr->n_roots && i < IIO_MAX_ROOTS; i++)
            if (tr->roots[i]) { T->m.roots[i] = strdup(tr->roots[i]); T->m.n_roots = i + 1; }

    uint32_t *ev = malloc((n + 1) * sizeof *ev);
    uint64_t *ts = malloc((n + 1) * sizeof *ts);
    uint32_t *bu = malloc((n + 1) * sizeof *bu);
    ev[0] = IIO_START; ts[0] = tr->t[0];
    for (size_t k = 0; k < n; k++) {
        ev[k + 1] = iio_st_intern(&T->m.st, tr->key[k]);
        ts[k + 1] = tr->t[k] < ts[k] ? ts[k] : tr->t[k];   /* monotonic */
    }
    bu[0] = 0;
    for (size_t k = 1; k <= n; k++)
        bu[k] = bu[k - 1] + ((ts[k] - ts[k - 1]) > T->m.burst_gap_us ? 1 : 0);

    const size_t W = T->m.window;
    for (size_t i = 0; i <= n; i++) {
        uint32_t c1 = ctx_get(T, ev[i], IIO_NONE);
        T->c[c1].total++;
        uint32_t c2 = IIO_NONE;
        if (i >= 1) { c2 = ctx_get(T, ev[i - 1], ev[i]); T->c[c2].total++; }

        uint32_t seen[IIO_MAX_WINDOW]; size_t ns = 0;
        for (size_t j = i + 1; j <= n && j <= i + W; j++) {
            uint32_t to = ev[j];
            if (to == ev[i]) continue;
            int dup = 0;
            for (size_t s = 0; s < ns; s++) if (seen[s] == to) { dup = 1; break; }
            if (dup) continue;
            seen[ns++] = to;
            uint64_t dt = ts[j] - ts[i];
            int sb = (bu[j] == bu[i]);
            edge_add(T, c1, to, (uint32_t)(j - i), dt, sb);
            if (c2 != IIO_NONE) edge_add(T, c2, to, (uint32_t)(j - i), dt, sb);
        }
    }
    free(ev); free(ts); free(bu);
    T->sessions++;
    return 1;
}

/* ======================================================================
 * developer manifest
 *
 *   # comment
 *   root /path/to/assets           (optional; else roots come from traces/--root)
 *   prior 6                        (pseudo-counts per declared edge; default 6)
 *   @start: menu.meta ui/font.ttf  (what a process opens first)
 *   level3.meta: atlas3.bin tiles3_*.bin music3.ogg
 *   scenes/s*.meta: shared/font.ttf (triggers and deps may be globs)
 *
 * Paths are relative to root 0, absolute, or "@N/rel" for root N. The order of
 * the deps is the order they are expected to be needed (nearest first).
 * ==================================================================== */
void iio_trainer_set_roots(iio_trainer *T, char *const roots[], uint32_t n)
{
    for (uint32_t i = 0; i < n && T->m.n_roots < IIO_MAX_ROOTS; i++) {
        char rp[PATH_MAX];
        if (!roots[i] || !realpath(roots[i], rp)) continue;
        size_t l = strlen(rp);
        while (l > 1 && rp[l - 1] == '/') rp[--l] = 0;
        int dup = 0;
        for (uint32_t j = 0; j < T->m.n_roots; j++) if (!strcmp(T->m.roots[j], rp)) dup = 1;
        if (dup) continue;
        T->m.roots[T->m.n_roots++] = strdup(rp);
    }
}

typedef struct { uint32_t *id; int n, cap; } idlist;
static void idl_add(idlist *l, uint32_t id)
{
    if (l->n == l->cap) { l->cap = l->cap ? l->cap * 2 : 16; l->id = realloc(l->id, l->cap * sizeof(uint32_t)); }
    l->id[l->n++] = id;
}

static int abs_to_key(const iio_trainer *T, const char *abs, char *out, size_t outsz)
{
    const iio_model *m = &T->m;
    if (m->n_roots) {
        for (uint32_t i = 0; i < m->n_roots; i++) {
            if (!m->roots[i]) continue;
            size_t l = strlen(m->roots[i]);
            if (!strncmp(abs, m->roots[i], l) && abs[l] == '/')
                return snprintf(out, outsz, "@%u%s", i, abs + l) < (int)outsz ? 0 : -1;
        }
        return -1;
    }
    return snprintf(out, outsz, "%s", abs) < (int)outsz ? 0 : -1;
}

static int tok_to_abs(const iio_trainer *T, const char *tok, char *out, size_t outsz)
{
    const iio_model *m = &T->m;
    if (tok[0] == '@' && tok[1] >= '0' && tok[1] <= '9' && tok[2] == '/')
        return iio_key_to_path((char *const *)m->roots, m->n_roots, tok, out, outsz);
    if (tok[0] == '/') return snprintf(out, outsz, "%s", tok) < (int)outsz ? 0 : -1;
    if (tok[0] == '.' && tok[1] == '/') tok += 2;
    if (!m->n_roots || !m->roots[0]) return -1;
    return snprintf(out, outsz, "%s/%s", m->roots[0], tok) < (int)outsz ? 0 : -1;
}

static int expand_tok(iio_trainer *T, const char *tok, idlist *out, int *nwarn,
                      char *err, size_t errsz, int lineno)
{
    char abs[PATH_MAX], key[PATH_MAX + 8];
    if (tok_to_abs(T, tok, abs, sizeof abs)) {
        snprintf(err, errsz, "line %d: cannot resolve '%s' (relative path needs a root: "
                 "add 'root PATH' to the manifest or pass --root)", lineno, tok);
        return -1;
    }
    if (strpbrk(tok, "*?[")) {
        glob_t g; memset(&g, 0, sizeof g);
        if (glob(abs, 0, NULL, &g) == 0) {
            for (size_t i = 0; i < g.gl_pathc; i++)
                if (!abs_to_key(T, g.gl_pathv[i], key, sizeof key))
                    idl_add(out, iio_st_intern(&T->m.st, key));
        } else {
            (*nwarn)++;
            fprintf(stderr, "iio: manifest line %d: '%s' matches no file\n", lineno, tok);
        }
        globfree(&g);
        return 0;
    }
    struct stat st;
    if (stat(abs, &st)) {
        (*nwarn)++;
        fprintf(stderr, "iio: manifest line %d: warning: %s does not exist\n", lineno, abs);
    }
    if (abs_to_key(T, abs, key, sizeof key)) {
        snprintf(err, errsz, "line %d: '%s' is outside every root", lineno, abs);
        return -1;
    }
    idl_add(out, iio_st_intern(&T->m.st, key));
    return 0;
}

int iio_trainer_add_manifest(iio_trainer *T, const char *file, int prior,
                             char *err, size_t errsz, int *nwarn_out)
{
    FILE *f = fopen(file, "r");
    if (!f) { snprintf(err, errsz, "cannot open %s: %s", file, strerror(errno)); return -1; }
    if (prior < 1) prior = 6;
    char *line = NULL; size_t cap = 0; ssize_t len;
    int lineno = 0, nwarn = 0, nrules = 0, rc = 0;
    err[0] = 0;
    while (rc == 0 && (len = getline(&line, &cap, f)) > 0) {
        lineno++;
        char *p = line, *hash = strchr(p, '#');
        if (hash) *hash = 0;
        while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
        char *e = p + strlen(p);
        while (e > p && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r' || e[-1] == '\n')) *--e = 0;
        if (!*p) continue;
        if (!strncmp(p, "prior", 5) && (p[5] == ' ' || p[5] == '\t')) {
            prior = atoi(p + 5); if (prior < 1) prior = 1; if (prior > 1000) prior = 1000;
            continue;
        }
        if (!strncmp(p, "root", 4) && (p[4] == ' ' || p[4] == '\t')) {
            char *r = p + 5; while (*r == ' ' || *r == '\t') r++;
            char *rr[1] = { r };
            iio_trainer_set_roots(T, rr, 1);
            continue;
        }
        char *colon = strchr(p, ':');
        if (!colon) { snprintf(err, errsz, "line %d: expected 'trigger: dep dep ...'", lineno); rc = -1; break; }
        *colon = 0;
        char *trig = p; e = trig + strlen(trig);
        while (e > trig && (e[-1] == ' ' || e[-1] == '\t')) *--e = 0;
        if (!*trig) { snprintf(err, errsz, "line %d: empty trigger", lineno); rc = -1; break; }

        idlist tl = { 0 }, dl = { 0 };
        if (!strcmp(trig, "@start")) idl_add(&tl, IIO_START);
        else rc = expand_tok(T, trig, &tl, &nwarn, err, errsz, lineno);
        char *save = NULL;
        for (char *tok = strtok_r(colon + 1, " \t", &save); rc == 0 && tok; tok = strtok_r(NULL, " \t", &save))
            rc = expand_tok(T, tok, &dl, &nwarn, err, errsz, lineno);
        if (rc == 0) {
            for (int a = 0; a < tl.n; a++) {
                uint32_t c1 = ctx_get(T, tl.id[a], IIO_NONE);
                T->c[c1].total += (uint32_t)prior;
                for (int j = 0; j < dl.n; j++) {
                    if (dl.id[j] == tl.id[a]) continue;
                    edge_add_w(T, c1, dl.id[j], (uint32_t)(j + 1), 0, 0, (uint32_t)prior);
                }
                nrules++;
            }
        }
        free(tl.id); free(dl.id);
    }
    free(line); fclose(f);
    if (nwarn_out) *nwarn_out = nwarn;
    return rc ? -1 : nrules;
}

static int cmp_edge(const void *x, const void *y, void *arg)
{
    const tedge *e = arg;
    const tedge *a = &e[*(const uint32_t *)x], *b = &e[*(const uint32_t *)y];
    if (a->ctx != b->ctx) return a->ctx < b->ctx ? -1 : 1;
    if (a->cnt != b->cnt) return a->cnt > b->cnt ? -1 : 1;
    if (a->to != b->to) return a->to < b->to ? -1 : 1;
    return 0;
}

static int cmp_ctx(const void *x, const void *y)
{
    const iio_ctx *a = x, *b = y;
    uint64_t ka = ((uint64_t)a->a << 32) | a->b, kb = ((uint64_t)b->a << 32) | b->b;
    return ka < kb ? -1 : ka > kb;
}

int iio_trainer_finish(iio_trainer *T, int min_cnt, int max_edges, iio_model *out)
{
    size_t ne = T->ne;
    uint32_t *ord = malloc((ne ? ne : 1) * sizeof *ord);
    for (size_t i = 0; i < ne; i++) ord[i] = (uint32_t)i;
    qsort_r(ord, ne, sizeof *ord, cmp_edge, T->e);

    iio_edge *oe = calloc(ne ? ne : 1, sizeof *oe);
    iio_ctx  *oc = calloc(T->nc ? T->nc : 1, sizeof *oc);
    size_t no = 0, nco = 0, i = 0;
    while (i < ne) {
        uint32_t cx = T->e[ord[i]].ctx;
        size_t j = i;
        while (j < ne && T->e[ord[j]].ctx == cx) j++;
        const tctx *c = &T->c[cx];
        uint32_t factor = (c->total + 65534) / 65535;
        if (!factor) factor = 1;
        size_t first = no; int kept = 0;
        for (size_t k = i; k < j && kept < max_edges; k++) {
            const tedge *e = &T->e[ord[k]];
            if ((int)e->cnt < min_cnt) break;       /* sorted by cnt desc */
            iio_edge *o = &oe[no++];
            uint32_t cn = e->cnt / factor; if (!cn) cn = 1;
            uint32_t bc = e->bcnt / factor;
            double d = 16.0 * (double)e->sd / e->cnt;
            uint64_t dtm = e->sdt / e->cnt;
            o->to = e->to;
            o->cnt = (uint16_t)cn;
            o->bcnt = (uint16_t)(bc > cn ? cn : bc);
            o->dist16 = d > 65535.0 ? 65535 : (uint16_t)(d + 0.5);
            o->dt_us = dtm > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)dtm;
            kept++;
        }
        if (kept) {
            uint32_t tot = c->total / factor; if (!tot) tot = 1;
            oc[nco++] = (iio_ctx){ c->a, c->b, tot, (uint32_t)first, (uint32_t)kept };
        }
        i = j;
    }
    qsort(oc, nco, sizeof *oc, cmp_ctx);
    free(ord);

    memset(out, 0, sizeof *out);
    out->window = T->m.window; out->burst_gap_us = T->m.burst_gap_us;
    out->n_roots = T->m.n_roots;
    for (int r = 0; r < IIO_MAX_ROOTS; r++) { out->roots[r] = T->m.roots[r]; T->m.roots[r] = NULL; }
    out->st = T->m.st; memset(&T->m.st, 0, sizeof T->m.st);
    out->ctx = oc; out->n_ctx = (uint32_t)nco;
    out->edges = oe; out->n_edges = (uint32_t)no;
    return 0;
}

void iio_trainer_free(iio_trainer *T)
{
    if (!T) return;
    st_free(&T->m.st);
    for (int r = 0; r < IIO_MAX_ROOTS; r++) free(T->m.roots[r]);
    free(T->cmap.k); free(T->cmap.v); free(T->emap.k); free(T->emap.v);
    free(T->c); free(T->e); free(T);
}

/* ======================================================================
 * model file
 * ==================================================================== */
static int wr32(FILE *f, uint32_t v) { return fwrite(&v, 4, 1, f) == 1 ? 0 : -1; }
static int rd32(FILE *f, uint32_t *v) { return fread(v, 4, 1, f) == 1 ? 0 : -1; }
static int wrstr(FILE *f, const char *s)
{
    uint32_t l = (uint32_t)strlen(s);
    if (wr32(f, l)) return -1;
    return l ? (fwrite(s, 1, l, f) == l ? 0 : -1) : 0;
}
static char *rdstr(FILE *f)
{
    uint32_t l;
    if (rd32(f, &l) || l > (1u << 20)) return NULL;
    char *s = malloc(l + 1);
    if (l && fread(s, 1, l, f) != l) { free(s); return NULL; }
    s[l] = 0;
    return s;
}

int iio_model_save(const iio_model *m, const char *file)
{
    char tmp[4200];
    snprintf(tmp, sizeof tmp, "%s.tmp", file);
    FILE *f = fopen(tmp, "wb");
    if (!f) return -1;
    int bad = 0;
    bad |= wr32(f, IIO_MAGIC) | wr32(f, IIO_VERSION) | wr32(f, m->st.n) |
           wr32(f, m->n_ctx) | wr32(f, m->n_edges) | wr32(f, m->n_roots) |
           wr32(f, m->window) | wr32(f, m->burst_gap_us);
    for (uint32_t i = 0; i < m->n_roots; i++) bad |= wrstr(f, m->roots[i] ? m->roots[i] : "");
    for (uint32_t i = 0; i < m->st.n; i++) bad |= wrstr(f, m->st.s[i]);
    if (m->n_ctx && fwrite(m->ctx, sizeof *m->ctx, m->n_ctx, f) != m->n_ctx) bad = -1;
    if (m->n_edges && fwrite(m->edges, sizeof *m->edges, m->n_edges, f) != m->n_edges) bad = -1;
    if (fclose(f)) bad = -1;
    if (bad) { unlink(tmp); return -1; }
    return rename(tmp, file);
}

int iio_model_load(iio_model *m, const char *file)
{
    memset(m, 0, sizeof *m);
    FILE *f = fopen(file, "rb");
    if (!f) return -1;
    uint32_t magic, ver, nf, nc, ne, nr;
    if (rd32(f, &magic) || rd32(f, &ver) || magic != IIO_MAGIC || ver != IIO_VERSION ||
        rd32(f, &nf) || rd32(f, &nc) || rd32(f, &ne) || rd32(f, &nr) ||
        rd32(f, &m->window) || rd32(f, &m->burst_gap_us) || nr > IIO_MAX_ROOTS) {
        fclose(f); return -1;
    }
    m->n_roots = nr;
    for (uint32_t i = 0; i < nr; i++) m->roots[i] = rdstr(f);
    for (uint32_t i = 0; i < nf; i++) {
        char *s = rdstr(f);
        if (!s) { fclose(f); iio_model_free(m); return -1; }
        iio_st_intern(&m->st, s);
        free(s);
    }
    m->ctx = calloc(nc ? nc : 1, sizeof *m->ctx);
    m->edges = calloc(ne ? ne : 1, sizeof *m->edges);
    if ((nc && fread(m->ctx, sizeof *m->ctx, nc, f) != nc) ||
        (ne && fread(m->edges, sizeof *m->edges, ne, f) != ne)) {
        fclose(f); iio_model_free(m); return -1;
    }
    m->n_ctx = nc; m->n_edges = ne;
    fclose(f);
    return 0;
}

void iio_model_free(iio_model *m)
{
    st_free(&m->st);
    for (int r = 0; r < IIO_MAX_ROOTS; r++) free(m->roots[r]);
    free(m->ctx); free(m->edges);
    memset(m, 0, sizeof *m);
}

int iio_key_to_path(char *const roots[], uint32_t nroots, const char *key,
                    char *out, size_t outsz)
{
    if (key[0] == '@') {
        unsigned idx = (unsigned char)key[1] - '0';
        if (idx >= nroots || !roots[idx] || key[2] != '/') return -1;
        return snprintf(out, outsz, "%s%s", roots[idx], key + 2) < (int)outsz ? 0 : -1;
    }
    if (key[0] != '/') return -1;
    return snprintf(out, outsz, "%s", key) < (int)outsz ? 0 : -1;
}

/* ======================================================================
 * predictor
 * ==================================================================== */
static inline uint64_t ckey(uint32_t a, uint32_t b) { return ((uint64_t)a << 32) | b; }

const iio_ctx *iio_find_ctx(const iio_model *m, uint32_t a, uint32_t b)
{
    uint64_t key = ckey(a, b);
    size_t lo = 0, hi = m->n_ctx;
    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (ckey(m->ctx[mid].a, m->ctx[mid].b) < key) lo = mid + 1; else hi = mid;
    }
    if (lo < m->n_ctx && ckey(m->ctx[lo].a, m->ctx[lo].b) == key) return &m->ctx[lo];
    return NULL;
}

void iio_params_default(iio_params *p)
{
    p->thr = 0.50; p->chain_thr = 0.70; p->k2 = 1.5; p->beta = 0.15;
    p->depth = 2;  p->use_o2 = 1;       p->max_dist16 = 65535;
}

void iio_params_from_env(iio_params *p)
{
    const char *s;
    iio_params_default(p);
    if ((s = getenv("IIO_THR")))       p->thr = atof(s);
    if ((s = getenv("IIO_CHAIN_THR"))) p->chain_thr = atof(s);
    if ((s = getenv("IIO_K2")))        p->k2 = atof(s);
    if ((s = getenv("IIO_BETA")))      p->beta = atof(s);
    if ((s = getenv("IIO_DEPTH")))     p->depth = atoi(s);
    if ((s = getenv("IIO_ORDER")))     p->use_o2 = atoi(s) >= 2;
}

static const iio_edge *edge_in(const iio_model *m, const iio_ctx *c, uint32_t to)
{
    if (!c) return NULL;
    for (uint32_t k = 0; k < c->n; k++)
        if (m->edges[c->first + k].to == to) return &m->edges[c->first + k];
    return NULL;
}

static void add_cand(iio_cand *arr, int *n, uint32_t id, double score,
                     uint32_t dist, uint32_t dt)
{
    for (int i = 0; i < *n; i++)
        if (arr[i].id == id) {
            if (score > arr[i].score) { arr[i].score = (float)score; arr[i].dist16 = dist; arr[i].dt_us = dt; }
            return;
        }
    if (*n < IIO_MAXC) arr[(*n)++] = (iio_cand){ id, (float)score, dist, dt };
}

static void expand(const iio_model *m, const iio_params *p, uint32_t prev, uint32_t cur,
                   double pscore, uint32_t pdist, uint32_t pdt, int depth,
                   iio_cand *arr, int *n)
{
    const iio_ctx *c1 = iio_find_ctx(m, cur, IIO_NONE);
    const iio_ctx *c2 = (p->use_o2 && prev != IIO_NONE) ? iio_find_ctx(m, prev, cur) : NULL;
    if (!c1 && !c2) return;
    /* confidence-weighted back-off: lambda -> 1 as order-2 evidence grows */
    double lam = c2 ? (double)c2->total / ((double)c2->total + p->k2) : 0.0;
    int start = *n;

    for (int pass = 0; pass < 2; pass++) {
        const iio_ctx *c = pass == 0 ? c2 : c1;
        if (!c) continue;
        for (uint32_t k = 0; k < c->n; k++) {
            const iio_edge *e = &m->edges[c->first + k];
            const iio_edge *e1, *e2;
            if (pass == 0) { e2 = e; e1 = edge_in(m, c1, e->to); }
            else {
                if (c2 && edge_in(m, c2, e->to)) continue;     /* done in pass 0 */
                e1 = e; e2 = NULL;
            }
            double p2 = e2 ? (double)e2->cnt / c2->total : 0.0;
            double p1 = e1 ? (double)e1->cnt / c1->total : 0.0;
            double score = lam * p2 + (1.0 - lam) * p1;
            const iio_edge *ref = e2 ? e2 : e1;
            if ((int)ref->dist16 > p->max_dist16) continue;
            score *= 1.0 + p->beta * (double)ref->bcnt / (double)ref->cnt;
            if (score > 1.0) score = 1.0;
            score *= pscore;
            if (score < p->thr) continue;
            add_cand(arr, n, ref->to, score, pdist + ref->dist16, pdt + ref->dt_us);
        }
    }

    if (depth >= p->depth) return;
    /* chain: expand the (up to) two soonest, most confident new candidates */
    int pick[2] = { -1, -1 }, end = *n;
    for (int i = start; i < end; i++) {
        if (arr[i].score < p->chain_thr || arr[i].dist16 - pdist > 24) continue;
        for (int s = 0; s < 2; s++) {
            if (pick[s] < 0 || arr[i].score > arr[pick[s]].score) {
                if (s == 0) pick[1] = pick[0];
                pick[s] = i; break;
            }
        }
    }
    for (int s = 0; s < 2; s++) {
        if (pick[s] < 0) continue;
        iio_cand c = arr[pick[s]];
        expand(m, p, cur, c.id, c.score, c.dist16, c.dt_us, depth + 1, arr, n);
    }
}

static int cmp_cand(const void *x, const void *y)
{
    const iio_cand *a = x, *b = y;
    if (a->dist16 != b->dist16) return a->dist16 < b->dist16 ? -1 : 1;
    if (a->score != b->score) return a->score > b->score ? -1 : 1;
    return 0;
}

int iio_predict(const iio_model *m, const iio_params *p, uint32_t prev, uint32_t cur,
                iio_cand *out, int maxout)
{
    iio_cand arr[IIO_MAXC];
    int n = 0;
    expand(m, p, prev, cur, 1.0, 0, 0, 0, arr, &n);
    int w = 0;
    for (int i = 0; i < n; i++)
        if (arr[i].id != cur && arr[i].id != IIO_START) arr[w++] = arr[i];
    qsort(arr, w, sizeof arr[0], cmp_cand);
    if (w > maxout) w = maxout;
    memcpy(out, arr, w * sizeof arr[0]);
    return w;
}
